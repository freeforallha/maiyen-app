const Map<String, String> gaStrings = {
  "Không tìm thấy người dùng": "Níor aimsíodh an t-úsáideoir",
  "Không đọc được số điện thoại":
      "Níorbh fhéidir an uimhir theileafóin a léamh",
  "Tin nhắn quá dài": "Tá an teachtaireacht rófhada",
  "Không gửi được tin nhắn": "Níorbh fhéidir an teachtaireacht a sheoladh",
  "Bạn không có quyền sửa lịch chung của nhà":
      "Níl cead agat sceideal comhroinnte an bhaile a chur in eagar",
  "Nhà của bạn": "Do bhaile",
  "Tải tin cũ hơn": "Lódáil teachtaireachtaí níos sine",
  "Nhà chưa đặt tên": "Baile gan ainm",
  "Nhà": "Baile",
  "Chưa có thông tin": "Níl aon eolas ar fáil",
  "Chưa cập nhật": "Gan nuashonrú",
  "Chủ nhà": "Úinéir",
  "Nhà được chia sẻ": "Baile comhroinnte",
  "Địa chỉ": "Seoladh",
  "An ninh ra/vào": "Slándáil iontrála",
  "Nguy hiểm khẩn cấp": "Guaiseacha éigeandála",
  "Điều khiển & hạ tầng": "Rialú agus bonneagar",
  "Môi trường": "Timpeallacht",
  "Toàn bộ thiết bị SafeHome": "Gach gléas SafeHome",
  "Cửa ra/vào": "Doras iontrála",
  "Cửa": "Doras",
  "Cửa sổ": "Fuinneog",
  "Cổng": "Geata",
  "Khóa thông minh": "Glas cliste",
  "Chuyển động": "Gluaiseacht",
  "Hiện diện": "Láithreacht",
  "Rung/chấn động": "Creathadh",
  "Kính vỡ": "Briseadh gloine",
  "Báo khói": "Aláram deataigh",
  "Báo nhiệt": "Aláram teasa",
  "Khí CO": "Aonocsaíd charbóin",
  "Báo gas": "Aláram gáis",
  "Báo ngập/rò nước": "Aláram sceite uisce",
  "Nút SOS": "Cnaipe SOS",
  "Nhiệt độ/Độ ẩm": "Teocht/Taise",
  "Bụi mịn PM2.5": "Deannach mín PM2.5",
  "CO₂": "CO₂",
  "Chất lượng không khí": "Cáilíocht an aeir",
  "Ổ điện thông minh": "Soicéad cliste",
  "Còi báo động": "Bonnán",
  "Van thông minh": "Comhla chliste",
  "Camera": "Ceamara",
  "Chuông cửa": "Cloigín dorais",
  "Bàn phím an ninh": "Méarchlár slándála",
  "Bộ mở rộng sóng": "Athsheoltóir",
  "Hub trung tâm": "Mol lárnach",
  "Đo điện năng": "Monatóir cumhachta",
  "Nguồn dự phòng UPS": "Cumhacht chúltaca UPS",
  "Thiết bị đang Offline": "Tá an gléas as líne",
  "Thiết bị đang Online": "Tá an gléas ar líne",
  "lâu không phản hồi": "gan freagairt",
  "Kết nối cần kiểm tra": "Ní mór aird a thabhairt ar an nasc",
  "Vừa xong": "Díreach anois",
  "Bị tháo": "Braitheadh cur isteach",
  "Có khói": "Braitheadh deatach",
  "Bình thường": "Gnáth",
  "Bảo vệ": "Cosaint",
  "Chế độ Bảo vệ": "Mód cosanta",
  "Tự động Bảo vệ khi rời nhà": "Cosaint uathoibríoch agus tú as baile",
  "Đã kích hoạt": "Gníomhachtaithe",
  "Sẵn sàng": "Réidh",
  "Đang đóng": "Dúnta",
  "Đang mở": "Oscailte",
  "Rò rỉ gas": "Braitheadh sceitheadh gáis",
  "Phát hiện ngập nước": "Braitheadh sceitheadh uisce",
  "Phát hiện chuyển động": "Braitheadh gluaiseacht",
  "Không có chuyển động": "Níor braitheadh aon ghluaiseacht",
  "Phát hiện hiện diện": "Braitheadh láithreacht",
  "Không phát hiện hiện diện": "Níor braitheadh láithreacht",
  "Phát hiện rung/chấn động": "Braitheadh creathadh",
  "Không có rung bất thường": "Níor braitheadh creathadh neamhghnách",
  "Phát hiện kính vỡ": "Braitheadh briseadh gloine",
  "Không có cảnh báo kính vỡ": "Níl foláireamh briste gloine ann",
  "Nhiệt độ nguy hiểm": "Braitheadh teas contúirteach",
  "Phát hiện khí CO": "Braitheadh aonocsaíd charbóin",
  "Không phát hiện khí CO": "Níor braitheadh aonocsaíd charbóin",
  "Khóa đang mở": "Díghlasáilte",
  "Khóa đang đóng": "Glasáilte",
  "Đang bật": "Ar siúl",
  "Bật": "Ar siúl",
  "Đang tắt": "Múchta",
  "Đang theo dõi điện năng": "Monatóireacht cumhachta",
  "Đang dùng nguồn dự phòng": "Ag rith ar chumhacht chúltaca",
  "Nguồn điện bình thường": "Gnáthchumhacht phríomhlíonra",
  "Còi đang bật": "Bonnán gníomhach",
  "Còi sẵn sàng": "Bonnán réidh",
  "Van đang mở": "Comhla oscailte",
  "Van đã đóng": "Comhla dúnta",
  "Đang hoạt động": "Ag feidhmiú",
  "Đang theo dõi": "Monatóireacht",
  "Chưa nhận diện": "Gléas neamhaitheanta",
  "Chưa có cập nhật": "Níl aon nuashonruithe fós",
  "Chưa có thiết bị, hãy nhấn nút + để thêm để bắt đầu duy trì an ninh":
      "Níl aon ghléasanna fós. Tapáil + chun ceann a chur leis agus tosú ag cosaint do bhaile.",
  "CHƯA AN TOÀN": "NEAMHSHÁBHÁILTE",
  "ĐÃ AN TOÀN": "SÁBHÁILTE",
  "Nhà đang có dấu hiệu cần kiểm tra, bạn nên xem lại các trạng thái bên dưới.":
      "Ní mór aird a thabhairt ar do bhaile. Athbhreithnigh na stádais thíos.",
  "Nhà đang hoạt động ổn định, bạn có thể yên tâm.":
      "Tá do bhaile ag feidhmiú de ghnáth.",
  "Không có dấu hiệu khói hoặc SOS bất thường.":
      "Níor braitheadh deatach neamhghnách ná gníomhaíocht SOS.",
  "Chưa có nhiều hoạt động mới để phân tích sâu hơn.":
      "Níl dóthain gníomhaíochta le déanaí le haghaidh anailís níos doimhne.",
  "Hub kết nối bình thường": "Mol ceangailte",
  "Cài đặt cảnh báo cho nhà hiện tại": "Socruithe foláirimh don bhaile seo",
  "Nhận cảnh báo báo động": "Faigh foláirimh aláraim",
  "Đang bật cho tài khoản này": "Cumasaithe don chuntas seo",
  "Đang tắt cho tài khoản này": "Díchumasaithe don chuntas seo",
  "Hẹn giờ nhắc nhở": "Sceideal meabhrúcháin",
  "Nhắc kiểm tra nhà theo thời gian":
      "Sceideal meabhrúcháin chun an baile a sheiceáil",
  "Hẹn giờ báo động": "Sceideal aláraim",
  "Chưa thiết lập": "Gan socrú",
  "Chưa thiết lập thời gian": "Níl aon sceideal cumraithe",
  "Tổng hợp trạng thái nhà": "Achoimre ar stádas an bhaile",
  "Cần xử lý ngay": "Gníomh de dhíth",
  "Đánh giá tự động": "Measúnú uathoibrithe",
  "Tự động đánh giá": "Measúnú uathoibríoch",
  "Tổng quan hôm nay": "Forbhreathnú an lae inniu",
  "Chưa có dữ liệu tổng quan": "Níl sonraí forbhreathnaithe ann fós",
  "Chưa có dữ liệu trạng thái": "Níl sonraí stádais ann fós",
  "Chưa đủ dữ liệu để đánh giá": "Níl dóthain sonraí le measúnú",
  "Chưa có dữ liệu để đánh giá": "Níl dóthain sonraí le measúnú",
  "Bấm vào để xem chi tiết": "Tapáil chun sonraí a fheiceáil",
  "Nhấn để xem chi tiết...": "Tapáil chun sonraí a fheiceáil...",
  "Tạm dừng": "Curtha ar sos",
  "Tắt": "Múchta",
  "Chi tiết": "Sonraí",
  "Tổng hợp trạng thái": "Achoimre stádais",
  "Không an toàn": "Neamhshábháilte",
  "Cần chú ý": "Teastaíonn aird",
  "An toàn": "Sábháilte",
  "Không có": "Ceann ar bith",
  "Đổi tên nhóm": "Athainmnigh an grúpa",
  "Huỷ": "Cealaigh",
  "Lưu": "Sábháil",
  "Thêm": "Cuir leis",
  "Xoá": "Scrios",
  "Đổi tên": "Athainmnigh",
  "Nhà của tôi": "Mo bhailte",
  "Bỏ chọn toàn bộ nhóm": "Díroghnaigh an grúpa iomlán",
  "Chọn toàn bộ nhóm": "Roghnaigh an grúpa iomlán",
  "Bỏ chọn": "Díroghnaigh",
  "Quay lại": "Ar ais",
  "Tìm kiếm": "Cuardaigh",
  "Đóng tìm kiếm": "Dún an cuardach",
  "Giờ": "Uair",
  "Phút": "Nóiméad",
  "Đặt nhắc nhở cho nhà": "Socraigh meabhrúchán baile",
  "Đặt báo động cho nhà": "Socraigh aláram baile",
  "Xác nhận thay đổi": "Deimhnigh na hathruithe",
  "Tiếp tục": "Lean ar aghaidh",
  "Giờ nhắc nhở": "Am meabhrúcháin",
  "Giờ bắt đầu báo động": "Am tosaithe an aláraim",
  "Giờ kết thúc báo động": "Am críochnaithe an aláraim",
  "Không có nhà nào đủ điều kiện để cài":
      "Níor aimsíodh aon bhaile incháilithe",
  "Cài đặt hoàn tất": "Socrú críochnaithe",
  "Xác nhận rời nhà": "Deimhnigh fágáil an bhaile",
  "Xác nhận xoá nhà": "Deimhnigh scriosadh an bhaile",
  "Nhập mật khẩu": "Cuir isteach an focal faire",
  "Mật khẩu tài khoản": "Focal faire an chuntais",
  "Rời khỏi nhà": "Fág an baile",
  "Xoá nhà": "Scrios an baile",
  "Sai mật khẩu": "Focal faire mícheart",
  "Đã rời khỏi home": "D'fhág tú an baile",
  "Đã cập nhật": "Nuashonraithe",
  "Tìm home...": "Cuardaigh bailte...",
  "Đặt vị trí nhà và bật bảo vệ tự động":
      "Socraigh suíomh an bhaile agus cumasaigh cosaint uathoibríoch",
  "Chuyển quyền chủ nhà hoặc xoá nhà":
      "Aistrigh úinéireacht an bhaile nó scrios an baile",
  "Đặt nhắc nhở / báo động nhà đã chọn":
      "Socraigh meabhrúchán/aláram do na bailte roghnaithe",
  "Chia sẻ nhà đã chọn": "Comhroinn na bailte roghnaithe",
  "Mở danh sách chia sẻ nhà": "Oscail liosta comhroinnte an bhaile",
  "Xoá các nhà đã chọn?": "Scrios na bailte roghnaithe?",
  "Các nhà đã chọn sẽ bị xoá vĩnh viễn.":
      "Scriosfar na bailte roghnaithe go buan.",
  "Hoặc quét QR để xin gia nhập các nhà đã chọn":
      "Nó scan cód QR chun rochtain ar na bailte roghnaithe a iarraidh",
  "Email người nhận": "Ríomhphost an fhaighteora",
  "Chia sẻ": "Comhroinn",
  "Email chưa đăng ký": "Níl an ríomhphost cláraithe",
  "Chia sẻ hoàn tất": "Comhroinnt críochnaithe",
  "Mở List chia sẻ nhà": "Oscail liosta comhroinnte an bhaile",
  "Không có nhà nào bạn có quyền quản lý":
      "Ní bhainistíonn tú aon cheann de na bailte roghnaithe",
  "Chưa share cho ai": "Níor comhroinneadh le duine ar bith fós",
  "Tìm nhà": "Cuardaigh bailte",
  "Xoá các nhà đã chọn ?": "Scrios na bailte roghnaithe?",
  "Thông báo Home": "Fógraí baile",
  "Thông báo nhà": "Fógraí baile",
  "Vai trò thành viên đã thay đổi": "Athraíodh ról an bhaill",
  "Xoá tất cả thông báo?": "Scrios gach fógra?",
  "Toàn bộ thông báo nhà sẽ bị xoá.": "Scriosfar gach fógra baile.",
  "Chưa có thông báo nào": "Níl aon fhógraí fós",
  "Chưa có thông báo": "Níl aon fhógraí",
  "Vuốt lên để tải thêm": "Svaidhpáil suas chun tuilleadh a lódáil",
  "Không có thiết bị": "Níl aon ghléasanna",
  "Chỉ chủ nhà mới được xoá nhà":
      "Ní féidir ach leis an úinéir an baile seo a scriosadh",
  "Chỉ chủ nhà mới được chuyển quyền":
      "Ní féidir ach leis an úinéir úinéireacht a aistriú",
  "Lưu ý khi bật báo động": "Fógra aláraim",
  "Báo động đã được bật": "Aláram cumasaithe",
  "Đã hiểu": "Tuigim",
  "Lưu ý tạm tắt báo động": "Nóta faoi aláram a chur ar sos",
  "Đã bật báo động": "Aláram cumasaithe",
  "Đã tắt báo động": "Tá an t-aláram múchta",
  "Tắt báo động": "Stop an t-aláram",
  "Cả ngày": "An lá ar fad",
  "Bạn không có quyền thực hiện thao tác này.":
      "Níl cead agat an gníomh seo a dhéanamh.",
  "Không thể hoàn tất thao tác. Vui lòng thử lại.":
      "Níorbh fhéidir an gníomh a chur i gcrích. Bain triail eile as.",
  "QR gia nhập nhiều nhà không hợp lệ":
      "Cód QR neamhbhailí chun dul isteach i mbailte iomadúla",
  "Bạn đang là chủ các nhà này": "Is leatsa na bailte seo",
  "Một người dùng": "Úsáideoir",
  "Yêu cầu gia nhập nhà": "Iarratas chun dul isteach sa bhaile",
  "Đã gửi yêu cầu gia nhập nhà": "Seoladh an t-iarratas chun dul isteach",
  "QR gia nhập không hợp lệ": "Cód QR neamhbhailí chun dul isteach",
  "Bạn đang là chủ nhà này": "Is leatsa an baile seo cheana",
  "QR này không phải mã xin gia nhập nhà":
      "Ní cód chun dul isteach i mbaile é an cód QR seo",
  "Bạn không có quyền thêm thiết bị": "Níl cead agat gléasanna a chur leis",
  "Đã mở chế độ thêm thiết bị": "Tá péireáil gléasanna cumasaithe",
  "Rời khỏi Home này?": "Fág an baile seo?",
  "Nhà này và toàn bộ thiết bị bên trong sẽ bị xoá vĩnh viễn.":
      "Scriosfar an baile seo agus a ghléasanna go léir go buan.",
  "Đã xoá nhà": "Scriosadh an baile",
  "QR của nhà này": "Cód QR an bhaile",
  "Người khác quét mã này để gửi yêu cầu gia nhập nhà.":
      "Is féidir le daoine eile an cód seo a scanadh chun rochtain ar an mbaile a iarraidh.",
  "Chia sẻ nhà": "Comhroinn an baile",
  "Quét QR để xin gia nhập nhà": "Scan cód QR chun dul isteach i mbaile",
  "Quét QR xin gia nhập nhà": "Scan cód QR chun dul isteach sa bhaile",
  "Đưa mã QR chia sẻ nhà vào khung hình":
      "Cuir cód QR an bhaile chomhroinnte taobh istigh den fhráma",
  "Mã QR này do chủ nhà chia sẻ": "Roinn úinéir an bhaile an cód QR seo",
  "Nhập mã mời": "Cuir isteach an cód cuiridh",
  "Gửi yêu cầu gia nhập": "Seol iarratas chun dul isteach",
  "QR này không phải mã thiết bị": "Ní cód gléis é an cód QR seo",
  "Xin gia nhập nhà": "Iarratas chun dul isteach sa bhaile",
  "Quét mã QR chia sẻ nhà": "Scan cód QR comhroinnte baile",
  "Mời thành viên bằng mã QR": "Tabhair cuireadh do bhall le cód QR",
  "Không thể share cho chính bạn": "Ní féidir leat comhroinnt leat féin",
  "Lời mời chia sẻ nhà": "Cuireadh chun baile a chomhroinnt",
  "Đã share home": "Comhroinneadh an baile",
  "Chuyển quyền chủ nhà": "Aistrigh úinéireacht",
  "Không thể chuyển quyền cho chính bạn":
      "Ní féidir leat úinéireacht a aistriú chugat féin",
  "Không tìm thấy user": "Níor aimsíodh an t-úsáideoir",
  "Không tìm thấy tài khoản": "Níor aimsíodh an cuntas",
  "Xác nhận chuyển quyền": "Deimhnigh aistriú úinéireachta",
  "Chuyển": "Aistrigh",
  "Xác nhận mật khẩu": "Deimhnigh an focal faire",
  "Yêu cầu chuyển quyền chủ nhà": "Iarratas ar aistriú úinéireachta",
  "Đã gửi yêu cầu chuyển quyền": "Seoladh an t-iarratas aistrithe",
  "Đã gửi yêu cầu chuyển quyền chủ nhà":
      "Seoladh an t-iarratas ar aistriú úinéireachta",
  "Bạn không có quyền xoá thiết bị": "Níl cead agat gléasanna a scriosadh",
  "Xóa Device?": "Scrios an gléas seo?",
  "Đã gửi yêu cầu xoá thiết bị": "Seoladh iarratas chun an gléas a scriosadh",
  "Đang xoá thiết bị": "Gléas á scriosadh",
  "Đăng xuất?": "Logáil amach?",
  "Thêm nhà": "Cuir baile leis",
  "Thêm nhà mới": "Cuir baile nua leis",
  "Tạo nhà mới": "Cruthaigh baile nua",
  "Tạo một ngôi nhà mới của bạn": "Cruthaigh baile nua",
  "Quét mã QR được chủ nhà chia sẻ": "Scan an cód QR a roinn úinéir an bhaile",
  "Tên nhà": "Ainm an bhaile",
  "Số điện thoại": "Uimhir theileafóin",
  "Nam": "Fireann",
  "Nữ": "Baineann",
  "Ngày": "Lá",
  "Tháng": "Mí",
  "Năm": "Bliain",
  "Thông tin cá nhân": "Eolas pearsanta",
  "Thiết lập tài khoản": "Socraigh an cuntas",
  "Vui lòng nhập đủ thông tin": "Cuir isteach an t-eolas riachtanach ar fad",
  "Không thể lưu thông tin": "Níorbh fhéidir an t-eolas a shábháil",
  "Đã lưu thông tin": "Sábháladh an t-eolas",
  "Lỗi lưu profile": "Níorbh fhéidir an phróifíl a shábháil",
  "Thêm số điện thoại để dùng cho các trường hợp khẩn cấp":
      "Cuir uimhir theileafóin leis le haghaidh éigeandálaí",
  "Hoàn tất": "Déanta",
  "Đã tạo nhà mới": "Cruthaíodh an baile",
  "Về muộn": "Ag teacht abhaile go déanach",
  "Ra ngoài": "Ag dul amach",
  "Khác": "Eile",
  "⏸️ Tạm tắt báo động hôm nay": "⏸️ Cuir an t-aláram ar sos inniu",
  "Chọn giờ bắt đầu tạm tắt": "Roghnaigh am tosaithe an tsosa",
  "Từ": "Ó",
  "Từ giờ": "Ó",
  "Chọn giờ kết thúc tạm tắt": "Roghnaigh am críochnaithe an tsosa",
  "Đến": "Go",
  "Đến giờ": "Go dtí",
  "Xoá lịch tạm tắt": "Scrios sceideal an tsosa",
  "Xóa lịch tạm tắt": "Scrios sceideal an tsosa",
  "Giới tính": "Inscne",
  "SĐT": "Fón",
  "Ngày sinh": "Dáta breithe",
  "Yêu cầu & lời mời": "Iarratais agus cuirí",
  "Xem lời mời chia sẻ và xin gia nhập":
      "Féach ar chuirí comhroinnte agus iarratais chun dul isteach",
  "Cài đặt bảo mật": "Socruithe slándála",
  "Quyền báo động toàn màn hình": "Cead aláraim lánscáileáin",
  "Báo động toàn màn hình": "Aláram lánscáileáin",
  "Đã được cấp quyền": "Cead tugtha",
  "Chưa được cấp quyền": "Cead gan tabhairt",
  "Mở cài đặt hệ thống": "Oscail socruithe an chórais",
  "Đăng xuất": "Logáil amach",
  "Thoát tài khoản khỏi thiết bị này": "Logáil amach ón ngléas seo",
  "Không có yêu cầu hoặc lời mời nào": "Níl aon iarratais ná cuirí",
  "Xoá tài khoản": "Scrios an cuntas",
  "Hành động này sẽ xoá toàn bộ dữ liệu:":
      "Scriosfaidh sé seo na sonraí go léir:",
  "Nhà và thiết bị": "Bailte agus gléasanna",
  "Chia sẻ và quyền truy cập": "Comhroinnt agus rochtain",
  "Toàn bộ dữ liệu liên quan": "Gach sonraí gaolmhara",
  "Mật khẩu xác nhận": "Focal faire deimhnithe",
  "Đã xoá tài khoản": "Scriosadh an cuntas",
  "Xoá thất bại": "Theip ar an scriosadh",
  "Lỗi xoá tài khoản": "Níorbh fhéidir an cuntas a scriosadh",
  "Tình trạng": "Stádas",
  "Tháo/Lắp": "Cur isteach",
  "Pin": "Ceallra",
  "Tín hiệu": "Comhartha",
  "Chưa liên kết": "Gan nasc",
  "Liên lạc cuối": "Teagmháil dheireanach",
  "Event cuối": "Imeacht deireanach",
  "Sự kiện cuối": "Imeacht deireanach",
  "Lần kích hoạt cuối": "Gníomhachtaithe an uair dheireanach",
  "Thiết bị không còn tồn tại": "Níl an gléas ann a thuilleadh",
  "Mất kết nối": "Dícheangailte",
  "Online": "Ar líne",
  "Offline": "As líne",
  "Loại thiết bị": "Cineál gléis",
  "Nhiệt độ": "Teocht",
  "Độ ẩm": "Taise",
  "Công suất": "Cumhacht",
  "Điện áp": "Voltas",
  "Dòng điện": "Sruth",
  "Điện năng": "Fuinneamh",
  "Cường độ rung": "Neart creatha",
  "Góc nghiêng": "Uillinn chlaonta",
  "Độ mở van": "Oscailt na comhla",
  "Nguồn dự phòng": "Cumhacht chúltaca",
  "Ngập/rò nước": "Sceitheadh uisce",
  "Phát hiện khói": "Braitheadh deatach",
  "Quản lý phòng": "Bainistíocht seomraí",
  "Bạn không có quyền quản lý phòng": "Níl cead agat seomraí a bhainistiú",
  "Đổi tên phòng": "Athainmnigh an seomra",
  "Tên phòng": "Ainm an tseomra",
  "Xoá phòng": "Scrios an seomra",
  "Thiết bị trong phòng này sẽ được chuyển về Chưa phân phòng.":
      "Bogfar na gléasanna sa seomra seo go Neamhshannta.",
  "Thêm phòng": "Cuir seomra leis",
  "Ví dụ: Phòng khách": "Sampla: Seomra suí",
  "Phòng khách": "Seomra suí",
  "Tên phòng đã tồn tại": "Tá ainm an tseomra ann cheana",
  "Chưa phân phòng": "Neamhshannta",
  "Phòng mặc định": "Seomra réamhshocraithe",
  "Phát hiện bất thường": "Braitheadh gníomhaíocht neamhghnách",
  "Phát hiện cạy phá": "Braitheadh gníomhaíocht neamhghnách",
  "Tamper detected": "Braitheadh cur isteach",
  "Tamper cleared": "Glanadh an foláireamh cur isteach",
  "Door opened": "Tá an doras oscailte",
  "Door closed": "Doras dúnta",
  "Motion detected": "Braitheadh gluaiseacht",
  "Battery low": "Ceallra íseal",
  "Device offline": "Tá an gléas as líne",
  "Device online": "Tá an gléas ar líne",
  "Cửa mở": "Tá an doras oscailte",
  "Cửa đóng": "Doras dúnta",
  "Chưa đặt vị trí nhà": "Níl suíomh an bhaile socraithe",
  "Đặt vị trí nhà tại đây": "Socraigh suíomh an bhaile anseo",
  "Hãy đặt vị trí nhà trước khi bật tự động Bảo vệ":
      "Socraigh suíomh an bhaile sula gcuirtear cosaint uathoibríoch ar siúl",
  "Bán kính bảo vệ mặc định: 150 m": "Ga cosanta réamhshocraithe: 150 m",
  "Mỗi thành viên sẽ cần cấp quyền vị trí Luôn cho phép để trạng thái rời/đến nhà hoạt động khi ứng dụng chạy nền.":
      "Caithfidh gach ball cead suímh i gcónaí a thabhairt ionas gur féidir le stádas as baile/sa bhaile oibriú sa chúlra.",
  "Lưu cài đặt": "Sábháil socruithe",
  "Đã đặt vị trí nhà": "Suíomh an bhaile socraithe",
  "Đang lấy vị trí...": "Suíomh á fháil...",
  "Đang lưu...": "Á shábháil...",
  "Đổi tên hiển thị": "Athraigh an t-ainm taispeána",
  "Cập nhật thông tin nhà": "Nuashonraigh eolas an bhaile",
  "Nhập địa chỉ của nhà": "Cuir isteach seoladh an bhaile",
  "Lưu thay đổi": "Sábháil na hathruithe",
  "Tên này chỉ hiển thị riêng trên tài khoản của bạn.":
      "Ní thaispeántar an t-ainm seo ach ar do chuntas.",
  "Tên và địa chỉ sẽ được cập nhật cho toàn bộ thành viên trong nhà.":
      "Nuashonrófar an t-ainm agus an seoladh do bhaill uile an bhaile.",
  "Một thành viên": "Ball",
  "Đã cập nhật thông tin nhà": "Nuashonraíodh eolas an bhaile",
  "Thay tên": "Athainmnigh",
  "Đã đổi tên thiết bị": "Athainmníodh an gléas",
  "Chưa chọn nhà để kiểm tra": "Roghnaigh baile le tástáil",
  "Hãy thực hiện kiểm tra bằng tài khoản Owner":
      "Rith an tástáil seo le cuntas an úinéara",
  "Không đọc được dữ liệu nhà": "Ní féidir sonraí an bhaile a léamh",
  "Nhà cần có ít nhất một thiết bị để test":
      "Ní mór gléas amháin ar a laghad a bheith sa bhaile le haghaidh tástála",
  "Đóng": "Dún",
  "Đã thiết lập": "Socraigh",
  "Quét QR": "Scan cód QR",
  "Quét QR để thêm thiết bị": "Scan cód QR chun gléas a chur leis",
  "Nhập HUB ID thủ công": "Cuir ID an HUB isteach de láimh",
  "Bạn không có quyền sắp xếp phòng": "Níl cead agat seomraí a athordú",
  "Cảnh báo khói": "Foláireamh deataigh",
  "Cập nhật thiết bị": "Nuashonrú gléis",
  "Cửa đang mở": "Tá an doras oscailte",
  "Cửa đã đóng": "Doras dúnta",
  "Firebase Rules: CÓ LỖI": "Rialacha Firebase: FUARADH FADHBANNA",
  "Firebase Rules: ĐẠT": "Rialacha Firebase: RITHE",
  "Giờ không hợp lệ": "Am neamhbhailí",
  "Khôi phục mật khẩu": "Athshocraigh an focal faire",
  "Nhập email của bạn": "Cuir isteach do ríomhphost",
  "Gửi": "Seol",
  "Đã gửi email khôi phục": "Seoladh ríomhphost athshocraithe focal faire",
  "Không gửi được email": "Níorbh fhéidir an ríomhphost a sheoladh",
  "Vui lòng nhập email và mật khẩu":
      "Cuir isteach do ríomhphost agus focal faire",
  "Mật khẩu xác nhận không khớp": "Ní mheaitseálann na focail faire",
  "Không thể tạo tài khoản": "Níorbh fhéidir an cuntas a chruthú",
  "Sai tài khoản": "Cuntas mícheart",
  "Email đã tồn tại": "Tá an ríomhphost ann cheana",
  "Mật khẩu quá yếu": "Tá an focal faire rólag",
  "Sai email hoặc mật khẩu": "Ríomhphost nó focal faire mícheart",
  "Lỗi đăng nhập": "Earráid logála isteach",
  "Email": "Ríomhphost",
  "Mật khẩu": "Focal faire",
  "Ghi nhớ tài khoản": "Cuimhnigh ar an gcuntas",
  "Đăng nhập": "Logáil isteach",
  "Đăng ký mới": "Cruthaigh cuntas",
  "Quên mật khẩu?": "An ndearna tú dearmad ar an bhfocal faire?",
  "Chưa có tài khoản? Đăng ký": "Níl cuntas agat? Cláraigh",
  "Đã có tài khoản? Đăng nhập": "Tá cuntas agat cheana? Logáil isteach",
  "Tính năng đang được phát triển": "Tá an ghné seo á forbairt",
  "Thông báo": "Fógra",
  "Chat trong nhà": "Comhrá baile",
  "Tìm kiếm tin nhắn": "Cuardaigh teachtaireachtaí",
  "Xem thành viên": "Féach ar bhaill",
  "Tìm nội dung hoặc tên người gửi": "Cuardaigh ábhar nó ainm an tseoltóra",
  "Xoá từ khoá": "Glan an eochairfhocal",
  "Không có kết quả": "Níl aon torthaí",
  "Tìm ngôn ngữ": "Cuardaigh teanga",
  "Kết quả trước": "Toradh roimhe seo",
  "Kết quả tiếp theo": "An chéad toradh eile",
  "Chưa có tin nhắn": "Níl aon teachtaireachtaí fós",
  "Không tìm thấy thành viên phù hợp": "Níor aimsíodh baill mheaitseála",
  "Nhắc đến trong tin nhắn": "Luaigh sa teachtaireacht",
  "Huỷ trả lời": "Cealaigh an freagra",
  "Nhắn gì đó...": "Clóscríobh teachtaireacht...",
  "Gọi điện": "Glaoigh",
  "Báo động thiết bị": "Aláram gléis",
  "Chế độ áp dụng": "Cuir an mód i bhfeidhm",
  "Theo nhà": "Sceideal baile",
  "Riêng tôi": "Pearsanta",
  "Dùng lịch chung do Chủ nhà hoặc Quản trị viên thiết lập":
      "Úsáid an sceideal comhroinnte a shocraigh an t-úinéir nó an riarthóir",
  "Dùng lịch riêng chỉ áp dụng cho tài khoản của bạn":
      "Úsáid sceideal pearsanta nach mbaineann ach le do chuntas",
  "Thiết lập nhanh báo động": "Socrú tapa aláraim",
  "Thiết lập nhanh toàn bộ thiết bị": "Socraigh gach gléas go tapa",
  "Áp dụng cho toàn bộ thiết bị": "Cuir i bhfeidhm ar gach gléas",
  "Bắt đầu": "Tús",
  "Kết thúc": "Deireadh",
  "Thời gian lặp lại": "Eatramh athdhéanta",
  "Không lặp lại": "Ná hathdhéan",
  "Quét QR HUB": "Scan cód QR an HUB",
  "Đưa mã QR vào giữa khung": "Cuir an cód QR laistigh den fhráma",
  "Đang áp dụng...": "Á chur i bhfeidhm...",
  "Hôm nay đã ghi nhận cảnh báo SOS": "Taifeadadh foláireamh SOS inniu",
  "Hôm nay đã ghi nhận cảnh báo khói": "Taifeadadh foláireamh deataigh inniu",
  "Khói đã an toàn": "Tá an staid deataigh glanta",
  "Không tìm thấy nhà của thông báo này":
      "Níor aimsíodh an baile don fhógra seo",
  "Không tìm thấy thiết bị trong nhà này":
      "Níor aimsíodh an gléas sa bhaile seo",
  "Một chủ nhà": "Úinéir baile",
  "Ngôi nhà đang hoạt động ổn định": "Tá an baile ag feidhmiú de ghnáth",
  "Nhiệt độ cao": "Teocht ard",
  "OK": "Ceart go leor",
  "Pin yếu": "Cadhnra íseal",
  "SOS đã kết thúc": "Tá an SOS glanta",
  "SOS được kích hoạt": "SOS gníomhachtaithe",
  "Tamper bình thường": "Tá an cur isteach glanta",
  "Thiết bị bị tháo": "Braitheadh cur isteach",
  "Thiết bị mới": "Gléas nua",
  "Thiết bị offline": "Tá an gléas as líne",
  "Thiết bị online": "Tá an gléas ar líne",
  "Báo động kích hoạt": "Spreagadh an t-aláram",
  "Báo động đã tắt": "Tá an t-aláram múchta",
  "Tạm tắt báo động hôm nay": "Cuir an t-aláram ar sos don lá inniu",
  "Độ ẩm cao": "Taise ard",
  "Thử lại": "Bain triail eile as",
  "Không thể tải dữ liệu tài khoản":
      "Níorbh fhéidir sonraí an chuntais a lódáil",
  "Không": "Níl",
  "Đã chia sẻ nhà thành công.": "Comhroinneadh na bailte go rathúil.",
  "Tìm nhà...": "Cuardaigh bailte...",
  "Đã rời khỏi nhà": "D'fhág tú an baile",
  "Bạn sẽ rời khỏi các nhà được chia sẻ.": "Fágfaidh tú na bailte comhroinnte.",
  "Các nhà của bạn sẽ bị xoá.\n": "Scriosfar do bhailte.\n",
  "Thao tác này sẽ thay đổi lịch báo động của toàn bộ thiết bị an ninh trong các nhà đã chọn.\n\n":
      "Athróidh sé seo sceidil Aláraim Baile do gach gléas slándála sna bailte roghnaithe.\n\n",
  "Thao tác này sẽ thêm nhắc nhở cho các nhà đã chọn.\n\n":
      "Cuirfidh sé seo Meabhrúchán Baile leis na bailte roghnaithe.\n\n",
  "Xác nhận thay đổi báo động": "Deimhnigh athruithe aláraim",
  "Xác nhận thay đổi nhắc nhở": "Deimhnigh athruithe meabhrúcháin",
  "Lặp lại khi sự cố vẫn còn": "Athdhéan fad a mhaireann an fhadhb",
  "Thời gian lặp lại báo động": "Am athdhéanta an aláraim",
  "VD: Mr Chung": "M.sh. An tUasal Chung",
  "🏡 Chưa có nhà nào": "🏡 Níl aon bhaile fós",
  "Vẫn chuyển về Bình thường": "Athraigh go Gnáth mar sin féin",
  "Tự động Bảo vệ khi rời nhà vẫn đang bật. Nếu mọi thành viên vẫn ở ngoài, hệ thống có thể tự bật lại Bảo vệ sau vài phút.":
      "Tá Mód Cosanta Uathoibríoch agus tú as baile fós cumasaithe. Má tá gach ball fós as baile, féadfaidh an córas Mód Cosanta a chur ar siúl arís tar éis cúpla nóiméad.",
  "Chuyển về Bình thường?": "Athrú go Gnáth?",
  "Khi bật, các thiết bị an ninh sẽ được giám sát ngay.\n\n":
      "Déanfar monatóireacht láithreach ar ghléasanna slándála.\n\n",
  "Bật Bảo vệ thủ công?": "Cuir Mód Cosanta láimhe ar siúl?",
  "Hành động này sẽ thay đổi thời gian báo động của một số thiết bị ":
      "Athróidh an gníomh seo am aláraim roinnt gléasanna inniu...",
  "Hành động này sẽ tắt toàn bộ báo động của nhà ":
      "Díchumasóidh an gníomh seo gach Aláram don ",
  "Tắt toàn bộ báo động?": "Gach Aláram a mhúchadh?",
  "Không xoá được lịch tạm tắt báo động":
      "Níorbh fhéidir sceideal sos an aláraim a scriosadh",
  "Không lưu được tạm tắt báo động": "Níorbh fhéidir sos an aláraim a shábháil",
  "Không gửi được yêu cầu xoá":
      "Níorbh fhéidir an t-iarratas scriosta a sheoladh",
  "Không lưu được cài đặt": "Níorbh fhéidir an socrú a shábháil",
  "Không lấy được vị trí hiện tại": "Níorbh fhéidir an suíomh reatha a fháil",
  "Không thể xác nhận tài khoản hiện tại":
      "Níorbh fhéidir an cuntas reatha a fhíorú",
  "Mật khẩu không đúng": "Focal faire mícheart",
  "Không thể xác nhận mật khẩu": "Níorbh fhéidir an focal faire a fhíorú",
  "Chỉ Chủ nhà hoặc Quản trị viên mới có quyền thay đổi lặp báo động":
      "Ní féidir ach leis an Úinéir nó le Riarthóir socrú athdhéanta an aláraim a athrú",
  "Không lưu được thời gian lặp báo động":
      "Níorbh fhéidir am athdhéanta an aláraim a shábháil",
  "Chỉ Chủ nhà hoặc Quản trị viên mới có quyền thay đổi Chế độ Bảo vệ":
      "Ní féidir ach leis an Úinéir nó le Riarthóir Mód Cosanta a athrú",
  "Không thể thay đổi chế độ nhà": "Níorbh fhéidir mód an bhaile a athrú",
  "Đã bật Bảo vệ nhưng chưa gửi được thông báo":
      "Tá Mód Cosanta ar siúl, ach níorbh fhéidir an fógra a sheoladh",
  "Đã bật Chế độ Bảo vệ thủ công": "Mód Cosanta láimhe cumasaithe",
  "Đã chuyển nhà về Bình thường": "Athraíodh an baile ar ais go Gnáth",
  "60 phút": "60 nóiméad",
  "30 phút": "30 nóiméad",
  "15 phút": "15 nóiméad",
  "Bạn đang xem lịch của chủ nhà. Chọn Riêng tôi để tự đặt lịch báo động.":
      "Tá tú ag féachaint ar sceideal an úinéara. Roghnaigh Mise amháin chun do sceideal Aláraim féin a shocrú.",
  "Chọn giờ kết thúc báo động": "Roghnaigh am deiridh an Aláraim",
  "Chọn giờ bắt đầu báo động": "Roghnaigh am tosaithe an Aláraim",
  "Bạn không có quyền sửa lịch báo động của nhà":
      "Níl cead agat sceideal Aláraim an bhaile seo a chur in eagar",
  "Không thể áp dụng báo động cho toàn bộ thiết bị":
      "Níorbh fhéidir an tAláram a chur i bhfeidhm ar gach gléas",
  "Nhà chưa có thiết bị an ninh để áp dụng":
      "Níl aon ghléasanna slándála sa bhaile seo lena chur i bhfeidhm orthu",
  "Bạn không có quyền sửa lịch Theo nhà. Hãy chọn Riêng tôi.":
      "Níl cead agat socruithe an bhaile a chur in eagar. Roghnaigh Mise amháin.",
  "Không thể lưu chế độ báo động": "Níorbh fhéidir mód an Aláraim a shábháil",
  "Thêm nhắc nhở": "Cuir meabhrúchán leis",
  "Nhắc nhở sẽ nhắc bạn kiểm tra trạng thái an toàn của ngôi nhà vào giờ đã chọn.":
      "Meabhróidh an meabhrúchán duit stádas sábháilteachta do bhaile a sheiceáil ag an am roghnaithe.",
  "Thêm khung giờ báo động": "Cuir fuinneog ama Aláraim leis",
  "Đang sử dụng nhắc nhở riêng của bạn":
      "Do shocruithe Meabhrúcháin féin á n-úsáid",
  "Đang sử dụng nhắc nhở của chủ nhà":
      "Socruithe Meabhrúcháin an úinéara á n-úsáid",
  "Sửa giờ nhắc nhở": "Cuir am an mheabhrúcháin in eagar",
  "Sửa giờ kết thúc báo động": "Cuir am deiridh an Aláraim in eagar",
  "Sửa giờ bắt đầu báo động": "Cuir am tosaithe an Aláraim in eagar",
  "Xoá nhắc nhở": "Scrios an meabhrúchán",
  "Mỗi 1 giờ": "Gach uair an chloig",
  "Mỗi 30 phút": "Gach 30 nóiméad",
  "Mỗi 15 phút": "Gach 15 nóiméad",
  "Không báo lại": "Ná hathdhéan",
  "Báo lại khi vẫn chưa an toàn": "Athdhéan fad atá sé fós neamhshábháilte",
  "Báo lại mỗi 1 giờ": "Athdhéan gach uair an chloig",
  "Báo lại mỗi 30 phút": "Athdhéan gach 30 nóiméad",
  "Báo lại mỗi 15 phút": "Athdhéan gach 15 nóiméad",
  "Quản lý nhà": "Bainistíocht baile",
  "Xoá thành viên": "Bain ball",
  "Đã xoá thành viên": "Baineadh an ball",
  "Đồng ý": "Ceart go leor",
  "Bạn chắc chắn muốn rời khỏi nhà này?":
      "An bhfuil tú cinnte gur mhaith leat an baile seo a fhágáil?",
  "Xoá thành viên?": "Bain an ball?",
  "Rời khỏi nhà?": "Fág an baile seo?",
  "Chỉ chủ nhà mới được thay đổi vai trò":
      "Ní féidir ach leis an úinéir róil a athrú",
  "Bạn không có quyền xoá thành viên này": "Níl cead agat an ball seo a bhaint",
  "Bạn": "Tusa",
  "Không có email": "Gan ríomhphost",
  "Chưa có số điện thoại": "Gan uimhir theileafóin",
  "Không mở được ứng dụng gọi điện": "Níorbh fhéidir an aip ghutháin a oscailt",
  "Thành viên chưa cập nhật số điện thoại":
      "Níor chuir an ball seo uimhir theileafóin leis",
  "Bảo vệ thủ công đang bật - chỉ tắt khi chuyển về Bình thường":
      "Tá Mód Cosanta láimhe ar siúl — athraigh go Gnáth chun é a mhúchadh",
  "Thời gian lặp": "Eatramh athdhéanta",
  "Chọn 0 để chỉ báo một lần. Cài đặt này dùng cho cả Bảo vệ thủ công và Tự động Bảo vệ khi rời nhà.":
      "Roghnaigh 0 chun foláireamh a thabhairt uair amháin. Baineann an socrú seo le Mód Cosanta láimhe agus Mód Cosanta Uathoibríoch agus tú as baile.",
  "Lặp báo động khi sự cố vẫn còn":
      "Athdhéan an tAláram fad a mhaireann an fhadhb",
  "Đang được sử dụng": "Gníomhach faoi láthair",
  "Chuyển về sử dụng thông thường": "Athraigh ar ais go gnáthúsáid",
  "Chế độ nhà": "Mód baile",
  "Thiết bị SOS chưa ghi nhận cảnh báo.":
      "Níor thaifead an gléas SOS foláireamh.",
  "Cảm biến khói chưa ghi nhận bất thường.":
      "Níor bhraith an braiteoir deataigh fadhb.",
  "Bạn hoặc thành viên đã chủ động bật Bảo vệ.":
      "Chuir tusa nó ball Mód Cosanta ar siúl de láimh.",
  "SafeHome tự bật Bảo vệ vì bạn đã rời khỏi nhà.":
      "Chuir SafeHome Mód Cosanta ar siúl go huathoibríoch mar d'fhág tú an baile.",
  "Nhà đang ở chế độ dùng bình thường.":
      "Tá an baile seo á úsáid de ghnáth faoi láthair.",
  "Bảo vệ thủ công đang bật": "Tá Mód Cosanta láimhe ar siúl",
  "Bảo vệ tự động đang bật": "Tá Mód Cosanta Uathoibríoch ar siúl",
  "Bảo vệ đang tắt": "Tá Mód Cosanta múchta",
  "Bạn đã mở ứng dụng gần đây để kiểm tra trạng thái.":
      "D'oscail tú an aip le déanaí chun an stádas a sheiceáil.",
  "Bạn nên mở ứng dụng định kỳ để kiểm tra quyền, lịch và cảnh báo chưa đọc.":
      "Oscail an aip go rialta chun ceadanna, sceidil agus foláirimh neamhléite a athbhreithniú.",
  "Sau vài lần sử dụng, SafeHome sẽ đánh giá thói quen kiểm tra ứng dụng tốt hơn.":
      "Tar éis cúpla seisiún, beidh SafeHome in ann do nós seiceála aipe a mheas níos fearr.",
  "Tần suất vào ứng dụng ổn": "Tá minicíocht seiceála na haipe go maith",
  "Đã lâu chưa vào ứng dụng kiểm tra":
      "Tá tamall caite ón seiceáil dheireanach ar an aip",
  "Đang ghi nhận tần suất vào ứng dụng":
      "Tá minicíocht seiceála na haipe á taifeadadh",
  "Cần kiểm tra quyền vị trí luôn luôn và điều kiện chạy nền.":
      "Seiceáil an cead suímh I gcónaí agus na coinníollacha reatha sa chúlra.",
  "Thiết bị đủ điều kiện để Auto rời khỏi nhà hoạt động.":
      "Comhlíonann an gléas seo na riachtanais don Chosaint Uathoibríoch agus tú as baile.",
  "Bạn có thể bật khi muốn tự động chuyển Bảo vệ lúc rời nhà.":
      "Cumasaigh é más mian leat go gcuirfí Mód Cosanta ar siúl go huathoibríoch nuair a fhágann tú.",
  "Auto rời khỏi nhà chưa ổn":
      "Níl an Chosaint Uathoibríoch agus tú as baile réidh",
  "Auto rời khỏi nhà đã sẵn sàng":
      "Tá an Chosaint Uathoibríoch agus tú as baile réidh",
  "Auto rời khỏi nhà chưa bật":
      "Níl an Chosaint Uathoibríoch agus tú as baile cumasaithe",
  "Nên thêm báo khói, SOS hoặc thiết bị khẩn cấp phù hợp với nhà.":
      "Cuir braiteoir deataigh, gléas SOS nó gléas éigeandála atá oiriúnach do do bhaile leis.",
  "Chưa có thiết bị khẩn cấp": "Níl aon ghléas éigeandála fós",
  "Đã có thiết bị khẩn cấp": "Tá gléasanna éigeandála curtha leis",
  "Nên đặt lịch báo động cho thời gian ngủ hoặc vắng nhà.":
      "Socraigh sceideal Aláraim don am codlata nó nuair atá tú as baile.",
  "Nhà đã có lịch báo động hoặc lịch cảnh báo theo thiết bị.":
      "Tá sceideal Aláraim nó sceideal foláirimh ar leibhéal gléis ag an mbaile seo.",
  "Chưa cài lịch báo động": "Níl sceideal Aláraim socraithe",
  "Đã cài lịch báo động": "Tá sceideal Aláraim socraithe",
  "Nên có ít nhất một nhắc nhở để không quên kiểm tra nhà.":
      "Socraigh Meabhrúchán amháin ar a laghad ionas nach ndéanfaidh tú dearmad do bhaile a sheiceáil.",
  "Ứng dụng sẽ nhắc bạn kiểm tra nhà theo lịch đã đặt.":
      "Meabhróidh an aip duit do bhaile a sheiceáil de réir an sceidil.",
  "Chưa cài đặt nhắc nhở": "Níl Meabhrúchán socraithe",
  "Đã cài đặt nhắc nhở": "Tá Meabhrúchán socraithe",
  "Hãy mở lại ứng dụng hoặc đăng nhập lại nếu thiết bị không nhận cảnh báo.":
      "Oscail an aip arís nó logáil isteach arís mura bhfaigheann an gléas seo foláirimh.",
  "Thiết bị chưa đăng ký nhận cảnh báo":
      "Níl an gléas seo cláraithe chun foláirimh a fháil",
  "Thiết bị nhận cảnh báo bình thường":
      "Is féidir leis an ngléas seo foláirimh a fháil",
  "iOS quản lý chạy nền chặt hơn Android; hãy giữ thông báo và vị trí luôn luôn nếu dùng Auto rời khỏi nhà.":
      "Rialaíonn iOS úsáid sa chúlra níos doichte ná Android; coinnigh fógraí agus suíomh I gcónaí ar siúl má úsáideann tú Cosaint Uathoibríoch agus tú as baile.",
  "Cơ chế iOS": "Iompar iOS",
  "Hãy kiểm tra quyền chạy nền và tự khởi động để cảnh báo không bị trễ.":
      "Seiceáil cead reatha sa chúlra agus uath-thosú ionas nach gcuirfear moill ar fholáirimh.",
  "Thiết bị đã xác nhận các điều kiện chạy nền quan trọng.":
      "Tá na coinníollacha tábhachtacha sa chúlra deimhnithe ag an ngléas.",
  "Cần kiểm tra chạy nền / tự khởi động":
      "Seiceáil úsáid sa chúlra / uath-thosú",
  "Chạy nền ổn định": "Tá úsáid sa chúlra cobhsaí",
  "Một số máy Android có thể trì hoãn cảnh báo nếu tối ưu pin còn bật.":
      "D'fhéadfadh roinnt fóin Android moill a chur ar fholáirimh agus barrfheabhsú cadhnra ar siúl.",
  "Điện thoại ít có khả năng trì hoãn cảnh báo SafeHome.":
      "Is lú an seans go gcuirfidh an fón moill ar fholáirimh SafeHome.",
  "Chưa tắt tối ưu pin": "Tá barrfheabhsú cadhnra fós cumasaithe",
  "Tối ưu pin không chặn ứng dụng":
      "Níl barrfheabhsú cadhnra ag cur bac ar an aip",
  "Auto rời khỏi nhà cần quyền vị trí luôn luôn để chạy ổn định.":
      "Teastaíonn cead suímh I gcónaí chun go n-oibreoidh an Chosaint Uathoibríoch agus tú as baile go hiontaofa.",
  "Cần cấp quyền vị trí để Auto rời khỏi nhà hoạt động.":
      "Tá cead suímh ag teastáil don Chosaint Uathoibríoch agus tú as baile.",
  "Dịch vụ vị trí đang tắt nên Auto rời khỏi nhà không ổn định.":
      "Tá an tseirbhís suímh múchta, mar sin seans nach n-oibreoidh an Chosaint Uathoibríoch agus tú as baile go hiontaofa.",
  "Chỉ cần quyền này khi dùng Auto rời khỏi nhà.":
      "Ní theastaíonn sé seo ach nuair a úsáidtear Cosaint Uathoibríoch agus tú as baile.",
  "Chưa cấp vị trí luôn luôn": "Níl suíomh I gcónaí ceadaithe",
  "Đã cấp vị trí luôn luôn": "Tá suíomh I gcónaí ceadaithe",
  "iOS không mở toàn màn hình như Android; ứng dụng dùng thông báo và âm thanh hệ thống.":
      "Ní osclaíonn iOS lánscáileán cosúil le Android; úsáideann an aip fógraí córais agus fuaim.",
  "Android dùng cảnh báo toàn màn hình; nếu máy chặn, hãy cấp quyền trong cài đặt.":
      "Úsáideann Android foláirimh lánscáileáin; ceadaigh iad sna socruithe má chuireann an fón bac orthu.",
  "Cảnh báo trên iOS": "Foláirimh ar iOS",
  "Cảnh báo toàn màn hình": "Foláirimh lánscáileáin",
  "Cảnh báo có thể không hiển thị nếu thông báo bị tắt.":
      "Seans nach dtaispeánfar foláirimh má tá fógraí díchumasaithe.",
  "Điện thoại có thể nhận thông báo SafeHome.":
      "Is féidir leis an bhfón seo fógraí SafeHome a fháil.",
  "Chưa bật thông báo": "Níl fógraí cumasaithe",
  "Đã bật thông báo": "Tá fógraí cumasaithe",
  "Hệ thống: Sẵn sàng": "Córas: Réidh",
  "Hệ thống: Có thể bỏ lỡ cảnh báo": "Córas: Seans go gcaillfear foláirimh",
  "Cách bạn đang dùng ứng dụng": "Conas a úsáideann tú an aip",
  "Thiết bị của bạn": "Do ghléas",
  "Kiểm tra điện thoại và cách bạn đang dùng ứng dụng.":
      "Seiceálann sé do ghuthán agus an chaoi a n-úsáideann tú an aip.",
  "Hệ thống SafeHome": "Córas SafeHome",
  "Hệ thống: Đang kiểm tra...": "Córas: Á sheiceáil...",
  "Tên": "Ainm",
  "Bạn không có quyền thay đổi vị trí nhà":
      "Níl cead agat suíomh an bhaile a athrú",
  "Hãy bật GPS để đặt vị trí nhà":
      "Cuir GPS ar siúl chun suíomh an bhaile a shocrú",
  "Bạn chưa cấp quyền vị trí": "Níor tugadh cead suímh",
  "Hãy cấp quyền vị trí trong Cài đặt ứng dụng":
      "Tabhair cead suímh i socruithe na haipe",
  "Đã bật tự động Bảo vệ khi mọi người rời nhà":
      "Tá Mód Cosanta Uathoibríoch nuair a fhágann gach duine an baile cumasaithe",
  "Đã tắt tự động Bảo vệ khi mọi người rời nhà":
      "Tá Mód Cosanta Uathoibríoch nuair a fhágann gach duine an baile díchumasaithe",
  "Không thể thay đổi trạng thái báo động":
      "Níorbh fhéidir stádas an Aláraim a athrú",
  "Đã tắt toàn bộ báo động của nhà": "Tá gach Aláram baile múchta",
  "QR này không phải mã xin gia nhập Home":
      "Ní cód chun dul isteach sa bhaile é an cód QR seo",
  "Thêm Home": "Cuir baile leis",
  "Mở cài đặt": "Oscail socruithe",
  "Để sau": "Níos déanaí",
  "SafeHome cần quyền vị trí \"Luôn cho phép\" để nhận biết khi bạn rời hoặc trở về nhà, kể cả khi ứng dụng đang chạy nền.":
      "Teastaíonn cead suímh I gcónaí ó SafeHome chun a bhrath cathain a fhágann tú nó a fhilleann tú abhaile, fiú agus an aip sa chúlra.",
  "SafeHome hiện chỉ được truy cập vị trí khi bạn đang sử dụng ứng dụng.\n\nHãy chọn quyền Vị trí và chuyển sang \"Luôn cho phép\" để tính năng tự động Bảo vệ khi rời nhà hoạt động khi ứng dụng đang chạy nền.":
      "Faoi láthair, ní féidir le SafeHome suíomh a rochtain ach agus an aip in úsáid.\n\nOscail an cead Suímh agus roghnaigh “Ceadaigh an t-am ar fad” ionas go leanfaidh cosaint uathoibríoch ag obair sa chúlra.",
  "Cho phép vị trí luôn luôn": "Ceadaigh suíomh i gcónaí",
  "Các nhà của bạn sẽ bị xoá.\nCác nhà được chia sẻ sẽ được rời khỏi.":
      "Scriosfar do bhailte.\nFágfaidh tú na bailte comhroinnte.",
  "Thao tác này sẽ thay đổi lịch báo động của toàn bộ thiết bị an ninh trong các nhà đã chọn.\n\nNhững thành viên đang sử dụng báo động 'Theo nhà' sẽ bị ảnh hưởng.\nBáo động cá nhân ở chế độ 'Riêng tôi' sẽ không bị thay đổi.":
      "Athróidh sé seo sceidil Aláraim Baile do gach gléas slándála sna bailte roghnaithe.\n\nBeidh tionchar aige ar bhaill a úsáideann socruithe Aláraim Baile.\nNí athrófar socruithe Aláraim phearsanta.",
  "Thao tác này sẽ thêm nhắc nhở cho các nhà đã chọn.\n\nNhững thành viên đang sử dụng nhắc nhở 'Theo nhà' sẽ bị ảnh hưởng.\nNhắc nhở cá nhân ở chế độ 'Riêng tôi' sẽ không bị thay đổi.":
      "Cuirfidh sé seo Meabhrúchán Baile leis na bailte roghnaithe.\n\nBeidh tionchar aige ar bhaill a úsáideann socruithe Meabhrúcháin Baile.\nNí athrófar socruithe Meabhrúcháin phearsanta.",
  "Khi bật, các thiết bị an ninh sẽ được giám sát ngay.\n\nTự động Bảo vệ khi rời nhà sẽ tạm dừng. Chế độ này không tự tắt khi có người về nhà và chỉ được tắt khi một thành viên có quyền chủ động chuyển về Bình thường.":
      "Déanfar monatóireacht láithreach ar ghléasanna slándála.\n\nCuirfear Cosaint Uathoibríoch agus tú as baile ar sos. Ní mhúchann an mód seo go huathoibríoch nuair a thagann duine abhaile agus ní mór do bhall ceadaithe é a athrú ar ais go Gnáth.",
  "Hành động này sẽ thay đổi thời gian báo động của một số thiết bị trong hôm nay...":
      "Athróidh an gníomh seo am aláraim roinnt gléasanna inniu...",
  "Hành động này sẽ tắt toàn bộ báo động của nhà dưới mọi hình thức. Bạn sẽ không còn nhận được cảnh báo khi có nguy hiểm trên điện thoại nữa.":
      "Díchumasóidh an gníomh seo gach Aláram don bhaile seo. Ní bhfaighidh tú foláirimh chontúirte ar an bhfón seo a thuilleadh.",
  "Báo động đang sử dụng chế độ Theo nhà.\n\nBạn sẽ nhận cảnh báo theo lịch báo động chung do Chủ nhà hoặc Quản trị viên thiết lập.":
      "Tá an tAláram ag úsáid socruithe Baile.\n\nGheobhaidh tú foláirimh de réir na sceideal comhroinnte a chumraigh an t-úinéir nó riarthóir.",
  "Báo động đang sử dụng chế độ Riêng tôi.\n\nBạn sẽ nhận cảnh báo theo lịch báo động riêng đã thiết lập cho tài khoản này.":
      "Tá an tAláram ag úsáid Mo shocruithe.\n\nGheobhaidh tú foláirimh de réir sceidil phearsanta Aláraim an chuntais seo.",
  "Không thể đăng nhập bằng Google": "Níorbh fhéidir logáil isteach le Google",
  "Không đặt được mật khẩu": "Níorbh fhéidir an focal faire a shocrú",
  "Chấp nhận": "Glac",
  "Cho phép": "Ceadaigh",
  "Không thể chấp nhận lời mời. Vui lòng thử lại.":
      "Níorbh fhéidir glacadh leis an gcuireadh. Bain triail eile as.",
  "Không thể chấp nhận lời xin vào nhà. Vui lòng thử lại.":
      "Níorbh fhéidir glacadh leis an iarratas dul isteach. Bain triail eile as.",
  "Từ chối": "Diúltaigh",
  "Lời mời từ chủ nhà": "Cuireadh ón úinéir",
  "Nhận quyền chủ nhà": "Glac úinéireacht an bhaile",
  "Một người dùng SafeHome": "Úsáideoir SafeHome",
  "Lời mời gia nhập": "Cuireadh chun dul isteach",
  "Lời xin vào nhà": "Iarratas chun dul isteach sa bhaile",
  "Nhập HUB ID": "Cuir ID an HUB isteach",
  "VD: HUB_001": "Sampla: HUB_001",
  "Pair": "Péireáil",
  "Mật khẩu tối thiểu 6 ký tự":
      "Caithfidh 6 charachtar ar a laghad a bheith san fhocal faire",
  "Mật khẩu nhập lại không khớp": "Ní mheaitseálann na focail faire",
  "Tạo mật khẩu": "Cruthaigh focal faire",
  "Mật khẩu mới": "Focal faire nua",
  "Nhập lại mật khẩu": "Cuir an focal faire isteach arís",
  "Xác nhận tắt cảnh báo": "Deimhnigh stopadh an aláraim",
  "HỦY": "CEALAIGH",
  "XÁC NHẬN": "DEIMHNIGH",
  "CẦN KIỂM TRA": "NÍ MÓR SEICEÁIL",
  "KIỂM TRA NHÀ": "SEICEÁIL AN BAILE",
  "ĐÓNG NHẮC NHỞ": "DÚN AN MEABHRÚCHÁN",
  "SafeHome Security Alert": "Foláireamh Slándála SafeHome",
  "Hãy chọn quyền vị trí Luôn cho phép trong Cài đặt ứng dụng":
      "Roghnaigh cead suímh Ceadaigh i gcónaí i socruithe na haipe",
  "Tài khoản Google cần tạo thêm mật khẩu để dùng các chức năng bảo mật.":
      "Teastaíonn focal faire breise ó do chuntas Google chun gnéithe slándála a úsáid.",
  "Báo động": "Aláram",
  "Bạn không có quyền thực hiện thao tác này。":
      "Níl cead agat an gníomh seo a dhéanamh.",
  "Cài đặt": "Socruithe",
  "Cập nhật": "Nuashonraigh",
  "Chọn ngôn ngữ": "Roghnaigh teanga",
  "Chưa có dữ liệu thiết bị để đánh giá":
      "Níl sonraí gléis ar fáil don mheasúnú",
  "Chuyển quyền sở hữu cho thành viên khác":
      "Aistrigh úinéireacht chuig ball eile",
  "Có": "Tá",
  "Cửa đã đóng an toàn": "Tá an doras dúnta go sábháilte",
  "Đã xảy ra lỗi. Vui lòng thử lại.": "Tharla earráid. Bain triail eile as.",
  "Đang kiểm tra kết nối Hub": "Ceangal an Hub á sheiceáil",
  "Đang mở khi nhà ở chế độ Bảo vệ": "Oscailte agus an Baile i Mód Cosanta",
  "Đang mở trong giờ báo động": "Oscailte le linn uaireanta Aláraim",
  "Đang tải...": "Á lódáil...",
  "Hồ sơ, yêu cầu và lời mời tham gia": "Próifíl, iarratais agus cuirí",
  "Hub chưa gửi trạng thái": "Níl stádas an Hub ar fáil",
  "Hub mất kết nối": "Hub dícheangailte",
  "Hub tín hiệu bình thường": "Hub ceangailte",
  "Khóa đang mở khi nhà ở chế độ Bảo vệ":
      "Díghlasáilte agus an Baile i Mód Cosanta",
  "Khóa đang mở trong giờ báo động": "Díghlasáilte le linn uaireanta Aláraim",
  "Không có thông báo": "Níl aon fhógraí",
  "Khu vực nguy hiểm": "Limistéar contúirte",
  "Kiểm tra thiết bị trong nhà này": "Athbhreithnigh gléasanna an bhaile seo",
  "Mất điện lưới": "Cailleadh cumhacht an phríomhlíonra",
  "Mời người khác tham gia nhà này":
      "Tabhair cuireadh do dhuine dul isteach sa bhaile seo",
  "Môi trường hiện tại": "An timpeallacht reatha",
  "MQTT mất kết nối": "MQTT dícheangailte",
  "Ngôn ngữ": "Teanga",
  "Nhà đã chia sẻ": "Baile comhroinnte",
  "Nhà đang hoạt động bình thường": "Tá an baile ag feidhmiú de ghnáth",
  "Nhập email": "Cuir ríomhphost isteach",
  "Phòng": "Seomra",
  "Quản trị viên": "Riarthóir",
  "Nhắc nhở": "Meabhrúchán",
  "SafeHome": "SafeHome",
  "Sóng yếu": "Comhartha lag",
  "SOS": "SOS",
  "Tài khoản & hệ thống": "Cuntas agus córas",
  "Tài khoản cá nhân": "Cuntas pearsanta",
  "Tạo tài khoản": "Cruthaigh cuntas",
  "Thành viên": "Ball",
  "Thành viên trong nhà": "Baill an bhaile",
  "Thành viên đang ở trong nhà": "Baill atá sa bhaile faoi láthair",
  "Thành viên đang ở ngoài": "Baill atá as baile faoi láthair",
  "Thành viên chưa xác định vị trí": "Baill nach eol a suíomh",
  "Thay đổi ngôn ngữ hiển thị": "Athraigh teanga taispeána",
  "Thêm, đổi tên và sắp xếp phòng":
      "Cuir seomraí leis, athainmnigh agus atheagraigh iad",
  "Thiết bị đang được giám sát": "Tá monatóireacht á déanamh ar an ngléas",
  "Tiếng Anh": "Béarla",
  "Tiếng Hàn": "Cóiréis",
  "Tiếng Nhật": "Seapáinis",
  "Tiếng Trung": "Sínis",
  "Tiếng Việt": "Vítneaimis",
  "Toàn bộ thiết bị": "Gach gléas",
  "Vai trò": "Ról",
  "Về nhà": "Sa bhaile",
  "Xem và quản lý quyền thành viên": "Féach ar róil ball agus bainistigh iad",
  "Xóa": "Scrios",
  "Xóa nhà": "Scrios an baile",
  "Xoá toàn bộ dữ liệu và thiết bị": "Scrios gach sonra agus gléas",
  "TẮT CẢNH BÁO": "MÚCH AN FOLÁIREAMH",
  "Đã tạo nhà": "Baile cruthaithe",
  "Chế độ Bảo vệ thủ công đã bật": "Mód Cosanta láimhe cumasaithe",
  "Báo động không lặp lại.": "Ní athdhéanfar an t-aláram.",
  "Báo động lặp sau \$securityModeRepeatMinutes phút nếu sự cố vẫn còn.":
      "Má mhaireann an fhadhb, athdhéanfar an t-aláram tar éis \$securityModeRepeatMinutes nóiméad.",
  "\$actorName đã bật Chế độ Bảo vệ thủ công cho \"\$homeName\". Chế độ này chỉ tắt khi một thành viên có quyền chủ động chuyển về Bình thường. \$repeatMessage":
      "Chuir \$actorName Mód Cosanta láimhe ar siúl do “\$homeName”. Ní mhúchann an mód seo ach nuair a athraíonn ball ceadaithe ar ais go Gnáth. \$repeatMessage",
  "Bạn đã bật báo động cho nhà \"\$homeName\".":
      "Chuir tú Aláram ar siúl do “\$homeName”.",
  "Bạn đã tắt toàn bộ báo động của nhà \"\$homeName\".":
      "Mhúch tú gach Aláram do “\$homeName”.",
  "Thành viên mới": "Ball nua",
  "Thành viên rời nhà": "D'fhág ball an baile",
  "\$displayMemberName đã rời khỏi nhà \"\$homeName\".":
      "D'fhág \$displayMemberName “\$homeName”.",
  "\$actorName đã đổi vai trò của \$memberName từ \$oldRoleName thành \$newRoleName trong nhà \"\$homeName\".":
      "D'athraigh \$actorName ról \$memberName ó \$oldRoleName go \$newRoleName in “\$homeName”.",
  "Còn \$count tin nhắn chưa đọc": "\$count teachtaireacht neamhléite",
  "Hãy an tâm nghỉ ngơi.": "Is féidir leat a bheith ar do shuaimhneas.",
  "Có thiết bị chưa an toàn.": "Níl roinnt gléasanna sábháilte.",
  "SafeHome đang cập nhật vị trí": "Tá SafeHome ag nuashonrú an tsuímh",
  "Đang theo dõi để tự động bật Chế độ Bảo vệ.":
      "Monatóireacht chun Mód Cosanta a chur ar siúl go huathoibríoch.",
  "Dùng vị trí để tự động bật Chế độ Bảo vệ khi mọi người rời nhà.":
      "Úsáideann sé suíomh chun Mód Cosanta a chur ar siúl go huathoibríoch nuair a fhágann gach duine an baile.",
  "CẢNH BÁO SOS": "FOLÁIREAMH SOS",
  "CẢNH BÁO KHÓI / CHÁY": "FOLÁIREAMH DEATAIGH / DÓITEÁIN",
  "CẢNH BÁO NGẬP NƯỚC": "FOLÁIREAMH TUILTE",
  "CẢNH BÁO RÒ KHÍ": "FOLÁIREAMH SCEITE GÁIS",
  "CẢNH BÁO CỬA": "FOLÁIREAMH DORAIS",
  "CẢNH BÁO AN NINH": "FOLÁIREAMH SLÁNDÁLA",
  "Không thể xác nhận với SafeHome. Hãy kiểm tra kết nối và thử lại.":
      "Níorbh fhéidir deimhniú le SafeHome. Seiceáil do cheangal agus bain triail eile as.",
  "Chỉ tắt cảnh báo khi bạn đã kiểm tra tình trạng trong nhà.\n\nBạn chắc chắn muốn tắt cảnh báo?":
      "Ná stop an foláireamh go dtí go mbeidh riocht an bhaile seiceáilte agat.\n\nAn bhfuil tú cinnte gur mhaith leat an foláireamh a stopadh?",
  "🚨 SafeHome phát hiện cảnh báo": "🚨 Bhraith SafeHome foláireamh",
  "Mở SafeHome để kiểm tra ngay.": "Oscail SafeHome chun seiceáil anois.",
  "\$count tin nhắn mới": "\$count teachtaireacht nua",
  "Tin nhắn HomeChat": "Teachtaireacht HomeChat",
  "\$senderName đã gửi một tin nhắn": "Sheol \$senderName teachtaireacht",
  "Bạn có tin nhắn mới": "Tá teachtaireacht nua agat",
  "Chế độ Bảo vệ sẽ chỉ báo động một lần":
      "Ní thabharfaidh Mód Cosanta foláireamh ach uair amháin",
  "Chế độ Bảo vệ sẽ lặp báo động sau \$minutes phút":
      "Athdhéanfaidh Mód Cosanta an foláireamh tar éis \$minutes nóiméad",
  "Đã gửi yêu cầu gia nhập \$count nhà":
      "Seoladh iarratais dul isteach chuig \$count baile",
  "\$requesterName đang xin gia nhập nhà \"\$homeName\".":
      "D'iarr \$requesterName dul isteach i “\$homeName”.",
  "Bạn đã xoá nhà \"\$homeName\".": "Scrios tú “\$homeName”.",
  "Bạn đã gửi yêu cầu chuyển quyền chủ nhà \"\$homeName\" cho \$email.":
      "Sheol tú iarratas chun úinéireacht “\$homeName” a aistriú chuig \$email.",
  "\$actorName muốn chuyển quyền chủ nhà \"\$homeName\" cho bạn.":
      "Tá \$actorName ag iarraidh úinéireacht “\$homeName” a aistriú chugat.",
  "\$actorName đã mời bạn tham gia nhà \"\$homeName\".":
      "Thug \$actorName cuireadh duit dul isteach i “\$homeName”.",
  "SafeHome đang xoá thiết bị \"\$deviceName\" khỏi nhà \"\$homeName\".":
      "Tá SafeHome ag baint “\$deviceName” ó “\$homeName”.",
  "Thiết bị \"\$deviceName\" đã xuất hiện trong \"\$homeName\".":
      "Cuireadh an gléas “\$deviceName” le “\$homeName”.",
  "Bạn đã tạo nhà \"\$name\".": "Chruthaigh tú an baile “\$name”.",
  "\$actorName đã cập nhật tên nhà thành \"\$newName\" và thay đổi địa chỉ.":
      "D'athraigh \$actorName ainm an bhaile go “\$newName” agus nuashonraigh sé a sheoladh.",
  "\$actorName đã đổi tên nhà thành \"\$newName\".":
      "D'athainmnigh \$actorName an baile mar “\$newName”.",
  "\$actorName đã cập nhật địa chỉ của nhà \"\$newName\".":
      "Nuashonraigh \$actorName seoladh “\$newName”.",
  "\$actorName đã đổi tên thiết bị \"\$oldDeviceName\" thành \"\$newName\" trong nhà \"\$homeName\".":
      "D'athainmnigh \$actorName an gléas “\$oldDeviceName” mar “\$newName” in “\$homeName”.",
  "Đang ghép nối: \$seconds giây": "Péireáil: \$seconds s",
  "Chế độ thêm thiết bị đã được mở trong nhà \"\$homeName\" trong \$seconds giây.":
      "Cumasaíodh péireáil gléasanna in “\$homeName” ar feadh \$seconds soicind.",
  "Khoảng thời gian phải nằm trong khung báo động (\$start → \$end)":
      "Caithfidh an tréimhse sosa a bheith laistigh de sceideal an Aláraim (\$start → \$end)",
  "\$passCount/\$total bài test đạt\n\n":
      "D'éirigh le \$passCount/\$total tástáil\n\n",
  "\$name chưa cập nhật số điện thoại trong hồ sơ.":
      "Níor chuir \$name uimhir theileafóin lena phróifíl.",
  "Tin nhắn mới trong \$homeName": "Teachtaireacht nua in \$homeName",
  "\$current/\$total kết quả": "\$current/\$total toradh",
  "Đang trả lời \$name": "Ag freagairt do \$name",
  "\"\$name\" phát hiện khói trong \"\$homeName\".":
      "Bhraith “\$name” deatach in “\$homeName”.",
  "\"\$name\" đã trở lại trạng thái bình thường.":
      "Tá “\$name” ar ais ina ghnáthriocht.",
  "\"\$name\" vừa kích hoạt SOS trong \"\$homeName\".":
      "Spreag “\$name” SOS in “\$homeName”.",
  "\"\$name\" đã hết trạng thái SOS.": "Níl “\$name” i staid SOS a thuilleadh.",
  "\"\$name\" báo bị tháo/cạy trong \"\$homeName\".":
      "Thuairiscigh “\$name” cur isteach in “\$homeName”.",
  "\"\$name\" đã hết cảnh báo tháo/cạy.":
      "Tá foláireamh cur isteach “\$name” glanta.",
  "\"\$name\" đã đóng trong \"\$homeName\".":
      "Dúnadh “\$name” in “\$homeName”.",
  "\"\$name\" đang mở trong \"\$homeName\".":
      "Tá “\$name” oscailte in “\$homeName”.",
  "\"\$name\" trong \"\$homeName\" đang yếu pin.":
      "Tá cadhnra íseal ag “\$name” in “\$homeName”.",
  "\"\$name\" trong \"\$homeName\" đã mất kết nối.":
      "Chuaigh “\$name” in “\$homeName” as líne.",
  "\"\$name\" trong \"\$homeName\" đã kết nối trở lại.":
      "Tá “\$name” in “\$homeName” ar líne arís.",
  "\"\$name\" ghi nhận nhiệt độ cao trong \"\$homeName\".":
      "Thaifead “\$name” teocht ard in “\$homeName”.",
  "\"\$name\" ghi nhận độ ẩm cao trong \"\$homeName\".":
      "Thaifead “\$name” taise ard in “\$homeName”.",
  "Có nút SOS vừa được kích hoạt": "Spreagadh cnaipe SOS",
  "Có dấu hiệu khói hoặc cháy": "Braitheadh deatach nó tine",
  "Có dấu hiệu ngập nước": "Braitheadh tuilte uisce",
  "Có dấu hiệu rò khí": "Braitheadh sceitheadh gáis",
  "Có cửa đang mở hoặc thiết bị bị tháo":
      "Tá doras oscailte nó cuireadh isteach ar ghléas",
  "Có thiết bị đang cảnh báo": "Tá gléas ag tabhairt foláirimh",
  "Nếu chưa có ai xác nhận, SafeHome sẽ chuyển sang gọi điện khẩn cấp.":
      "Mura ndeimhníonn aon duine, cuirfidh SafeHome tús le glao éigeandála.",
  "Báo lại lúc \$time nếu vấn đề chưa được xử lý.":
      "Tabharfar foláireamh arís ag \$time mura bhfuil an fhadhb láimhseáilte.",
  "Sẽ báo lại theo lịch báo động đã cài nếu vấn đề chưa được xử lý.":
      "Tabharfar foláireamh arís de réir sceideal an Aláraim mura bhfuil an fhadhb láimhseáilte.",
  "\"\$deviceName\" đã đóng trong \"\$resolvedHomeName\".":
      "Dúnadh “\$deviceName” in “\$resolvedHomeName”.",
  "\"\$deviceName\" đang mở trong \"\$resolvedHomeName\".":
      "Tá “\$deviceName” oscailte in “\$resolvedHomeName”.",
  "\$count nhà đã chọn": "\$count baile roghnaithe",
  "🚨 \$count nhà không an toàn\$suffix":
      "🚨 \$count baile neamhshábháilte\$suffix",
  "⚠️ \$count nhà cần chú ý\$suffix":
      "⚠️ Tá aird de dhíth ar \$count baile\$suffix",
  "✅ \$count nhà an toàn": "✅ \$count baile sábháilte",
  "\$count nhà đang được theo dõi": "\$count baile á monatóireacht",
  "\$minutes phút": "\$minutes nóiméad",
  "Đã cài nhắc nhở cho \$updatedHomes nhà.":
      "Socraíodh Meabhrúchán do \$updatedHomes baile.",
  "Đã cài báo động cho \$updatedDevices thiết bị trong \$updatedHomes nhà.\n":
      "Socraíodh Aláram do \$updatedDevices gléas thar \$updatedHomes baile.\n",
  "Đã chia sẻ các nhà bạn có quyền.\n\n\$skipped nhà bị bỏ qua vì bạn không có quyền chia sẻ.":
      "Comhroinneadh na bailte a bhainistíonn tú.\n\nFágadh \$skipped baile ar lár mar níl cead comhroinnte agat.",
  "Đã áp dụng báo động cho \$count thiết bị an ninh":
      "Cuireadh Aláram i bhfeidhm ar \$count gléas slándála",
  "Áp dụng cùng một lịch cho \$count thiết bị an ninh":
      "Cuir an sceideal céanna i bhfeidhm ar \$count gléas slándála",
  "\$count phút trước": "\$count nóiméad ó shin",
  "\$count giờ trước": "\$count uair an chloig ó shin",
  "\${count}h trước": "\${count}u ó shin",
  "\${hours}h\$minutes' trước": "\${hours}u \$minutes nóim ó shin",
  "\$count ngày trước": "\$count lá ó shin",
  "\$count tháng trước": "\$count mí ó shin",
  "Bạn chắc chắn muốn xoá \$name khỏi nhà này?":
      "An bhfuil tú cinnte gur mhaith leat \$name a bhaint den bhaile seo?",
  "\$targetEmail\nXin gia nhập \"\$homeName\"":
      "\$targetEmail\nAg iarraidh dul isteach i “\$homeName”",
  "Xin gia nhập \"\$homeName\"": "Ag iarraidh dul isteach i “\$homeName”",
  "Bạn được mời nhận quyền nhà \"\$homeName\"":
      "Tugadh cuireadh duit úinéireacht “\$homeName” a ghlacadh",
  "\$ownerEmail\nMời bạn gia nhập \"\$homeName\"":
      "\$ownerEmail\nAg tabhairt cuireadh duit dul isteach i “\$homeName”",
  "Mời bạn gia nhập \"\$homeName\"":
      "Ag tabhairt cuireadh duit dul isteach i “\$homeName”",
  "Cần kiểm tra: \$joined": "Aird de dhíth: \$joined",
  "Cập nhật \$value": "Nuashonraithe \$value",
  "Hãy thêm thiết bị SafeHome đầu tiên để bắt đầu theo dõi nhà.":
      "Cuir do chéad ghléas SafeHome leis chun monatóireacht a dhéanamh ar an mbaile seo.",
  "Kiểm tra cảnh báo khẩn cấp trước, sau đó liên hệ thành viên trong nhà nếu cần.":
      "Seiceáil foláirimh éigeandála ar dtús, ansin déan teagmháil le baill an teaghlaigh más gá.",
  "Không có thành viên nào ở nhà nhưng cửa hoặc khóa đang mở, hãy kiểm tra ngay.":
      "Níl aon bhall den teaghlach sa bhaile ach tá doras nó glas oscailte. Seiceáil anois é.",
  "Kiểm tra cửa hoặc khóa đang mở trước khi giữ nhà ở chế độ Bảo vệ.":
      "Seiceáil an doras nó an glas oscailte sula bhfágann tú an baile seo i Mód Cosanta.",
  "Có thể vẫn có người ở nhà; nếu đúng, nên chuyển về Bình thường.":
      "D'fhéadfadh duine a bheith sa bhaile fós. Más ea, athraigh ar ais go Gnáth.",
  "Có thành viên chưa xác định vị trí, hãy nhắc họ mở ứng dụng hoặc kiểm tra quyền vị trí.":
      "Ní fios cá bhfuil roinnt ball. Iarr orthu an aip a oscailt nó an cead suímh a sheiceáil.",
  "Có thiết bị mất kết nối, hãy kiểm tra pin, nguồn hoặc vị trí đặt thiết bị.":
      "Tá gléas dícheangailte. Seiceáil a chadhnra, a chumhacht nó a shuíomh.",
  "Có thiết bị pin yếu, nên thay pin sớm để tránh mất cảnh báo.":
      "Tá cadhnra íseal ag gléas. Athsholáthair go luath é chun foláirimh a sheachaint.",
  "Bạn chưa đặt nhắc nhở, nên tạo lịch nhắc kiểm tra nhà định kỳ.":
      "Níl Meabhrúchán socraithe. Cruthaigh sceideal chun do bhaile a sheiceáil go rialta.",
  "Bạn chưa đặt lịch báo động, nên bật bảo vệ theo khung giờ thường vắng nhà.":
      "Níl sceideal Aláraim socraithe. Cumasaigh cosaint do na hamanna a mbíonn tú as baile de ghnáth.",
  "Không có việc cần xử lý ngay, bạn chỉ cần tiếp tục theo dõi trạng thái nhà.":
      "Níl gá le gníomh láithreach. Lean ort ag déanamh monatóireachta ar an mbaile seo.",
  "Lặp sau \$minutes phút": "Athdhéan tar éis \$minutes nóiméad",
  "Đang dùng • \$repeatText": "Gníomhach • \$repeatText",
  "Giám sát an ninh • \$repeatText": "Monatóireacht slándála • \$repeatText",
  "Gia đình: \$mode": "Mód baile: \$mode",
  "Gợi ý xử lý": "Gníomhartha molta",
  "Phát hiện \$count vấn đề cần xử lý": "Tá aird de dhíth ar \$count fadhb",
  "Hôm nay các cửa đã được sử dụng \$count lần":
      "Úsáideadh doirse \$count uair inniu",
  "Đã ghi nhận \$count hoạt động gần đây":
      "Taifeadadh \$count gníomhaíocht le déanaí",
  "Hệ thống: Cần kiểm tra \$issueCount mục":
      "Córas: Ní mór \$issueCount mír a sheiceáil",
  "FCM token đã sẵn sàng trên điện thoại này.":
      "Tá an comhartha FCM réidh ar an bhfón seo.",
  "FCM token đã sẵn sàng, nhưng Auto rời khỏi nhà còn thiếu điều kiện.":
      "Tá an comhartha FCM réidh, ach tá riachtanas amháin in easnamh don Chosaint Uathoibríoch agus tú as baile.",
  "Hiện có \$emergencyTotal thiết bị khẩn cấp. Khuyến nghị tối thiểu: báo khói và SOS.":
      "Fuarthas \$emergencyTotal gléas éigeandála. Íosmhéid molta: braiteoir deataigh agus SOS.",
  "Bạn chắc chắn muốn chuyển quyền chủ nhà cho:\n\$targetEmail?":
      "Aistrigh úinéireacht an bhaile chuig:\n\$targetEmail?",
  "\$count cửa đã đóng an toàn": "\$count doras dúnta go sábháilte",
  "\$count cửa và khóa đã an toàn": "\$count doras agus glas daingnithe",
  "\$count thiết bị đang được theo dõi": "\$count gléas á monatóireacht",
  "Cập nhật \$timeText": "Nuashonraithe \$timeText",
  "Dữ liệu gần nhất cập nhật \$count phút trước":
      "Nuashonraíodh na sonraí is déanaí \$count nóiméad ó shin",
  "Dữ liệu gần nhất cập nhật \$count giờ trước":
      "Nuashonraíodh na sonraí is déanaí \$count uair an chloig ó shin",
  "Thành viên trong nhà: \$count": "Baill sa bhaile: \$count",
  "Thành viên bên ngoài: \$count": "Baill as baile: \$count",
  "Chưa xác định vị trí: \$count": "Suíomh anaithnid: \$count",
  "Môi trường hiện tại: \$environment": "An timpeallacht reatha: \$environment",
  "\$name: Đang mở khi nhà ở chế độ Bảo vệ":
      "\$name: Oscailte agus an Baile i Mód Cosanta",
  "An tâm hơn trong từng ngôi nhà": "Suaimhneas intinne i ngach baile",
  "Báo động SafeHome": "Aláram SafeHome",
  "Có cảnh báo an ninh cần kiểm tra ngay.":
      "Teastaíonn d'aird ó fholáireamh slándála.",
  "Có cảnh báo cần kiểm tra": "Teastaíonn d'aird ó fholáireamh",
  "Tự đóng sau \$time": "Dúnfar go huathoibríoch i gceann \$time",
  "Ngày trong tuần": "Laethanta na seachtaine",
  "Hoặc": "Nó",
  "Giờ bắt đầu và kết thúc không được trùng nhau":
      "Ní féidir leis na hamanna tosaithe agus deiridh a bheith mar an gcéanna",
  "Giờ kết thúc phải sau thời điểm hiện tại":
      "Caithfidh an t-am deiridh a bheith níos déanaí ná an t-am reatha",
  "Khoảng tạm tắt không hợp lệ": "Raon sosa Aláraim neamhbhailí",
  "Khoảng tạm tắt không trùng với lịch báo động nào đang bật":
      "Ní fhorluíonn an raon sosa le haon sceideal Aláraim gníomhach",
  "Cài đặt báo động": "Socruithe Aláraim",
  "Điều khiển cách cảm biến này kích hoạt cảnh báo.":
      "Rialaigh conas a spreagann an braiteoir seo foláirimh.",
  "Tham gia báo động": "Glac páirt in aláraim",
  "Tắt để cảm biến không tạo báo động.":
      "Múch é chun an braiteoir seo a chosc ó Aláram a chruthú.",
  "Bật còi vật lý": "Cumasaigh an bonnán fisiciúil",
  "Cho phép kích hoạt còi trong nhà.":
      "Ceadaigh don bhonnán laistigh gníomhachtú.",
  "Đánh thức màn hình": "Múscail an scáileán",
  "Hiển thị cảnh báo toàn màn hình trên điện thoại.":
      "Taispeáin foláireamh lánscáileáin ar an bhfón.",
  "Độ trễ kích hoạt": "Moill spreagtha",
  "Chỉ áp dụng cho cảm biến an ninh.":
      "Ní bhaineann sé ach le braiteoirí slándála.",
  "Cảm biến khẩn cấp luôn kích hoạt ngay lập tức.":
      "Spreagann braiteoirí éigeandála láithreach i gcónaí.",
  "Ngay lập tức": "Láithreach",
  "giây": "soicind",
  "Đã lưu cấu hình báo động": "Socruithe Aláraim sábháilte",
  "Không thể lưu cấu hình báo động":
      "Níorbh fhéidir socruithe Aláraim a shábháil",
  "Chỉ chủ nhà và quản trị viên có thể thay đổi cài đặt này.":
      "Ní féidir ach le húinéir an bhaile agus riarthóirí an socrú seo a athrú.",
  "Thông tin chi tiết": "Sonraí gléis",
  "Thông báo báo động": "Fógra Aláraim",
  "Cài đặt nhắc nhở": "Socruithe Meabhrúcháin",
  "Nhắc nhở theo lịch": "Meabhrúchán sceidealaithe",
  "Danh sách thông báo": "Fógraí",
  "Cài đặt thông báo": "Socruithe fógraí",
  "Sử dụng báo động theo lịch đã thiết lập":
      "Úsáid an sceideal Aláraim cumraithe",
  "Chỉ gửi thông báo, không kích hoạt báo động":
      "Seol fógraí amháin; ná spreag an t-aláram",
  "Toàn bộ báo động của nhà đang tắt; hệ thống chỉ gửi thông báo.":
      "Tá gach Aláram baile múchta; ní sheolfaidh an córas ach fógraí.",
  "Chỉ Chủ nhà có thể bật chế độ này.":
      "Ní féidir ach leis an úinéir an mód seo a chumasú.",
  "Bật Không bảo vệ?": "Cumasaigh mód Gan Chosaint?",
  "Cảm biến vừa phát hiện một sự kiện.":
      "Tá imeacht díreach braite ag braiteoir.",
  "Chỉ Chủ nhà mới có quyền bật chế độ Không bảo vệ":
      "Ní féidir ach leis an úinéir mód Gan Chosaint a chumasú",
  "Đã chuyển nhà sang Không bảo vệ": "Athraíodh an baile go mód Gan Chosaint",
  "Đã chuyển sang Không bảo vệ nhưng chưa gửi được thông báo":
      "Athraíodh go mód Gan Chosaint, ach níorbh fhéidir an fógra a sheoladh",
  "Giám sát toàn diện": "Monatóireacht iomlán",
  "Không bảo vệ": "Gan Chosaint",
  "Không bảo vệ đang bật": "Tá mód Gan Chosaint gníomhach",
  "Nhà đã chuyển sang Không bảo vệ": "Athraíodh an baile go mód Gan Chosaint",
  "Thông báo cảm biến": "Fógraí braiteora",
  "Thông báo thông thường khi cảm biến phát hiện sự kiện.":
      "Fógraí caighdeánacha nuair a bhraitheann braiteoir imeacht.",
  "Tôi hiểu, tiếp tục": "Tuigim, lean ar aghaidh",
  "Cảnh báo an ninh đã kết thúc":
      "Tháinig deireadh leis an bhfoláireamh slándála",
  "Sự cố nguy hiểm đã kết thúc": "Tháinig deireadh leis an éigeandáil",
  "Cảnh báo đã được kết thúc.": "Tá deireadh leis an bhfoláireamh.",
  "Vẫn còn cảnh báo khác đang hoạt động.": "Tá foláireamh eile fós gníomhach.",
  "Báo động đã hoạt động trở lại": "Tá an t-aláram gníomhach arís",
  "Thời gian tạm dừng báo động đã kết thúc.":
      "Tá tréimhse sosa an aláraim thart.",
  "MQTT đã kết nối trở lại": "MQTT athcheangailte",
  "Còi báo động đã được tắt": "Múchadh an bonnán fisiciúil",
  "Sự cố vẫn đang được theo dõi.":
      "Tá monatóireacht á déanamh ar an teagmhas fós.",
  "Bảo vệ tự động đã bật": "Cosaint uathoibríoch cumasaithe",
  "Toàn bộ thành viên đã rời khỏi nhà.":
      "Tá gach ball tar éis an baile a fhágáil.",
  "Bảo vệ tự động đã tắt": "Cosaint uathoibríoch díchumasaithe",
  "Có thành viên đã trở về nhà.": "Tá ball tar éis filleadh abhaile.",
  "Thiết bị đã được xoá": "Baineadh an gléas",
  "Không thể xoá thiết bị": "Níorbh fhéidir an gléas a bhaint",
  "Hãy thử lại thao tác xoá thiết bị.":
      "Bain triail eile as an ngléas a bhaint.",
  "Chế độ Bảo vệ đã được tắt.": "Múchadh an mód cosanta.",
  "Nhà đang ở chế độ Bình thường.": "Tá an baile i mód Gnáth.",
  "Pin thiết bị đã ổn định": "Tá cadhnra an ghléis cobhsaí",
  "Hub đã kết nối trở lại": "Hub athcheangailte",
  "Đã chuyển về Bình thường nhưng chưa gửi được thông báo":
      "Athraíodh go Gnáth, ach níorbh fhéidir an fógra a sheoladh",
  "Chung cho nhà": "Baile comhroinnte",
  "Áp dụng cho toàn bộ thành viên và có thể bật còi vật lý.":
      "Baineann sé le gach ball agus féadfaidh sé an bonnán fisiciúil a ghníomhachtú.",
  "Cá nhân": "Pearsanta",
  "Lịch cá nhân hoạt động độc lập và không bật còi vật lý.":
      "Oibríonn an sceideal pearsanta go neamhspleách agus ní ghníomhachtaíonn sé an bonnán fisiciúil riamh.",
  "Cài đặt này chỉ áp dụng cho tài khoản của bạn.":
      "Ní bhaineann an socrú seo ach le do chuntas.",
  "Chỉ chủ nhà và quản trị viên có thể thay đổi phần chung cho nhà.":
      "Ní féidir ach leis an úinéir agus riarthóirí socruithe baile comhroinnte a athrú.",
  "Tham gia hệ thống báo động": "Glac páirt sa chóras aláraim",
  "Cảm biến khẩn cấp luôn tham gia hệ thống báo động.":
      "Glacann braiteoirí éigeandála páirt sa chóras aláraim i gcónaí.",
  "Tắt để thiết bị không tạo bất kỳ báo động nào.":
      "Múch é chun an gléas a chosc ó aon aláram a chruthú.",
  "Lịch báo động chung": "Sceideal Aláraim comhroinnte",
  "Lịch báo động cá nhân": "Sceideal Aláraim pearsanta",
  "Hiển thị cảnh báo toàn màn hình trên điện thoại của bạn.":
      "Taispeáin foláireamh lánscáileáin ar do ghuthán.",
  "Lặp lại cảnh báo": "Athdhéan an foláireamh",
  "Báo động chung": "Aláram comhroinnte",
  "Báo động cá nhân": "Aláram pearsanta",
  "Đã cài đặt": "Cumraithe",
  "Chưa cài đặt": "Gan chumrú",
  "Lịch chung và lịch cá nhân hoạt động song song, không còn phải chọn một trong hai.":
      "Oibríonn sceidil chomhroinnte agus phearsanta i gcomhthreo; ní gá ceann a roghnú a thuilleadh.",
  "Cài nhanh chung": "Socrú tapa comhroinnte",
  "Cài nhanh cá nhân": "Socrú tapa pearsanta",
  "Thiết lập nhanh lịch cá nhân": "Socrú tapa sceidil phearsanta",
  "Thiết lập nhanh lịch chung": "Socrú tapa sceidil chomhroinnte",
  "Lịch này chỉ áp dụng cho bạn và không bật còi vật lý.":
      "Ní bhaineann an sceideal seo ach leatsa agus ní ghníomhachtaíonn sé an bonnán fisiciúil.",
  "Lịch này áp dụng cho toàn bộ thành viên trong nhà.":
      "Baineann an sceideal seo le gach ball sa bhaile.",
  "Đã áp dụng lịch báo động": "Sceideal Aláraim curtha i bhfeidhm",
  "Không thể lưu lịch báo động":
      "Níorbh fhéidir sceideal an Aláraim a shábháil",
  "Nhà chưa có thiết bị an ninh": "Níl aon ghléasanna slándála sa bhaile seo",
  "Nhận cảnh báo theo lịch chung của nhà":
      "Faigh foláirimh ó sceideal an bhaile chomhroinnte",
  "Tắt để không nhận thông báo hoặc cảnh báo toàn màn hình từ lịch chung. Còi vật lý của nhà vẫn hoạt động.":
      "Múch é seo chun fógraí agus foláirimh lánscáileáin ón sceideal comhroinnte a stopadh. Leanfaidh bonnán an bhaile ag obair.",
};

const Map<String, String> skDynamicStrings = {
  "Bảo vệ - Tự động": "Ochrana – automatická",
  "Bảo vệ - Thủ công": "Ochrana – manuálna",
  "Tự động": "Automaticky",
  "Thủ công": "Manuálne",
  "\$displayMemberName đã gia nhập nhà \"\$homeName\".":
      "\$displayMemberName sa pripojil(a) k domovu „\$homeName“.",
  "NGUY HIỂM": "NEBEZPEČENSTVO",
  "Nguy hiểm & Khẩn cấp": "Nebezpečenstvo a núdzové situácie",
  "TẮT CÒI": "VYPNÚŤ SIRÉNU",
  "Tắt còi báo động?": "Vypnúť sirénu alarmu?",
  "Còi vật lý sẽ dừng, nhưng cảnh báo vẫn tiếp tục cho đến khi sự cố được xử lý.\n\nBạn chắc chắn muốn tắt còi?":
      "Fyzická siréna sa zastaví, ale upozornenie zostane aktívne, kým sa incident nevyrieši.\n\nNaozaj chcete sirénu vypnúť?",
  "Đã gửi lệnh tắt còi. Cảnh báo vẫn đang được theo dõi.":
      "Príkaz na vypnutie sirény bol odoslaný. Upozornenie sa stále sleduje.",
  "Không tìm thấy cảnh báo đang hoạt động hoặc chưa thể gửi lệnh tắt còi.":
      "Nenašlo sa žiadne aktívne upozornenie alebo sa zatiaľ nepodarilo odoslať príkaz na vypnutie sirény.",
  "TẮT CÒI TRONG NHÀ": "VYPNÚŤ SIRÉNU V DOME",
  "Đã tắt còi trong nhà. Cảnh báo vẫn tiếp tục cho đến khi được xử lý.":
      "Siréna v dome bola vypnutá. Upozornenie zostane aktívne, kým sa incident nevyrieši.",
  "\$name đang chuẩn bị gửi tin...": "\$name píše správu…",
  "\$name1 và \$name2 đang chuẩn bị gửi tin...":
      "\$name1 a \$name2 píšu správu…",
  "\$name và \$otherCount người khác đang chuẩn bị gửi tin...":
      "\$name a ďalších \$otherCount používateľov píše správu…",
  "Kênh báo động cũ để giữ tương thích":
      "Starý kanál alarmu kvôli spätnej kompatibilite",
  "SafeHome báo động toàn màn hình": "Celoobrazovkový alarm SafeHome",
  "Mở cảnh báo toàn màn hình; âm còi phát từ trang báo động":
      "Otvorí upozornenie na celú obrazovku; zvuk sirény sa prehráva na stránke alarmu",
  "SafeHome cảnh báo khẩn cấp": "Núdzové upozornenie SafeHome",
  "Cảnh báo khẩn cấp ưu tiên cao trước khi mở toàn màn hình":
      "Núdzové upozornenie s vysokou prioritou pred otvorením na celú obrazovku",
  "SafeHome nhắc nhở toàn màn hình": "Celoobrazovková pripomienka SafeHome",
  "Nhắc nhở SafeHome toàn màn hình không âm thanh":
      "Celoobrazovková pripomienka SafeHome bez zvuku",
  "SafeHome nhắc nhở ưu tiên cao": "Pripomienka SafeHome s vysokou prioritou",
  "Nhắc nhở SafeHome ưu tiên cao, không mở toàn màn hình":
      "Pripomienka SafeHome s vysokou prioritou bez otvorenia na celú obrazovku",
  "Tin nhắn mới trong các nhà SafeHome": "Nové správy v domovoch SafeHome",
  "Hành động này sẽ thay đổi thời gian báo động của một số thiết bị hôm nay.\n\nBáo động của các thiết bị thuộc trường \"Nguy hiểm khẩn cấp\" và báo động ở chế độ \"Bảo vệ\" sẽ không bị ảnh hưởng bởi chức năng này.":
      "Táto akcia dnes zmení čas alarmu niektorých zariadení.\n\nAlarmy zariadení v kategórii „Núdzové nebezpečenstvo“ a alarmy v režime „Ochrana“ nebudú touto funkciou ovplyvnené.",
  "🆘 \$count nhà nguy hiểm\$suffix":
      "🆘 \$count domovov v nebezpečenstve\$suffix",
  "FCM token đã sẵn sàng, nhưng tính năng tự động khi rời nhà còn thiếu điều kiện.":
      "Token FCM je pripravený, ale automatickej funkcii pri odchode stále chýbajú niektoré podmienky.",
  "Đã kích hoạt SOS": "SOS bolo aktivované",
  "Phát hiện chập điện": "Zistený skrat",
  "Phát hiện quá dòng": "Zistený nadprúd",
  "Phát hiện quá áp": "Zistené prepätie",
  "Thiết bị điện quá nhiệt": "Elektrické zariadenie sa prehrieva",
  "Tài khoản đang được sử dụng": "Účet sa používa",
  "Hiện tại tài khoản này đang đăng nhập trên một thiết bị khác. Nếu tiếp tục, tài khoản trên thiết bị đó sẽ tự đăng xuất.":
      "Tento účet je aktuálne prihlásený na inom zariadení. Ak budete pokračovať, účet na tomto zariadení bude automaticky odhlásený.",
  "Tiếp tục đăng nhập": "Pokračovať v prihlásení",
  "Tài khoản đã được đăng nhập trên một thiết bị khác.":
      "Účet bol prihlásený na inom zariadení.",
  "KHẨN CẤP": "NÚDZOVÝ STAV",
  "CẦN CHÚ Ý": "VYŽADUJE POZORNOSŤ",
  "THÔNG TIN": "INFORMÁCIE",
  "BÁO ĐỘNG": "ALARM",
  "Cảm biến đã trở lại trạng thái an toàn.":
      "Senzor sa vrátil do bezpečného stavu.",
  "Người dùng đã tắt cảnh báo.": "Používateľ upozornenie vypol.",
  "Khung giờ bảo vệ đã kết thúc.": "Časové okno ochrany sa skončilo.",
  "Cảnh báo tức thời đã tự kết thúc.":
      "Okamžité upozornenie bolo automaticky ukončené.",
  "Điều kiện cảnh báo không còn hoạt động.":
      "Podmienka upozornenia už nie je aktívna.",
  "Cảnh báo đã kết thúc: \$reason": "Upozornenie ukončené: \$reason",
};

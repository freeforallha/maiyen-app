const Map<String, String> skStrings = {
  "Không tìm thấy người dùng": "Používateľ sa nenašiel",
  "Không đọc được số điện thoại": "Telefónne číslo sa nepodarilo načítať",
  "Tin nhắn quá dài": "Správa je príliš dlhá",
  "Không gửi được tin nhắn": "Správu sa nepodarilo odoslať",
  "Bạn không có quyền sửa lịch chung của nhà":
      "Nemáte povolenie upravovať spoločný rozvrh domácnosti",
  "Nhà của bạn": "Váš domov",
  "Tải tin cũ hơn": "Načítať staršie správy",
  "Nhà chưa đặt tên": "Dom bez názvu",
  "Nhà": "Domov",
  "Chưa có thông tin": "Žiadne informácie",
  "Chưa cập nhật": "Zatiaľ neaktualizované",
  "Chủ nhà": "Vlastník",
  "Nhà được chia sẻ": "Zdieľaný domov",
  "Địa chỉ": "Adresa",
  "An ninh ra/vào": "Zabezpečenie vstupu a výstupu",
  "Nguy hiểm khẩn cấp": "Núdzové nebezpečenstvo",
  "Điều khiển & hạ tầng": "Ovládanie a infraštruktúra",
  "Môi trường": "Prostredie",
  "Toàn bộ thiết bị SafeHome": "Všetky zariadenia SafeHome",
  "Cửa ra/vào": "Vstupné dvere",
  "Cửa": "Dvere",
  "Cửa sổ": "Okno",
  "Cổng": "Brána",
  "Khóa thông minh": "Inteligentný zámok",
  "Chuyển động": "Pohyb",
  "Hiện diện": "Prítomnosť",
  "Rung/chấn động": "Vibrácie/otras",
  "Kính vỡ": "Rozbitie skla",
  "Báo khói": "Detektor dymu",
  "Báo nhiệt": "Detektor tepla",
  "Khí CO": "Oxid uhoľnatý (CO)",
  "Báo gas": "Detektor plynu",
  "Báo ngập/rò nước": "Detektor zaplavenia/úniku vody",
  "Nút SOS": "Tlačidlo SOS",
  "Nhiệt độ/Độ ẩm": "Teplota/vlhkosť",
  "Bụi mịn PM2.5": "Jemný prach PM2.5",
  "CO₂": "CO₂",
  "Chất lượng không khí": "Kvalita ovzdušia",
  "Ổ điện thông minh": "Inteligentná zásuvka",
  "Còi báo động": "Poplašná siréna",
  "Van thông minh": "Inteligentný ventil",
  "Camera": "Kamera",
  "Chuông cửa": "Domový zvonček",
  "Bàn phím an ninh": "Bezpečnostná klávesnica",
  "Bộ mở rộng sóng": "Zosilňovač signálu",
  "Hub trung tâm": "Centrálny hub",
  "Đo điện năng": "Meranie spotreby energie",
  "Nguồn dự phòng UPS": "Záložný zdroj UPS",
  "Thiết bị đang Offline": "Zariadenie je offline",
  "Thiết bị đang Online": "Zariadenie je online",
  "lâu không phản hồi": "dlho neodpovedá",
  "Kết nối cần kiểm tra": "Pripojenie vyžaduje kontrolu",
  "Vừa xong": "Práve teraz",
  "Bị tháo": "Odstránené",
  "Có khói": "Zistený dym",
  "Bình thường": "Normálne",
  "Bảo vệ": "Ochrana",
  "Chế độ Bảo vệ": "Režim ochrany",
  "Tự động Bảo vệ khi rời nhà": "Automatická ochrana pri odchode z domu",
  "Đã kích hoạt": "Aktivované",
  "Sẵn sàng": "Pripravené",
  "Đang đóng": "Zatvorené",
  "Đang mở": "Otvorené",
  "Rò rỉ gas": "Únik plynu",
  "Phát hiện ngập nước": "Zistené zaplavenie",
  "Phát hiện chuyển động": "Zistený pohyb",
  "Không có chuyển động": "Žiadny pohyb",
  "Phát hiện hiện diện": "Zistená prítomnosť",
  "Không phát hiện hiện diện": "Prítomnosť nezistená",
  "Phát hiện rung/chấn động": "Zistené vibrácie/otras",
  "Không có rung bất thường": "Žiadne nezvyčajné vibrácie",
  "Phát hiện kính vỡ": "Zistené rozbitie skla",
  "Không có cảnh báo kính vỡ": "Žiadne upozornenie na rozbitie skla",
  "Nhiệt độ nguy hiểm": "Nebezpečná teplota",
  "Phát hiện khí CO": "Zistený oxid uhoľnatý",
  "Không phát hiện khí CO": "Oxid uhoľnatý nezistený",
  "Khóa đang mở": "Zámok je odomknutý",
  "Khóa đang đóng": "Zámok je zamknutý",
  "Đang bật": "Zapnuté",
  "Bật": "Zapnuté",
  "Đang tắt": "Vypnuté",
  "Đang theo dõi điện năng": "Sledovanie spotreby energie",
  "Đang dùng nguồn dự phòng": "Používa sa záložné napájanie",
  "Nguồn điện bình thường": "Napájanie je v poriadku",
  "Còi đang bật": "Siréna je zapnutá",
  "Còi sẵn sàng": "Siréna je pripravená",
  "Van đang mở": "Ventil je otvorený",
  "Van đã đóng": "Ventil je zatvorený",
  "Đang hoạt động": "Aktívne",
  "Đang theo dõi": "Sledovanie aktívne",
  "Chưa nhận diện": "Nerozpoznané",
  "Chưa có cập nhật": "Zatiaľ žiadne aktualizácie",
  "Chưa có thiết bị, hãy nhấn nút + để thêm để bắt đầu duy trì an ninh":
      "Zatiaľ nie sú pridané žiadne zariadenia. Ťuknutím na + pridajte zariadenie a začnite chrániť svoj domov",
  "CHƯA AN TOÀN": "NIE JE BEZPEČNÉ",
  "ĐÃ AN TOÀN": "BEZPEČNÉ",
  "Nhà đang có dấu hiệu cần kiểm tra, bạn nên xem lại các trạng thái bên dưới.":
      "V dome sú príznaky, ktoré je potrebné skontrolovať. Pozrite si nižšie uvedené stavy.",
  "Nhà đang hoạt động ổn định, bạn có thể yên tâm.":
      "Domov funguje stabilne. Môžete byť pokojní.",
  "Không có dấu hiệu khói hoặc SOS bất thường.":
      "Žiadne známky dymu ani nezvyčajného SOS signálu.",
  "Chưa có nhiều hoạt động mới để phân tích sâu hơn.":
      "Zatiaľ nie je dostatok novej aktivity na podrobnejšiu analýzu.",
  "Hub kết nối bình thường": "Pripojenie hubu je v poriadku",
  "Cài đặt cảnh báo cho nhà hiện tại":
      "Nastaviť upozornenia pre aktuálny domov",
  "Nhận cảnh báo báo động": "Prijímať poplašné upozornenia",
  "Đang bật cho tài khoản này": "Zapnuté pre tento účet",
  "Đang tắt cho tài khoản này": "Vypnuté pre tento účet",
  "Hẹn giờ nhắc nhở": "Naplánovať pripomienku",
  "Nhắc kiểm tra nhà theo thời gian":
      "Pripomínať kontrolu domova v naplánovanom čase",
  "Hẹn giờ báo động": "Naplánovať alarm",
  "Chưa thiết lập": "Nenastavené",
  "Chưa thiết lập thời gian": "Čas nie je nastavený",
  "Tổng hợp trạng thái nhà": "Súhrn stavu domova",
  "Cần xử lý ngay": "Vyžaduje okamžité riešenie",
  "Đánh giá tự động": "Automatické vyhodnotenie",
  "Tự động đánh giá": "Automaticky vyhodnotiť",
  "Tổng quan hôm nay": "Dnešný prehľad",
  "Chưa có dữ liệu tổng quan": "Zatiaľ nie sú k dispozícii súhrnné údaje",
  "Chưa có dữ liệu trạng thái": "Zatiaľ nie sú k dispozícii údaje o stave",
  "Chưa đủ dữ liệu để đánh giá":
      "Zatiaľ nie je dostatok údajov na vyhodnotenie",
  "Chưa có dữ liệu để đánh giá": "Nie sú k dispozícii údaje na vyhodnotenie",
  "Bấm vào để xem chi tiết": "Ťuknutím zobrazíte podrobnosti",
  "Nhấn để xem chi tiết...": "Ťuknutím zobrazíte podrobnosti...",
  "Tạm dừng": "Pozastaviť",
  "Tắt": "Vypnúť",
  "Chi tiết": "Podrobnosti",
  "Tổng hợp trạng thái": "Súhrn stavu",
  "Không an toàn": "Nebezpečné",
  "Cần chú ý": "Vyžaduje pozornosť",
  "An toàn": "Bezpečné",
  "Không có": "Žiadne",
  "Đổi tên nhóm": "Premenovať skupinu",
  "Huỷ": "Zrušiť",
  "Lưu": "Uložiť",
  "Thêm": "Pridať",
  "Xoá": "Odstrániť",
  "Đổi tên": "Premenovať",
  "Nhà của tôi": "Môj domov",
  "Bỏ chọn toàn bộ nhóm": "Zrušiť výber všetkých skupín",
  "Chọn toàn bộ nhóm": "Vybrať všetky skupiny",
  "Bỏ chọn": "Zrušiť výber",
  "Quay lại": "Späť",
  "Tìm kiếm": "Hľadať",
  "Đóng tìm kiếm": "Zavrieť vyhľadávanie",
  "Giờ": "Hodina",
  "Phút": "Minúta",
  "Đặt nhắc nhở cho nhà": "Nastaviť pripomienku pre domov",
  "Đặt báo động cho nhà": "Nastaviť alarm pre domov",
  "Xác nhận thay đổi": "Potvrdiť zmeny",
  "Tiếp tục": "Pokračovať",
  "Giờ nhắc nhở": "Čas pripomienky",
  "Giờ bắt đầu báo động": "Čas začiatku alarmu",
  "Giờ kết thúc báo động": "Čas ukončenia alarmu",
  "Không có nhà nào đủ điều kiện để cài": "Žiadny vhodný domov na nastavenie",
  "Cài đặt hoàn tất": "Nastavenie dokončené",
  "Xác nhận rời nhà": "Potvrdiť opustenie domova",
  "Xác nhận xoá nhà": "Potvrdiť odstránenie domova",
  "Nhập mật khẩu": "Zadajte heslo",
  "Mật khẩu tài khoản": "Heslo účtu",
  "Rời khỏi nhà": "Opustiť domov",
  "Xoá nhà": "Odstrániť domov",
  "Sai mật khẩu": "Nesprávne heslo",
  "Đã rời khỏi home": "Domov bol opustený",
  "Đã cập nhật": "Aktualizované",
  "Tìm home...": "Hľadať domov...",
  "Đặt vị trí nhà và bật bảo vệ tự động":
      "Nastaviť polohu domova a zapnúť automatickú ochranu",
  "Chuyển quyền chủ nhà hoặc xoá nhà":
      "Previesť vlastníctvo alebo odstrániť domov",
  "Đặt nhắc nhở / báo động nhà đã chọn":
      "Nastaviť pripomienku/alarm pre vybrané domovy",
  "Chia sẻ nhà đã chọn": "Zdieľať vybrané domovy",
  "Mở danh sách chia sẻ nhà": "Otvoriť zoznam zdieľania domova",
  "Xoá các nhà đã chọn?": "Odstrániť vybrané domovy?",
  "Các nhà đã chọn sẽ bị xoá vĩnh viễn.":
      "Vybrané domovy budú natrvalo odstránené.",
  "Hoặc quét QR để xin gia nhập các nhà đã chọn":
      "Alebo naskenujte QR kód a požiadajte o pripojenie k vybraným domovom",
  "Email người nhận": "E-mail príjemcu",
  "Chia sẻ": "Zdieľať",
  "Email chưa đăng ký": "E-mail nie je zaregistrovaný",
  "Chia sẻ hoàn tất": "Zdieľanie dokončené",
  "Mở List chia sẻ nhà": "Otvoriť zoznam zdieľania domova",
  "Không có nhà nào bạn có quyền quản lý":
      "Nemáte žiadny domov, ktorý môžete spravovať",
  "Chưa share cho ai": "Zatiaľ s nikým nezdieľané",
  "Tìm nhà": "Hľadať domov",
  "Xoá các nhà đã chọn ?": "Odstrániť vybrané domovy?",
  "Thông báo Home": "Oznámenia domova",
  "Thông báo nhà": "Oznámenia domova",
  "Vai trò thành viên đã thay đổi": "Rola člena bola zmenená",
  "Xoá tất cả thông báo?": "Odstrániť všetky oznámenia?",
  "Toàn bộ thông báo nhà sẽ bị xoá.":
      "Všetky oznámenia domova budú odstránené.",
  "Chưa có thông báo nào": "Zatiaľ žiadne oznámenia",
  "Chưa có thông báo": "Žiadne oznámenia",
  "Vuốt lên để tải thêm": "Potiahnutím nahor načítate ďalšie",
  "Không có thiết bị": "Žiadne zariadenia",
  "Chỉ chủ nhà mới được xoá nhà": "Domov môže odstrániť iba vlastník",
  "Chỉ chủ nhà mới được chuyển quyền": "Vlastníctvo môže previesť iba vlastník",
  "Lưu ý khi bật báo động": "Upozornenie pri zapnutí alarmu",
  "Báo động đã được bật": "Alarm bol zapnutý",
  "Đã hiểu": "Rozumiem",
  "Lưu ý tạm tắt báo động": "Upozornenie pri dočasnom vypnutí alarmu",
  "Đã bật báo động": "Alarm zapnutý",
  "Đã tắt báo động": "Alarm vypnutý",
  "Tắt báo động": "Vypnúť alarm",
  "Cả ngày": "Celý deň",
  "Bạn không có quyền thực hiện thao tác này.":
      "Na vykonanie tejto akcie nemáte povolenie.",
  "Không thể hoàn tất thao tác. Vui lòng thử lại.":
      "Akciu sa nepodarilo dokončiť. Skúste to znova.",
  "QR gia nhập nhiều nhà không hợp lệ":
      "Neplatný QR kód na pripojenie k viacerým domovom",
  "Bạn đang là chủ các nhà này": "Ste vlastníkom týchto domovov",
  "Một người dùng": "Jeden používateľ",
  "Yêu cầu gia nhập nhà": "Žiadosť o pripojenie k domovu",
  "Đã gửi yêu cầu gia nhập nhà": "Žiadosť o pripojenie k domovu bola odoslaná",
  "QR gia nhập không hợp lệ": "Neplatný QR kód na pripojenie",
  "Bạn đang là chủ nhà này": "Ste vlastníkom tohto domova",
  "QR này không phải mã xin gia nhập nhà":
      "Tento QR kód nie je určený na žiadosť o pripojenie k domovu",
  "Bạn không có quyền thêm thiết bị": "Nemáte povolenie pridávať zariadenia",
  "Đã mở chế độ thêm thiết bị": "Režim pridávania zariadení bol spustený",
  "Rời khỏi Home này?": "Opustiť tento domov?",
  "Nhà này và toàn bộ thiết bị bên trong sẽ bị xoá vĩnh viễn.":
      "Tento domov a všetky zariadenia v ňom budú natrvalo odstránené.",
  "Đã xoá nhà": "Domov bol odstránený",
  "QR của nhà này": "QR kód tohto domova",
  "Người khác quét mã này để gửi yêu cầu gia nhập nhà.":
      "Ostatní môžu tento kód naskenovať a odoslať žiadosť o pripojenie k domovu.",
  "Chia sẻ nhà": "Zdieľať domov",
  "Quét QR để xin gia nhập nhà": "Naskenovať QR kód a požiadať o pripojenie",
  "Quét QR xin gia nhập nhà":
      "Naskenovať QR kód na žiadosť o pripojenie k domovu",
  "Đưa mã QR chia sẻ nhà vào khung hình":
      "Umiestnite QR kód na zdieľanie domova do rámčeka",
  "Mã QR này do chủ nhà chia sẻ": "Tento QR kód zdieľal vlastník domova",
  "Nhập mã mời": "Zadajte kód pozvánky",
  "Gửi yêu cầu gia nhập": "Odoslať žiadosť o pripojenie",
  "QR này không phải mã thiết bị": "Tento QR kód nie je kód zariadenia",
  "Xin gia nhập nhà": "Požiadať o pripojenie k domovu",
  "Quét mã QR chia sẻ nhà": "Naskenovať QR kód na zdieľanie domova",
  "Mời thành viên bằng mã QR": "Pozvať člena pomocou QR kódu",
  "Không thể share cho chính bạn": "Nemôžete zdieľať sami so sebou",
  "Lời mời chia sẻ nhà": "Pozvánka na zdieľanie domova",
  "Đã share home": "Domov bol zdieľaný",
  "Chuyển quyền chủ nhà": "Previesť vlastníctvo",
  "Không thể chuyển quyền cho chính bạn":
      "Vlastníctvo nemožno previesť na seba",
  "Không tìm thấy user": "Používateľ sa nenašiel",
  "Không tìm thấy tài khoản": "Účet sa nenašiel",
  "Xác nhận chuyển quyền": "Potvrdiť prevod",
  "Chuyển": "Previesť",
  "Xác nhận mật khẩu": "Potvrdiť heslo",
  "Yêu cầu chuyển quyền chủ nhà": "Žiadosť o prevod vlastníctva domova",
  "Đã gửi yêu cầu chuyển quyền": "Žiadosť o prevod bola odoslaná",
  "Đã gửi yêu cầu chuyển quyền chủ nhà":
      "Žiadosť o prevod vlastníctva domova bola odoslaná",
  "Bạn không có quyền xoá thiết bị": "Nemáte povolenie odstraňovať zariadenia",
  "Xóa Device?": "Odstrániť zariadenie?",
  "Đã gửi yêu cầu xoá thiết bị":
      "Žiadosť o odstránenie zariadenia bola odoslaná",
  "Đang xoá thiết bị": "Zariadenie sa odstraňuje",
  "Đăng xuất?": "Odhlásiť sa?",
  "Thêm nhà": "Pridať domov",
  "Thêm nhà mới": "Pridať nový domov",
  "Tạo nhà mới": "Vytvoriť nový domov",
  "Tạo một ngôi nhà mới của bạn": "Vytvorte si nový domov",
  "Quét mã QR được chủ nhà chia sẻ": "Naskenujte QR kód zdieľaný vlastníkom",
  "Tên nhà": "Názov domova",
  "Số điện thoại": "Telefónne číslo",
  "Nam": "Muž",
  "Nữ": "Žena",
  "Ngày": "Deň",
  "Tháng": "Mesiac",
  "Năm": "Rok",
  "Thông tin cá nhân": "Osobné údaje",
  "Thiết lập tài khoản": "Nastavenie účtu",
  "Vui lòng nhập đủ thông tin": "Vyplňte všetky údaje",
  "Không thể lưu thông tin": "Informácie sa nepodarilo uložiť",
  "Đã lưu thông tin": "Informácie boli uložené",
  "Lỗi lưu profile": "Chyba pri ukladaní profilu",
  "Thêm số điện thoại để dùng cho các trường hợp khẩn cấp":
      "Pridajte telefónne číslo pre núdzové situácie",
  "Hoàn tất": "Dokončiť",
  "Đã tạo nhà mới": "Nový domov bol vytvorený",
  "Về muộn": "Neskorý návrat",
  "Ra ngoài": "Odchod von",
  "Khác": "Iné",
  "⏸️ Tạm tắt báo động hôm nay": "⏸️ Dočasne vypnúť dnešný alarm",
  "Chọn giờ bắt đầu tạm tắt": "Vyberte začiatok dočasného vypnutia",
  "Từ": "Od",
  "Từ giờ": "Odteraz",
  "Chọn giờ kết thúc tạm tắt": "Vyberte koniec dočasného vypnutia",
  "Đến": "Do",
  "Đến giờ": "Do nastaveného času",
  "Xoá lịch tạm tắt": "Odstrániť plán dočasného vypnutia",
  "Xóa lịch tạm tắt": "Odstrániť plán dočasného vypnutia",
  "Giới tính": "Pohlavie",
  "SĐT": "Tel.",
  "Ngày sinh": "Dátum narodenia",
  "Yêu cầu & lời mời": "Žiadosti a pozvánky",
  "Xem lời mời chia sẻ và xin gia nhập":
      "Zobraziť pozvánky na zdieľanie a žiadosti o pripojenie",
  "Cài đặt bảo mật": "Nastavenia zabezpečenia",
  "Quyền báo động toàn màn hình": "Povolenie pre alarm na celú obrazovku",
  "Báo động toàn màn hình": "Alarm na celú obrazovku",
  "Đã được cấp quyền": "Povolenie udelené",
  "Chưa được cấp quyền": "Povolenie nebolo udelené",
  "Mở cài đặt hệ thống": "Otvoriť nastavenia systému",
  "Đăng xuất": "Odhlásiť sa",
  "Thoát tài khoản khỏi thiết bị này": "Odhlásiť účet z tohto zariadenia",
  "Không có yêu cầu hoặc lời mời nào": "Žiadne žiadosti ani pozvánky",
  "Xoá tài khoản": "Odstrániť účet",
  "Hành động này sẽ xoá toàn bộ dữ liệu:": "Táto akcia odstráni všetky údaje:",
  "Nhà và thiết bị": "Domovy a zariadenia",
  "Chia sẻ và quyền truy cập": "Zdieľanie a prístupové povolenia",
  "Toàn bộ dữ liệu liên quan": "Všetky súvisiace údaje",
  "Mật khẩu xác nhận": "Heslo na potvrdenie",
  "Đã xoá tài khoản": "Účet bol odstránený",
  "Xoá thất bại": "Odstránenie zlyhalo",
  "Lỗi xoá tài khoản": "Chyba pri odstraňovaní účtu",
  "Tình trạng": "Stav",
  "Tháo/Lắp": "Odstránenie/inštalácia",
  "Pin": "Batéria",
  "Tín hiệu": "Signál",
  "Chưa liên kết": "Nepripojené",
  "Liên lạc cuối": "Posledný kontakt",
  "Event cuối": "Posledná udalosť",
  "Sự kiện cuối": "Posledná udalosť",
  "Lần kích hoạt cuối": "Posledná aktivácia",
  "Thiết bị không còn tồn tại": "Zariadenie už neexistuje",
  "Mất kết nối": "Odpojené",
  "Online": "Online",
  "Offline": "Offline",
  "Loại thiết bị": "Typ zariadenia",
  "Nhiệt độ": "Teplota",
  "Độ ẩm": "Vlhkosť",
  "Công suất": "Výkon",
  "Điện áp": "Napätie",
  "Dòng điện": "Prúd",
  "Điện năng": "Energia",
  "Cường độ rung": "Intenzita vibrácií",
  "Góc nghiêng": "Uhol náklonu",
  "Độ mở van": "Otvorenie ventilu",
  "Nguồn dự phòng": "Záložné napájanie",
  "Ngập/rò nước": "Zaplavenie/únik vody",
  "Phát hiện khói": "Detekcia dymu",
  "Quản lý phòng": "Správa miestností",
  "Bạn không có quyền quản lý phòng": "Nemáte povolenie spravovať miestnosti",
  "Đổi tên phòng": "Premenovať miestnosť",
  "Tên phòng": "Názov miestnosti",
  "Xoá phòng": "Odstrániť miestnosť",
  "Thiết bị trong phòng này sẽ được chuyển về Chưa phân phòng.":
      "Zariadenia v tejto miestnosti budú presunuté do sekcie Nepriradené.",
  "Thêm phòng": "Pridať miestnosť",
  "Ví dụ: Phòng khách": "Napríklad: Obývacia izba",
  "Phòng khách": "Obývacia izba",
  "Tên phòng đã tồn tại": "Názov miestnosti už existuje",
  "Chưa phân phòng": "Nepriradené",
  "Phòng mặc định": "Predvolená miestnosť",
  "Phát hiện bất thường": "Zistená abnormalita",
  "Phát hiện cạy phá": "Zistený pokus o násilné otvorenie",
  "Tamper detected": "Zistená manipulácia",
  "Tamper cleared": "Manipulácia ukončená",
  "Door opened": "Dvere otvorené",
  "Door closed": "Dvere zatvorené",
  "Motion detected": "Zistený pohyb",
  "Battery low": "Nízky stav batérie",
  "Device offline": "Zariadenie offline",
  "Device online": "Zariadenie online",
  "Cửa mở": "Dvere otvorené",
  "Cửa đóng": "Dvere zatvorené",
  "Chưa đặt vị trí nhà": "Poloha domova nie je nastavená",
  "Đặt vị trí nhà tại đây": "Nastaviť polohu domova tu",
  "Hãy đặt vị trí nhà trước khi bật tự động Bảo vệ":
      "Pred zapnutím automatickej ochrany najprv nastavte polohu domova",
  "Bán kính bảo vệ mặc định: 150 m": "Predvolený polomer ochrany: 150 m",
  "Mỗi thành viên sẽ cần cấp quyền vị trí Luôn cho phép để trạng thái rời/đến nhà hoạt động khi ứng dụng chạy nền.":
      "Každý člen musí povoliť prístup k polohe Vždy, aby sa príchod a odchod z domova zaznamenával aj na pozadí.",
  "Lưu cài đặt": "Uložiť nastavenia",
  "Đã đặt vị trí nhà": "Poloha domova bola nastavená",
  "Đang lấy vị trí...": "Získava sa poloha...",
  "Đang lưu...": "Ukladanie...",
  "Đổi tên hiển thị": "Zmeniť zobrazované meno",
  "Cập nhật thông tin nhà": "Aktualizovať informácie o domove",
  "Nhập địa chỉ của nhà": "Zadajte adresu domova",
  "Lưu thay đổi": "Uložiť zmeny",
  "Tên này chỉ hiển thị riêng trên tài khoản của bạn.":
      "Tento názov sa zobrazí iba vo vašom účte.",
  "Tên và địa chỉ sẽ được cập nhật cho toàn bộ thành viên trong nhà.":
      "Názov a adresa budú aktualizované pre všetkých členov domova.",
  "Một thành viên": "Jeden člen",
  "Đã cập nhật thông tin nhà": "Informácie o domove boli aktualizované",
  "Thay tên": "Zmeniť názov",
  "Đã đổi tên thiết bị": "Názov zariadenia bol zmenený",
  "Chưa chọn nhà để kiểm tra": "Nie je vybraný domov na kontrolu",
  "Hãy thực hiện kiểm tra bằng tài khoản Owner":
      "Vykonajte kontrolu pomocou účtu vlastníka",
  "Không đọc được dữ liệu nhà": "Údaje domova sa nepodarilo načítať",
  "Nhà cần có ít nhất một thiết bị để test":
      "Domov musí mať aspoň jedno zariadenie na testovanie",
  "Đóng": "Zavrieť",
  "Đã thiết lập": "Nastavené",
  "Quét QR": "Naskenovať QR kód",
  "Quét QR để thêm thiết bị": "Naskenovať QR kód a pridať zariadenie",
  "Nhập HUB ID thủ công": "Zadať ID hubu ručne",
  "Bạn không có quyền sắp xếp phòng":
      "Nemáte povolenie meniť poradie miestností",
  "Cảnh báo khói": "Upozornenie na dym",
  "Cập nhật thiết bị": "Aktualizovať zariadenie",
  "Cửa đang mở": "Dvere sú otvorené",
  "Cửa đã đóng": "Dvere sú zatvorené",
  "Firebase Rules: CÓ LỖI": "Firebase Rules: CHYBA",
  "Firebase Rules: ĐẠT": "Firebase Rules: V PORIADKU",
  "Giờ không hợp lệ": "Neplatný čas",
  "Khôi phục mật khẩu": "Obnoviť heslo",
  "Nhập email của bạn": "Zadajte svoj e-mail",
  "Gửi": "Odoslať",
  "Đã gửi email khôi phục": "E-mail na obnovenie bol odoslaný",
  "Không gửi được email": "E-mail sa nepodarilo odoslať",
  "Vui lòng nhập email và mật khẩu": "Zadajte e-mail a heslo",
  "Mật khẩu xác nhận không khớp": "Potvrdzovacie heslo sa nezhoduje",
  "Không thể tạo tài khoản": "Účet sa nepodarilo vytvoriť",
  "Sai tài khoản": "Nesprávny účet",
  "Email đã tồn tại": "E-mail už existuje",
  "Mật khẩu quá yếu": "Heslo je príliš slabé",
  "Sai email hoặc mật khẩu": "Nesprávny e-mail alebo heslo",
  "Lỗi đăng nhập": "Chyba prihlásenia",
  "Email": "E-mail",
  "Mật khẩu": "Heslo",
  "Ghi nhớ tài khoản": "Zapamätať účet",
  "Đăng nhập": "Prihlásiť sa",
  "Đăng ký mới": "Nová registrácia",
  "Quên mật khẩu?": "Zabudli ste heslo?",
  "Chưa có tài khoản? Đăng ký": "Nemáte účet? Zaregistrujte sa",
  "Đã có tài khoản? Đăng nhập": "Máte účet? Prihláste sa",
  "Tính năng đang được phát triển": "Táto funkcia sa vyvíja",
  "Thông báo": "Oznámenia",
  "Chat trong nhà": "Domáci chat",
  "Tìm kiếm tin nhắn": "Hľadať správy",
  "Xem thành viên": "Zobraziť členov",
  "Tìm nội dung hoặc tên người gửi": "Hľadať obsah alebo meno odosielateľa",
  "Xoá từ khoá": "Vymazať hľadaný výraz",
  "Không có kết quả": "Žiadne výsledky",
  "Tìm ngôn ngữ": "Hľadať jazyk",
  "Kết quả trước": "Predchádzajúci výsledok",
  "Kết quả tiếp theo": "Ďalší výsledok",
  "Chưa có tin nhắn": "Zatiaľ žiadne správy",
  "Không tìm thấy thành viên phù hợp": "Nenašiel sa žiadny zodpovedajúci člen",
  "Nhắc đến trong tin nhắn": "Spomenúť v správe",
  "Huỷ trả lời": "Zrušiť odpoveď",
  "Nhắn gì đó...": "Napíšte správu...",
  "Gọi điện": "Volať",
  "Báo động thiết bị": "Alarm zariadenia",
  "Chế độ áp dụng": "Režim použitia",
  "Theo nhà": "Podľa domova",
  "Riêng tôi": "Iba pre mňa",
  "Dùng lịch chung do Chủ nhà hoặc Quản trị viên thiết lập":
      "Použiť spoločný rozvrh nastavený vlastníkom alebo správcom",
  "Dùng lịch riêng chỉ áp dụng cho tài khoản của bạn":
      "Použiť osobný rozvrh platný iba pre váš účet",
  "Thiết lập nhanh báo động": "Rýchle nastavenie alarmu",
  "Thiết lập nhanh toàn bộ thiết bị": "Rýchle nastavenie všetkých zariadení",
  "Áp dụng cho toàn bộ thiết bị": "Použiť na všetky zariadenia",
  "Bắt đầu": "Začiatok",
  "Kết thúc": "Koniec",
  "Thời gian lặp lại": "Interval opakovania",
  "Không lặp lại": "Neopakovať",
  "Quét QR HUB": "Naskenovať QR kód hubu",
  "Đưa mã QR vào giữa khung": "Umiestnite QR kód do stredu rámčeka",
  "Đang áp dụng...": "Používa sa...",
  "Hôm nay đã ghi nhận cảnh báo SOS": "Dnes bolo zaznamenané upozornenie SOS",
  "Hôm nay đã ghi nhận cảnh báo khói":
      "Dnes bolo zaznamenané upozornenie na dym",
  "Khói đã an toàn": "Stav dymu je opäť bezpečný",
  "Không tìm thấy nhà của thông báo này": "Domov tohto oznámenia sa nenašiel",
  "Không tìm thấy thiết bị trong nhà này":
      "Zariadenie sa v tomto domove nenašlo",
  "Một chủ nhà": "Jeden vlastník",
  "Ngôi nhà đang hoạt động ổn định": "Domov funguje stabilne",
  "Nhiệt độ cao": "Vysoká teplota",
  "OK": "OK",
  "Pin yếu": "Nízky stav batérie",
  "SOS đã kết thúc": "SOS ukončené",
  "SOS được kích hoạt": "SOS aktivované",
  "Tamper bình thường": "Bez známok manipulácie",
  "Thiết bị bị tháo": "Zariadenie bolo odstránené",
  "Thiết bị mới": "Nové zariadenie",
  "Thiết bị offline": "Zariadenie offline",
  "Thiết bị online": "Zariadenie online",
  "Báo động kích hoạt": "Alarm aktivovaný",
  "Báo động đã tắt": "Alarm vypnutý",
  "Tạm tắt báo động hôm nay": "Dočasne vypnúť dnešný alarm",
  "Độ ẩm cao": "Vysoká vlhkosť",
  "Thử lại": "Skúsiť znova",
  "Không thể tải dữ liệu tài khoản": "Údaje účtu sa nepodarilo načítať",
  "Không": "Nie",
  "Đã chia sẻ nhà thành công.": "Domov bol úspešne zdieľaný.",
  "Tìm nhà...": "Hľadať domov...",
  "Đã rời khỏi nhà": "Opustili ste domov",
  "Bạn sẽ rời khỏi các nhà được chia sẻ.": "Opustíte zdieľané domovy.",
  "Các nhà của bạn sẽ bị xoá.\n": "Vaše domovy budú odstránené.\n",
  "Thao tác này sẽ thay đổi lịch báo động của toàn bộ thiết bị an ninh trong các nhà đã chọn.\n\n":
      "Táto akcia zmení rozvrh alarmu všetkých bezpečnostných zariadení vo vybraných domovoch.\n\n",
  "Thao tác này sẽ thêm nhắc nhở cho các nhà đã chọn.\n\n":
      "Táto akcia pridá pripomienky pre vybrané domovy.\n\n",
  "Xác nhận thay đổi báo động": "Potvrdiť zmeny alarmu",
  "Xác nhận thay đổi nhắc nhở": "Potvrdiť zmeny pripomienok",
  "Lặp lại khi sự cố vẫn còn": "Opakovať, kým problém trvá",
  "Thời gian lặp lại báo động": "Interval opakovania alarmu",
  "VD: Mr Chung": "Napr.: Mr Chung",
  "🏡 Chưa có nhà nào": "🏡 Zatiaľ žiadne domovy",
  "Vẫn chuyển về Bình thường": "Napriek tomu prepnúť na Normálny",
  "Tự động Bảo vệ khi rời nhà vẫn đang bật. Nếu mọi thành viên vẫn ở ngoài, hệ thống có thể tự bật lại Bảo vệ sau vài phút.":
      "Automatická ochrana pri odchode je stále zapnutá. Ak sú všetci členovia stále mimo domova, systém môže po niekoľkých minútach ochranu znovu automaticky zapnúť.",
  "Chuyển về Bình thường?": "Prepnúť na Normálny?",
  "Khi bật, các thiết bị an ninh sẽ được giám sát ngay.\n\n":
      "Po zapnutí budú bezpečnostné zariadenia okamžite sledované.\n\n",
  "Bật Bảo vệ thủ công?": "Zapnúť manuálnu ochranu?",
  "Hành động này sẽ thay đổi thời gian báo động của một số thiết bị ":
      "Táto akcia zmení čas alarmu niektorých zariadení",
  "Hành động này sẽ tắt toàn bộ báo động của nhà ":
      "Táto akcia vypne všetky alarmy domova",
  "Tắt toàn bộ báo động?": "Vypnúť všetky alarmy?",
  "Không xoá được lịch tạm tắt báo động":
      "Plán dočasného vypnutia alarmu sa nepodarilo odstrániť",
  "Không lưu được tạm tắt báo động":
      "Dočasné vypnutie alarmu sa nepodarilo uložiť",
  "Không gửi được yêu cầu xoá": "Žiadosť o odstránenie sa nepodarilo odoslať",
  "Không lưu được cài đặt": "Nastavenia sa nepodarilo uložiť",
  "Không lấy được vị trí hiện tại": "Aktuálnu polohu sa nepodarilo získať",
  "Không thể xác nhận tài khoản hiện tại": "Aktuálny účet sa nepodarilo overiť",
  "Mật khẩu không đúng": "Nesprávne heslo",
  "Không thể xác nhận mật khẩu": "Heslo sa nepodarilo overiť",
  "Chỉ Chủ nhà hoặc Quản trị viên mới có quyền thay đổi lặp báo động":
      "Opakovanie alarmu môže meniť iba vlastník alebo správca",
  "Không lưu được thời gian lặp báo động":
      "Interval opakovania alarmu sa nepodarilo uložiť",
  "Chỉ Chủ nhà hoặc Quản trị viên mới có quyền thay đổi Chế độ Bảo vệ":
      "Režim ochrany môže meniť iba vlastník alebo správca",
  "Không thể thay đổi chế độ nhà": "Režim domova sa nepodarilo zmeniť",
  "Đã bật Bảo vệ nhưng chưa gửi được thông báo":
      "Ochrana bola zapnutá, ale oznámenie sa nepodarilo odoslať",
  "Đã bật Chế độ Bảo vệ thủ công": "Manuálny režim ochrany bol zapnutý",
  "Đã chuyển nhà về Bình thường": "Domov bol prepnutý do normálneho režimu",
  "60 phút": "60 minút",
  "30 phút": "30 minút",
  "15 phút": "15 minút",
  "Bạn đang xem lịch của chủ nhà. Chọn Riêng tôi để tự đặt lịch báo động.":
      "Prezeráte rozvrh vlastníka. Ak chcete nastaviť vlastný rozvrh alarmu, vyberte Iba pre mňa.",
  "Chọn giờ kết thúc báo động": "Vyberte čas ukončenia alarmu",
  "Chọn giờ bắt đầu báo động": "Vyberte čas začiatku alarmu",
  "Bạn không có quyền sửa lịch báo động của nhà":
      "Nemáte povolenie upravovať rozvrh alarmu domova",
  "Không thể áp dụng báo động cho toàn bộ thiết bị":
      "Alarm sa nepodarilo použiť na všetky zariadenia",
  "Nhà chưa có thiết bị an ninh để áp dụng":
      "Domov nemá žiadne bezpečnostné zariadenia, na ktoré možno nastavenie použiť",
  "Bạn không có quyền sửa lịch Theo nhà. Hãy chọn Riêng tôi.":
      "Nemáte povolenie upravovať rozvrh Podľa domova. Vyberte Iba pre mňa.",
  "Không thể lưu chế độ báo động": "Režim alarmu sa nepodarilo uložiť",
  "Thêm nhắc nhở": "Pridať pripomienku",
  "Nhắc nhở sẽ nhắc bạn kiểm tra trạng thái an toàn của ngôi nhà vào giờ đã chọn.":
      "Pripomienka vás vo zvolenom čase upozorní, aby ste skontrolovali bezpečnostný stav domova.",
  "Thêm khung giờ báo động": "Pridať časové obdobie alarmu",
  "Đang sử dụng nhắc nhở riêng của bạn": "Používajú sa vaše osobné pripomienky",
  "Đang sử dụng nhắc nhở của chủ nhà": "Používajú sa pripomienky vlastníka",
  "Sửa giờ nhắc nhở": "Upraviť čas pripomienky",
  "Sửa giờ kết thúc báo động": "Upraviť čas ukončenia alarmu",
  "Sửa giờ bắt đầu báo động": "Upraviť čas začiatku alarmu",
  "Xoá nhắc nhở": "Odstrániť pripomienku",
  "Mỗi 1 giờ": "Každú hodinu",
  "Mỗi 30 phút": "Každých 30 minút",
  "Mỗi 15 phút": "Každých 15 minút",
  "Không báo lại": "Znova neupozorňovať",
  "Báo lại khi vẫn chưa an toàn":
      "Znova upozorniť, ak stav stále nie je bezpečný",
  "Báo lại mỗi 1 giờ": "Upozorňovať každú hodinu",
  "Báo lại mỗi 30 phút": "Upozorňovať každých 30 minút",
  "Báo lại mỗi 15 phút": "Upozorňovať každých 15 minút",
  "Quản lý nhà": "Spravovať domov",
  "Xoá thành viên": "Odstrániť člena",
  "Đã xoá thành viên": "Člen bol odstránený",
  "Đồng ý": "Súhlasím",
  "Bạn chắc chắn muốn rời khỏi nhà này?": "Naozaj chcete opustiť tento domov?",
  "Xoá thành viên?": "Odstrániť člena?",
  "Rời khỏi nhà?": "Opustiť domov?",
  "Chỉ chủ nhà mới được thay đổi vai trò": "Roly môže meniť iba vlastník",
  "Bạn không có quyền xoá thành viên này":
      "Nemáte povolenie odstrániť tohto člena",
  "Bạn": "Vy",
  "Không có email": "Bez e-mailu",
  "Chưa có số điện thoại": "Telefónne číslo nebolo pridané",
  "Không mở được ứng dụng gọi điện":
      "Aplikáciu na volanie sa nepodarilo otvoriť",
  "Thành viên chưa cập nhật số điện thoại":
      "Člen zatiaľ nepridal telefónne číslo",
  "Bảo vệ thủ công đang bật - chỉ tắt khi chuyển về Bình thường":
      "Manuálna ochrana je zapnutá a vypne sa iba prepnutím do normálneho režimu",
  "Thời gian lặp": "Interval opakovania",
  "Chọn 0 để chỉ báo một lần. Cài đặt này dùng cho cả Bảo vệ thủ công và Tự động Bảo vệ khi rời nhà.":
      "Zvoľte 0 pre jediné upozornenie. Toto nastavenie platí pre manuálnu ochranu aj automatickú ochranu pri odchode z domova.",
  "Lặp báo động khi sự cố vẫn còn": "Opakovať alarm, kým problém trvá",
  "Đang được sử dụng": "Používa sa",
  "Chuyển về sử dụng thông thường": "Prepnúť späť na bežné používanie",
  "Chế độ nhà": "Režim domova",
  "Thiết bị SOS chưa ghi nhận cảnh báo.":
      "Zariadenie SOS zatiaľ nezaznamenalo žiadne upozornenie.",
  "Cảm biến khói chưa ghi nhận bất thường.":
      "Detektor dymu nezaznamenal žiadnu abnormalitu.",
  "Bạn hoặc thành viên đã chủ động bật Bảo vệ.":
      "Vy alebo iný člen ste manuálne zapli ochranu.",
  "SafeHome tự bật Bảo vệ vì bạn đã rời khỏi nhà.":
      "SafeHome automaticky zapol ochranu, pretože ste opustili domov.",
  "Nhà đang ở chế độ dùng bình thường.":
      "Domov je v režime bežného používania.",
  "Bảo vệ thủ công đang bật": "Manuálna ochrana je zapnutá",
  "Bảo vệ tự động đang bật": "Automatická ochrana je zapnutá",
  "Bảo vệ đang tắt": "Ochrana je vypnutá",
  "Bạn đã mở ứng dụng gần đây để kiểm tra trạng thái.":
      "Nedávno ste aplikáciu otvorili a skontrolovali stav.",
  "Bạn nên mở ứng dụng định kỳ để kiểm tra quyền, lịch và cảnh báo chưa đọc.":
      "Pravidelne otvárajte aplikáciu a kontrolujte povolenia, rozvrhy a neprečítané upozornenia.",
  "Sau vài lần sử dụng, SafeHome sẽ đánh giá thói quen kiểm tra ứng dụng tốt hơn.":
      "Po niekoľkých použitiach bude SafeHome lepšie vyhodnocovať vaše návyky pri kontrole aplikácie.",
  "Tần suất vào ứng dụng ổn": "Frekvencia používania aplikácie je v poriadku",
  "Đã lâu chưa vào ứng dụng kiểm tra":
      "Aplikáciu ste už dlho neotvorili na kontrolu",
  "Đang ghi nhận tần suất vào ứng dụng":
      "Zaznamenáva sa frekvencia používania aplikácie",
  "Cần kiểm tra quyền vị trí luôn luôn và điều kiện chạy nền.":
      "Skontrolujte povolenie polohy Vždy a podmienky behu na pozadí.",
  "Thiết bị đủ điều kiện để Auto rời khỏi nhà hoạt động.":
      "Zariadenie spĺňa podmienky pre automatickú ochranu pri odchode z domova.",
  "Bạn có thể bật khi muốn tự động chuyển Bảo vệ lúc rời nhà.":
      "Môžete ju zapnúť, ak chcete pri odchode z domova automaticky prepnúť do režimu ochrany.",
  "Auto rời khỏi nhà chưa ổn":
      "Automatická ochrana pri odchode ešte nie je pripravená",
  "Auto rời khỏi nhà đã sẵn sàng":
      "Automatická ochrana pri odchode je pripravená",
  "Auto rời khỏi nhà chưa bật":
      "Automatická ochrana pri odchode nie je zapnutá",
  "Nên thêm báo khói, SOS hoặc thiết bị khẩn cấp phù hợp với nhà.":
      "Odporúčame pridať detektor dymu, SOS tlačidlo alebo iné vhodné núdzové zariadenie.",
  "Chưa có thiết bị khẩn cấp": "Žiadne núdzové zariadenia",
  "Đã có thiết bị khẩn cấp": "Núdzové zariadenia sú k dispozícii",
  "Nên đặt lịch báo động cho thời gian ngủ hoặc vắng nhà.":
      "Odporúčame nastaviť rozvrh alarmu na čas spánku alebo neprítomnosti.",
  "Nhà đã có lịch báo động hoặc lịch cảnh báo theo thiết bị.":
      "Domov už má rozvrh alarmu alebo upozornenia podľa zariadenia.",
  "Chưa cài lịch báo động": "Rozvrh alarmu nie je nastavený",
  "Đã cài lịch báo động": "Rozvrh alarmu je nastavený",
  "Nên có ít nhất một nhắc nhở để không quên kiểm tra nhà.":
      "Odporúčame nastaviť aspoň jednu pripomienku, aby ste nezabudli skontrolovať domov.",
  "Ứng dụng sẽ nhắc bạn kiểm tra nhà theo lịch đã đặt.":
      "Aplikácia vám podľa nastaveného rozvrhu pripomenie kontrolu domova.",
  "Chưa cài đặt nhắc nhở": "Pripomienky nie sú nastavené",
  "Đã cài đặt nhắc nhở": "Pripomienky sú nastavené",
  "Hãy mở lại ứng dụng hoặc đăng nhập lại nếu thiết bị không nhận cảnh báo.":
      "Ak zariadenie neprijíma upozornenia, znova otvorte aplikáciu alebo sa znova prihláste.",
  "Thiết bị chưa đăng ký nhận cảnh báo":
      "Zariadenie nie je zaregistrované na prijímanie upozornení",
  "Thiết bị nhận cảnh báo bình thường":
      "Zariadenie prijíma upozornenia normálne",
  "iOS quản lý chạy nền chặt hơn Android; hãy giữ thông báo và vị trí luôn luôn nếu dùng Auto rời khỏi nhà.":
      "iOS obmedzuje beh na pozadí prísnejšie než Android. Ak používate automatickú ochranu pri odchode, ponechajte oznámenia a polohu Vždy povolené.",
  "Cơ chế iOS": "Mechanizmus iOS",
  "Hãy kiểm tra quyền chạy nền và tự khởi động để cảnh báo không bị trễ.":
      "Skontrolujte beh na pozadí a automatické spúšťanie, aby upozornenia neboli oneskorené.",
  "Thiết bị đã xác nhận các điều kiện chạy nền quan trọng.":
      "Zariadenie potvrdilo dôležité podmienky pre beh na pozadí.",
  "Cần kiểm tra chạy nền / tự khởi động":
      "Skontrolujte beh na pozadí / automatické spúšťanie",
  "Chạy nền ổn định": "Stabilný beh na pozadí",
  "Một số máy Android có thể trì hoãn cảnh báo nếu tối ưu pin còn bật.":
      "Niektoré telefóny Android môžu upozornenia oneskoriť, ak je zapnutá optimalizácia batérie.",
  "Điện thoại ít có khả năng trì hoãn cảnh báo SafeHome.":
      "Pri tomto telefóne je menšia pravdepodobnosť oneskorenia upozornení SafeHome.",
  "Chưa tắt tối ưu pin": "Optimalizácia batérie nebola vypnutá",
  "Tối ưu pin không chặn ứng dụng": "Optimalizácia batérie aplikáciu neblokuje",
  "Auto rời khỏi nhà cần quyền vị trí luôn luôn để chạy ổn định.":
      "Automatická ochrana pri odchode vyžaduje na stabilnú prevádzku povolenie polohy Vždy.",
  "Cần cấp quyền vị trí để Auto rời khỏi nhà hoạt động.":
      "Povoľte prístup k polohe, aby automatická ochrana pri odchode fungovala.",
  "Dịch vụ vị trí đang tắt nên Auto rời khỏi nhà không ổn định.":
      "Lokalizačné služby sú vypnuté, takže automatická ochrana pri odchode nemusí fungovať stabilne.",
  "Chỉ cần quyền này khi dùng Auto rời khỏi nhà.":
      "Toto povolenie je potrebné iba pre automatickú ochranu pri odchode.",
  "Chưa cấp vị trí luôn luôn": "Poloha Vždy nie je povolená",
  "Đã cấp vị trí luôn luôn": "Poloha Vždy je povolená",
  "iOS không mở toàn màn hình như Android; ứng dụng dùng thông báo và âm thanh hệ thống.":
      "iOS neotvára upozornenia na celú obrazovku ako Android; aplikácia používa oznámenia a systémové zvuky.",
  "Android dùng cảnh báo toàn màn hình; nếu máy chặn, hãy cấp quyền trong cài đặt.":
      "Android používa upozornenia na celú obrazovku. Ak ich telefón blokuje, udeľte povolenie v nastaveniach.",
  "Cảnh báo trên iOS": "Upozornenia v iOS",
  "Cảnh báo toàn màn hình": "Upozornenie na celú obrazovku",
  "Cảnh báo có thể không hiển thị nếu thông báo bị tắt.":
      "Ak sú oznámenia vypnuté, upozornenia sa nemusia zobraziť.",
  "Điện thoại có thể nhận thông báo SafeHome.":
      "Telefón môže prijímať oznámenia SafeHome.",
  "Chưa bật thông báo": "Oznámenia nie sú zapnuté",
  "Đã bật thông báo": "Oznámenia sú zapnuté",
  "Hệ thống: Sẵn sàng": "Systém: Pripravený",
  "Hệ thống: Có thể bỏ lỡ cảnh báo": "Systém: Upozornenia môžu byť zmeškané",
  "Cách bạn đang dùng ứng dụng": "Ako aplikáciu používate",
  "Thiết bị của bạn": "Vaše zariadenie",
  "Kiểm tra điện thoại và cách bạn đang dùng ứng dụng.":
      "Skontrolujte telefón a spôsob používania aplikácie.",
  "Hệ thống SafeHome": "Systém SafeHome",
  "Hệ thống: Đang kiểm tra...": "Systém: Prebieha kontrola...",
  "Tên": "Meno",
  "Bạn không có quyền thay đổi vị trí nhà":
      "Nemáte povolenie meniť polohu domova",
  "Hãy bật GPS để đặt vị trí nhà":
      "Zapnite GPS, aby ste mohli nastaviť polohu domova",
  "Bạn chưa cấp quyền vị trí": "Nepovolili ste prístup k polohe",
  "Hãy cấp quyền vị trí trong Cài đặt ứng dụng":
      "Povoľte prístup k polohe v nastaveniach aplikácie",
  "Đã bật tự động Bảo vệ khi mọi người rời nhà":
      "Automatická ochrana pri odchode všetkých členov bola zapnutá",
  "Đã tắt tự động Bảo vệ khi mọi người rời nhà":
      "Automatická ochrana pri odchode všetkých členov bola vypnutá",
  "Không thể thay đổi trạng thái báo động": "Stav alarmu sa nepodarilo zmeniť",
  "Đã tắt toàn bộ báo động của nhà": "Všetky alarmy domova boli vypnuté",
  "QR này không phải mã xin gia nhập Home":
      "Tento QR kód nie je určený na žiadosť o pripojenie k domovu",
  "Thêm Home": "Pridať domov",
  "Mở cài đặt": "Otvoriť nastavenia",
  "Để sau": "Neskôr",
  "SafeHome cần quyền vị trí \"Luôn cho phép\" để nhận biết khi bạn rời hoặc trở về nhà, kể cả khi ứng dụng đang chạy nền.":
      "SafeHome potrebuje povolenie polohy „Vždy“, aby rozpoznal váš odchod a návrat domov, aj keď aplikácia beží na pozadí.",
  "SafeHome hiện chỉ được truy cập vị trí khi bạn đang sử dụng ứng dụng.\n\nHãy chọn quyền Vị trí và chuyển sang \"Luôn cho phép\" để tính năng tự động Bảo vệ khi rời nhà hoạt động khi ứng dụng đang chạy nền.":
      "SafeHome má teraz prístup k polohe iba pri používaní aplikácie.\n\nOtvorte nastavenie Polohy a zvoľte „Vždy“, aby automatická ochrana pri odchode fungovala aj na pozadí.",
  "Cho phép vị trí luôn luôn": "Povoliť polohu Vždy",
  "Các nhà của bạn sẽ bị xoá.\nCác nhà được chia sẻ sẽ được rời khỏi.":
      "Vaše domovy budú odstránené.\nZdieľané domovy budú opustené.",
  "Thao tác này sẽ thay đổi lịch báo động của toàn bộ thiết bị an ninh trong các nhà đã chọn.\n\nNhững thành viên đang sử dụng báo động 'Theo nhà' sẽ bị ảnh hưởng.\nBáo động cá nhân ở chế độ 'Riêng tôi' sẽ không bị thay đổi.":
      "Táto akcia zmení rozvrh alarmu všetkých bezpečnostných zariadení vo vybraných domovoch.\n\nOvplyvní členov, ktorí používajú alarm Podľa domova.\nOsobné alarmy v režime Iba pre mňa sa nezmenia.",
  "Thao tác này sẽ thêm nhắc nhở cho các nhà đã chọn.\n\nNhững thành viên đang sử dụng nhắc nhở 'Theo nhà' sẽ bị ảnh hưởng.\nNhắc nhở cá nhân ở chế độ 'Riêng tôi' sẽ không bị thay đổi.":
      "Táto akcia pridá pripomienky pre vybrané domovy.\n\nOvplyvní členov, ktorí používajú pripomienky Podľa domova.\nOsobné pripomienky v režime Iba pre mňa sa nezmenia.",
  "Khi bật, các thiết bị an ninh sẽ được giám sát ngay.\n\nTự động Bảo vệ khi rời nhà sẽ tạm dừng. Chế độ này không tự tắt khi có người về nhà và chỉ được tắt khi một thành viên có quyền chủ động chuyển về Bình thường.":
      "Po zapnutí budú bezpečnostné zariadenia okamžite sledované.\n\nAutomatická ochrana pri odchode bude pozastavená. Tento režim sa automaticky nevypne, keď sa niekto vráti domov, a možno ho vypnúť iba ručným prepnutím oprávneného člena do normálneho režimu.",
  "Hành động này sẽ thay đổi thời gian báo động của một số thiết bị trong hôm nay...":
      "Táto akcia zmení dnešný čas alarmu niektorých zariadení...",
  "Hành động này sẽ tắt toàn bộ báo động của nhà dưới mọi hình thức. Bạn sẽ không còn nhận được cảnh báo khi có nguy hiểm trên điện thoại nữa.":
      "Táto akcia vypne všetky alarmy domova vo všetkých režimoch. Pri nebezpečenstve už nebudete dostávať upozornenia do telefónu.",
  "Báo động đang sử dụng chế độ Theo nhà.\n\nBạn sẽ nhận cảnh báo theo lịch báo động chung do Chủ nhà hoặc Quản trị viên thiết lập.":
      "Alarm používa režim Podľa domova.\n\nUpozornenia budete dostávať podľa spoločného rozvrhu alarmu nastaveného vlastníkom alebo správcom.",
  "Báo động đang sử dụng chế độ Riêng tôi.\n\nBạn sẽ nhận cảnh báo theo lịch báo động riêng đã thiết lập cho tài khoản này.":
      "Alarm používa režim Iba pre mňa.\n\nUpozornenia budete dostávať podľa osobného rozvrhu alarmu nastaveného pre tento účet.",
  "Không thể đăng nhập bằng Google": "Prihlásenie cez Google zlyhalo",
  "Không đặt được mật khẩu": "Heslo sa nepodarilo nastaviť",
  "Chấp nhận": "Prijať",
  "Cho phép": "Povoliť",
  "Không thể chấp nhận lời mời. Vui lòng thử lại.":
      "Pozvánku sa nepodarilo prijať. Skúste to znova.",
  "Không thể chấp nhận lời xin vào nhà. Vui lòng thử lại.":
      "Žiadosť o pripojenie k domovu sa nepodarilo prijať. Skúste to znova.",
  "Từ chối": "Odmietnuť",
  "Lời mời từ chủ nhà": "Pozvánka od vlastníka",
  "Nhận quyền chủ nhà": "Prevziať vlastníctvo domova",
  "Một người dùng SafeHome": "Používateľ SafeHome",
  "Lời mời gia nhập": "Pozvánka na pripojenie",
  "Lời xin vào nhà": "Žiadosť o pripojenie k domovu",
  "Nhập HUB ID": "Zadajte ID hubu",
  "VD: HUB_001": "Napr.: HUB_001",
  "Pair": "Spárovať",
  "Mật khẩu tối thiểu 6 ký tự": "Heslo musí mať aspoň 6 znakov",
  "Mật khẩu nhập lại không khớp": "Zadané heslá sa nezhodujú",
  "Tạo mật khẩu": "Vytvoriť heslo",
  "Mật khẩu mới": "Nové heslo",
  "Nhập lại mật khẩu": "Zadajte heslo znova",
  "Xác nhận tắt cảnh báo": "Potvrdiť vypnutie upozornenia",
  "HỦY": "ZRUŠIŤ",
  "XÁC NHẬN": "POTVRDIŤ",
  "CẦN KIỂM TRA": "VYŽADUJE KONTROLU",
  "KIỂM TRA NHÀ": "SKONTROLOVAŤ DOMOV",
  "ĐÓNG NHẮC NHỞ": "ZAVRIEŤ PRIPOMIENKU",
  "SafeHome Security Alert": "Bezpečnostné upozornenie SafeHome",
  "Hãy chọn quyền vị trí Luôn cho phép trong Cài đặt ứng dụng":
      "V nastaveniach aplikácie vyberte povolenie polohy Vždy",
  "Tài khoản Google cần tạo thêm mật khẩu để dùng các chức năng bảo mật.":
      "Na používanie bezpečnostných funkcií je pri účte Google potrebné vytvoriť ďalšie heslo.",
  "Báo động": "Alarm",
  "Bạn không có quyền thực hiện thao tác này。":
      "Na vykonanie tejto akcie nemáte povolenie.",
  "Cài đặt": "Nastavenia",
  "Cập nhật": "Aktualizovať",
  "Chọn ngôn ngữ": "Vybrať jazyk",
  "Chưa có dữ liệu thiết bị để đánh giá":
      "Nie sú k dispozícii údaje zariadenia na vyhodnotenie",
  "Chuyển quyền sở hữu cho thành viên khác":
      "Previesť vlastníctvo na iného člena",
  "Có": "Áno",
  "Cửa đã đóng an toàn": "Dvere sú bezpečne zatvorené",
  "Đã xảy ra lỗi. Vui lòng thử lại.": "Vyskytla sa chyba. Skúste to znova.",
  "Đang kiểm tra kết nối Hub": "Kontrola pripojenia hubu",
  "Đang mở khi nhà ở chế độ Bảo vệ": "Otvorené, keď je domov v režime ochrany",
  "Đang mở trong giờ báo động": "Otvorené počas času alarmu",
  "Đang tải...": "Načítava sa...",
  "Hồ sơ, yêu cầu và lời mời tham gia": "Profil, žiadosti a pozvánky",
  "Hub chưa gửi trạng thái": "Hub zatiaľ neodoslal stav",
  "Hub mất kết nối": "Hub je odpojený",
  "Hub tín hiệu bình thường": "Signál hubu je v poriadku",
  "Khóa đang mở khi nhà ở chế độ Bảo vệ":
      "Zámok je odomknutý, keď je domov v režime ochrany",
  "Khóa đang mở trong giờ báo động": "Zámok je odomknutý počas času alarmu",
  "Không có thông báo": "Žiadne oznámenia",
  "Khu vực nguy hiểm": "Nebezpečná oblasť",
  "Kiểm tra thiết bị trong nhà này": "Skontrolovať zariadenia v tomto domove",
  "Mất điện lưới": "Výpadok elektrickej siete",
  "Mời người khác tham gia nhà này": "Pozvať ďalších ľudí do tohto domova",
  "Môi trường hiện tại": "Aktuálne prostredie",
  "MQTT mất kết nối": "MQTT je odpojené",
  "Ngôn ngữ": "Jazyk",
  "Nhà đã chia sẻ": "Domov bol zdieľaný",
  "Nhà đang hoạt động bình thường": "Domov funguje normálne",
  "Nhập email": "Zadajte e-mail",
  "Phòng": "Miestnosť",
  "Quản trị viên": "Správca",
  "Nhắc nhở": "Pripomienka",
  "SafeHome": "SafeHome",
  "Sóng yếu": "Slabý signál",
  "SOS": "SOS",
  "Tài khoản & hệ thống": "Účet a systém",
  "Tài khoản cá nhân": "Osobný účet",
  "Tạo tài khoản": "Vytvoriť účet",
  "Thành viên": "Člen",
  "Thành viên trong nhà": "Členovia domova",
  "Thành viên đang ở trong nhà": "Členovia, ktorí sú doma",
  "Thành viên đang ở ngoài": "Členovia, ktorí sú mimo domova",
  "Thành viên chưa xác định vị trí": "Členovia s neznámou polohou",
  "Thay đổi ngôn ngữ hiển thị": "Zmeniť jazyk zobrazenia",
  "Thêm, đổi tên và sắp xếp phòng":
      "Pridávať, premenovávať a zoraďovať miestnosti",
  "Thiết bị đang được giám sát": "Zariadenie je sledované",
  "Tiếng Anh": "Angličtina",
  "Tiếng Hàn": "Kórejčina",
  "Tiếng Nhật": "Japončina",
  "Tiếng Trung": "Čínština",
  "Tiếng Việt": "Vietnamčina",
  "Toàn bộ thiết bị": "Všetky zariadenia",
  "Vai trò": "Rola",
  "Về nhà": "Domov",
  "Xem và quản lý quyền thành viên": "Zobraziť a spravovať oprávnenia členov",
  "Xóa": "Odstrániť",
  "Xóa nhà": "Odstrániť domov",
  "Xoá toàn bộ dữ liệu và thiết bị": "Odstrániť všetky údaje a zariadenia",
  "TẮT CẢNH BÁO": "VYPNÚŤ UPOZORNENIE",
  "Đã tạo nhà": "Domov bol vytvorený",
  "Chế độ Bảo vệ thủ công đã bật": "Manuálny režim ochrany bol zapnutý",
  "Báo động không lặp lại.": "Alarm sa nebude opakovať.",
  "Báo động lặp sau \$securityModeRepeatMinutes phút nếu sự cố vẫn còn.":
      "Ak incident stále trvá, alarm sa zopakuje o \$securityModeRepeatMinutes minút.",
  "\$actorName đã bật Chế độ Bảo vệ thủ công cho \"\$homeName\". Chế độ này chỉ tắt khi một thành viên có quyền chủ động chuyển về Bình thường. \$repeatMessage":
      "\$actorName zapol/zapla manuálny režim ochrany pre „\$homeName“. Tento režim sa vypne iba vtedy, keď ho oprávnený člen manuálne prepne späť na Normálny. \$repeatMessage",
  "Bạn đã bật báo động cho nhà \"\$homeName\".":
      "Zapli ste alarm pre domov „\$homeName“.",
  "Bạn đã tắt toàn bộ báo động của nhà \"\$homeName\".":
      "Vypli ste všetky alarmy domova „\$homeName“.",
  "Thành viên mới": "Nový člen",
  "Thành viên rời nhà": "Člen odišiel z domu",
  "\$displayMemberName đã rời khỏi nhà \"\$homeName\".":
      "\$displayMemberName opustil(a) domov „\$homeName“.",
  "\$actorName đã đổi vai trò của \$memberName từ \$oldRoleName thành \$newRoleName trong nhà \"\$homeName\".":
      "\$actorName zmenil(a) rolu používateľa \$memberName v domove „\$homeName“ z \$oldRoleName na \$newRoleName.",
  "Còn \$count tin nhắn chưa đọc": "Zostáva \$count neprečítaných správ",
  "Hãy an tâm nghỉ ngơi.": "Môžete pokojne odpočívať.",
  "Có thiết bị chưa an toàn.": "Niektoré zariadenia nie sú v bezpečnom stave.",
  "SafeHome đang cập nhật vị trí": "SafeHome aktualizuje polohu",
  "Đang theo dõi để tự động bật Chế độ Bảo vệ.":
      "Prebieha sledovanie na automatické zapnutie režimu ochrany.",
  "Dùng vị trí để tự động bật Chế độ Bảo vệ khi mọi người rời nhà.":
      "Použiť polohu na automatické zapnutie režimu ochrany, keď všetci odídu z domu.",
  "CẢNH BÁO SOS": "UPOZORNENIE SOS",
  "CẢNH BÁO KHÓI / CHÁY": "UPOZORNENIE NA DYM / POŽIAR",
  "CẢNH BÁO NGẬP NƯỚC": "UPOZORNENIE NA ZAPLAVENIE",
  "CẢNH BÁO RÒ KHÍ": "UPOZORNENIE NA ÚNIK PLYNU",
  "CẢNH BÁO CỬA": "UPOZORNENIE DVERÍ",
  "CẢNH BÁO AN NINH": "BEZPEČNOSTNÉ UPOZORNENIE",
  "Không thể xác nhận với SafeHome. Hãy kiểm tra kết nối và thử lại.":
      "Potvrdenie so službou SafeHome zlyhalo. Skontrolujte pripojenie a skúste to znova.",
  "Chỉ tắt cảnh báo khi bạn đã kiểm tra tình trạng trong nhà.\n\nBạn chắc chắn muốn tắt cảnh báo?":
      "Upozornenie vypnite až po kontrole situácie v dome.\n\nNaozaj chcete upozornenie vypnúť?",
  "🚨 SafeHome phát hiện cảnh báo": "🚨 SafeHome zistil upozornenie",
  "Mở SafeHome để kiểm tra ngay.":
      "Otvorte SafeHome a ihneď všetko skontrolujte.",
  "\$count tin nhắn mới": "\$count nových správ",
  "Tin nhắn HomeChat": "Správy HomeChat",
  "\$senderName đã gửi một tin nhắn": "\$senderName poslal(a) správu",
  "Bạn có tin nhắn mới": "Máte novú správu",
  "Chế độ Bảo vệ sẽ chỉ báo động một lần": "Režim ochrany spustí alarm iba raz",
  "Chế độ Bảo vệ sẽ lặp báo động sau \$minutes phút":
      "Režim ochrany zopakuje alarm o \$minutes minút",
  "Đã gửi yêu cầu gia nhập \$count nhà":
      "Odoslaná žiadosť o pripojenie k \$count domovom",
  "\$requesterName đang xin gia nhập nhà \"\$homeName\".":
      "\$requesterName žiada o pripojenie k domovu „\$homeName“.",
  "Bạn đã xoá nhà \"\$homeName\".": "Odstránili ste domov „\$homeName“.",
  "Bạn đã gửi yêu cầu chuyển quyền chủ nhà \"\$homeName\" cho \$email.":
      "Odoslali ste žiadosť o prevod vlastníctva domova „\$homeName“ na \$email.",
  "\$actorName muốn chuyển quyền chủ nhà \"\$homeName\" cho bạn.":
      "\$actorName vám chce previesť vlastníctvo domova „\$homeName“.",
  "\$actorName đã mời bạn tham gia nhà \"\$homeName\".":
      "\$actorName vás pozval(a) do domova „\$homeName“.",
  "SafeHome đang xoá thiết bị \"\$deviceName\" khỏi nhà \"\$homeName\".":
      "SafeHome odstraňuje zariadenie „\$deviceName“ z domova „\$homeName“.",
  "Thiết bị \"\$deviceName\" đã xuất hiện trong \"\$homeName\".":
      "Zariadenie „\$deviceName“ sa objavilo v domove „\$homeName“.",
  "Bạn đã tạo nhà \"\$name\".": "Vytvorili ste domov „\$name“.",
  "\$actorName đã cập nhật tên nhà thành \"\$newName\" và thay đổi địa chỉ.":
      "\$actorName zmenil(a) názov domova na „\$newName“ a aktualizoval(a) adresu.",
  "\$actorName đã đổi tên nhà thành \"\$newName\".":
      "\$actorName zmenil(a) názov domova na „\$newName“.",
  "\$actorName đã cập nhật địa chỉ của nhà \"\$newName\".":
      "\$actorName aktualizoval(a) adresu domova „\$newName“.",
  "\$actorName đã đổi tên thiết bị \"\$oldDeviceName\" thành \"\$newName\" trong nhà \"\$homeName\".":
      "\$actorName premenoval(a) zariadenie „\$oldDeviceName“ v domove „\$homeName“ na „\$newName“.",
  "Đang ghép nối: \$seconds giây": "Párovanie: \$seconds sekúnd",
  "Chế độ thêm thiết bị đã được mở trong nhà \"\$homeName\" trong \$seconds giây.":
      "Režim pridávania zariadení bol v domove „\$homeName“ otvorený na \$seconds sekúnd.",
  "Khoảng thời gian phải nằm trong khung báo động (\$start → \$end)":
      "Časový úsek musí byť v rámci okna alarmu (\$start → \$end)",
  "\$passCount/\$total bài test đạt\n\n":
      "Úspešných testov: \$passCount/\$total\n\n",
  "\$name chưa cập nhật số điện thoại trong hồ sơ.":
      "\$name zatiaľ nepridal(a) do profilu telefónne číslo.",
  "Tin nhắn mới trong \$homeName": "Nová správa v \$homeName",
  "\$current/\$total kết quả": "\$current/\$total výsledkov",
  "Đang trả lời \$name": "Odpoveď používateľovi \$name",
  "\"\$name\" phát hiện khói trong \"\$homeName\".":
      "„\$name“ zistil dym v domove „\$homeName“.",
  "\"\$name\" đã trở lại trạng thái bình thường.":
      "„\$name“ sa vrátil do normálneho stavu.",
  "\"\$name\" vừa kích hoạt SOS trong \"\$homeName\".":
      "„\$name“ práve aktivoval SOS v domove „\$homeName“.",
  "\"\$name\" đã hết trạng thái SOS.":
      "Stav SOS zariadenia „\$name“ sa skončil.",
  "\"\$name\" báo bị tháo/cạy trong \"\$homeName\".":
      "„\$name“ hlási manipuláciu v domove „\$homeName“.",
  "\"\$name\" đã hết cảnh báo tháo/cạy.":
      "Upozornenie na manipuláciu zariadenia „\$name“ sa skončilo.",
  "\"\$name\" đã đóng trong \"\$homeName\".":
      "„\$name“ je zatvorené v domove „\$homeName“.",
  "\"\$name\" đang mở trong \"\$homeName\".":
      "„\$name“ je otvorené v domove „\$homeName“.",
  "\"\$name\" trong \"\$homeName\" đang yếu pin.":
      "„\$name“ v domove „\$homeName“ má takmer vybitú batériu.",
  "\"\$name\" trong \"\$homeName\" đã mất kết nối.":
      "„\$name“ v domove „\$homeName“ stratil pripojenie.",
  "\"\$name\" trong \"\$homeName\" đã kết nối trở lại.":
      "„\$name“ v domove „\$homeName“ je znova pripojené.",
  "\"\$name\" ghi nhận nhiệt độ cao trong \"\$homeName\".":
      "„\$name“ zaznamenal vysokú teplotu v domove „\$homeName“.",
  "\"\$name\" ghi nhận độ ẩm cao trong \"\$homeName\".":
      "„\$name“ zaznamenal vysokú vlhkosť v domove „\$homeName“.",
  "Có nút SOS vừa được kích hoạt": "Práve bolo aktivované tlačidlo SOS",
  "Có dấu hiệu khói hoặc cháy": "Boli zistené známky dymu alebo požiaru",
  "Có dấu hiệu ngập nước": "Boli zistené známky zaplavenia",
  "Có dấu hiệu rò khí": "Boli zistené známky úniku plynu",
  "Có cửa đang mở hoặc thiết bị bị tháo":
      "Niektoré dvere sú otvorené alebo bolo manipulované so zariadením",
  "Có thiết bị đang cảnh báo": "Niektoré zariadenie hlási upozornenie",
  "Nếu chưa có ai xác nhận, SafeHome sẽ chuyển sang gọi điện khẩn cấp.":
      "Ak nikto nepotvrdí situáciu, SafeHome prejde na núdzové volanie.",
  "Báo lại lúc \$time nếu vấn đề chưa được xử lý.":
      "Ak problém nebude vyriešený, upozorniť znova o \$time.",
  "Sẽ báo lại theo lịch báo động đã cài nếu vấn đề chưa được xử lý.":
      "Ak problém nebude vyriešený, upozornenie sa zopakuje podľa nastaveného plánu alarmu.",
  "\"\$deviceName\" đã đóng trong \"\$resolvedHomeName\".":
      "„\$deviceName“ je zatvorené v domove „\$resolvedHomeName“.",
  "\"\$deviceName\" đang mở trong \"\$resolvedHomeName\".":
      "„\$deviceName“ je otvorené v domove „\$resolvedHomeName“.",
  "\$count nhà đã chọn": "Vybraných domovov: \$count",
  "🚨 \$count nhà không an toàn\$suffix":
      "🚨 \$count nebezpečných domovov\$suffix",
  "⚠️ \$count nhà cần chú ý\$suffix":
      "⚠️ \$count domovov vyžaduje pozornosť\$suffix",
  "✅ \$count nhà an toàn": "✅ \$count bezpečných domovov",
  "\$count nhà đang được theo dõi": "Sledovaných domovov: \$count",
  "\$minutes phút": "\$minutes minút",
  "Đã cài nhắc nhở cho \$updatedHomes nhà.":
      "Pripomienky boli nastavené pre \$updatedHomes domovov.",
  "Đã cài báo động cho \$updatedDevices thiết bị trong \$updatedHomes nhà.\n":
      "Alarmy boli nastavené pre \$updatedDevices zariadení v \$updatedHomes domovoch.\n",
  "Đã chia sẻ các nhà bạn có quyền.\n\n\$skipped nhà bị bỏ qua vì bạn không có quyền chia sẻ.":
      "Domovy, ku ktorým máte oprávnenie, boli zdieľané.\n\n\$skipped domovov bolo preskočených, pretože ich nemáte oprávnenie zdieľať.",
  "Đã áp dụng báo động cho \$count thiết bị an ninh":
      "Alarm použitý pre \$count bezpečnostných zariadení",
  "Áp dụng cùng một lịch cho \$count thiết bị an ninh":
      "Použiť rovnaký plán pre \$count bezpečnostných zariadení",
  "\$count phút trước": "Pred \$count minútami",
  "\$count giờ trước": "Pred \$count hodinami",
  "\${count}h trước": "Pred \${count} h",
  "\${hours}h\$minutes' trước": "Pred \${hours} h \$minutes min",
  "\$count ngày trước": "Pred \$count dňami",
  "\$count tháng trước": "Pred \$count mesiacmi",
  "Bạn chắc chắn muốn xoá \$name khỏi nhà này?":
      "Naozaj chcete odstrániť používateľa \$name z tohto domova?",
  "\$targetEmail\nXin gia nhập \"\$homeName\"":
      "\$targetEmail\nŽiada o pripojenie k domovu „\$homeName“",
  "Xin gia nhập \"\$homeName\"": "Žiadosť o pripojenie k domovu „\$homeName“",
  "Bạn được mời nhận quyền nhà \"\$homeName\"":
      "Boli ste pozvaní prevziať vlastníctvo domova „\$homeName“",
  "\$ownerEmail\nMời bạn gia nhập \"\$homeName\"":
      "\$ownerEmail\nPozýva vás do domova „\$homeName“",
  "Mời bạn gia nhập \"\$homeName\"": "Pozvánka do domova „\$homeName“",
  "Cần kiểm tra: \$joined": "Treba skontrolovať: \$joined",
  "Cập nhật \$value": "Aktualizované \$value",
  "Hãy thêm thiết bị SafeHome đầu tiên để bắt đầu theo dõi nhà.":
      "Pridajte prvé zariadenie SafeHome a začnite svoj domov sledovať.",
  "Kiểm tra cảnh báo khẩn cấp trước, sau đó liên hệ thành viên trong nhà nếu cần.":
      "Najprv skontrolujte núdzové upozornenie a potom v prípade potreby kontaktujte členov domácnosti.",
  "Không có thành viên nào ở nhà nhưng cửa hoặc khóa đang mở, hãy kiểm tra ngay.":
      "Nikto nie je doma, ale dvere alebo zámok sú otvorené. Ihneď to skontrolujte.",
  "Kiểm tra cửa hoặc khóa đang mở trước khi giữ nhà ở chế độ Bảo vệ.":
      "Pred ponechaním domova v režime ochrany skontrolujte otvorené dvere alebo zámky.",
  "Có thể vẫn có người ở nhà; nếu đúng, nên chuyển về Bình thường.":
      "Niekto môže byť stále doma; ak áno, prepnite režim na Normálny.",
  "Có thành viên chưa xác định vị trí, hãy nhắc họ mở ứng dụng hoặc kiểm tra quyền vị trí.":
      "Poloha niektorého člena nie je známa. Požiadajte ho, aby otvoril aplikáciu alebo skontroloval povolenia polohy.",
  "Có thiết bị mất kết nối, hãy kiểm tra pin, nguồn hoặc vị trí đặt thiết bị.":
      "Niektoré zariadenie je odpojené. Skontrolujte batériu, napájanie alebo jeho umiestnenie.",
  "Có thiết bị pin yếu, nên thay pin sớm để tránh mất cảnh báo.":
      "Niektoré zariadenie má slabú batériu. Čoskoro ju vymeňte, aby nedošlo k strate upozornení.",
  "Bạn chưa đặt nhắc nhở, nên tạo lịch nhắc kiểm tra nhà định kỳ.":
      "Zatiaľ ste nenastavili žiadne pripomienky. Vytvorte plán pravidelných kontrol domova.",
  "Bạn chưa đặt lịch báo động, nên bật bảo vệ theo khung giờ thường vắng nhà.":
      "Zatiaľ ste nenastavili plán alarmu. Zapnite ochranu na čas, keď býva domov zvyčajne prázdny.",
  "Không có việc cần xử lý ngay, bạn chỉ cần tiếp tục theo dõi trạng thái nhà.":
      "Teraz netreba nič riešiť; stačí ďalej sledovať stav domova.",
  "Lặp sau \$minutes phút": "Opakovať o \$minutes minút",
  "Đang dùng • \$repeatText": "Používa sa • \$repeatText",
  "Giám sát an ninh • \$repeatText": "Bezpečnostné sledovanie • \$repeatText",
  "Gia đình: \$mode": "Rodina: \$mode",
  "Gợi ý xử lý": "Odporúčaný postup",
  "Phát hiện \$count vấn đề cần xử lý":
      "Zistených problémov na riešenie: \$count",
  "Hôm nay các cửa đã được sử dụng \$count lần":
      "Dnes boli dvere použité \$count-krát",
  "Đã ghi nhận \$count hoạt động gần đây":
      "Zaznamenaných nedávnych aktivít: \$count",
  "Hệ thống: Cần kiểm tra \$issueCount mục":
      "Systém: Treba skontrolovať \$issueCount položiek",
  "FCM token đã sẵn sàng trên điện thoại này.":
      "Token FCM je v tomto telefóne pripravený.",
  "FCM token đã sẵn sàng, nhưng Auto rời khỏi nhà còn thiếu điều kiện.":
      "Token FCM je pripravený, ale funkcii Automaticky pri odchode stále chýbajú niektoré podmienky.",
  "Hiện có \$emergencyTotal thiết bị khẩn cấp. Khuyến nghị tối thiểu: báo khói và SOS.":
      "Aktuálne je k dispozícii \$emergencyTotal núdzových zariadení. Odporúčané minimum: detektor dymu a SOS.",
  "Bạn chắc chắn muốn chuyển quyền chủ nhà cho:\n\$targetEmail?":
      "Naozaj chcete previesť vlastníctvo na:\n\$targetEmail?",
  "\$count cửa đã đóng an toàn": "Bezpečne zatvorených dverí: \$count",
  "\$count cửa và khóa đã an toàn": "Bezpečných dverí a zámkov: \$count",
  "\$count thiết bị đang được theo dõi": "Sledovaných zariadení: \$count",
  "Cập nhật \$timeText": "Aktualizované \$timeText",
  "Dữ liệu gần nhất cập nhật \$count phút trước":
      "Posledná aktualizácia údajov pred \$count minútami",
  "Dữ liệu gần nhất cập nhật \$count giờ trước":
      "Posledná aktualizácia údajov pred \$count hodinami",
  "Thành viên trong nhà: \$count": "Členovia doma: \$count",
  "Thành viên bên ngoài: \$count": "Členovia mimo domu: \$count",
  "Chưa xác định vị trí: \$count": "Neznáma poloha: \$count",
  "Môi trường hiện tại: \$environment": "Aktuálne prostredie: \$environment",
  "\$name: Đang mở khi nhà ở chế độ Bảo vệ":
      "\$name: Otvorené, keď je domov v režime ochrany",
  "An tâm hơn trong từng ngôi nhà": "Viac pokoja v každom domove",
  "Báo động SafeHome": "Alarm SafeHome",
  "Có cảnh báo an ninh cần kiểm tra ngay.":
      "Je tu bezpečnostné upozornenie, ktoré treba ihneď skontrolovať.",
  "Có cảnh báo cần kiểm tra": "Je tu upozornenie, ktoré treba skontrolovať",
  "Tự đóng sau \$time": "Automaticky zavrieť o \$time",
  "Ngày trong tuần": "Dni v týždni",
  "Hoặc": "Alebo",
  "Giờ bắt đầu và kết thúc không được trùng nhau":
      "Čas začiatku a konca nesmie byť rovnaký",
  "Giờ kết thúc phải sau thời điểm hiện tại":
      "Čas konca musí byť neskôr ako aktuálny čas",
  "Khoảng tạm tắt không hợp lệ": "Neplatný interval pozastavenia",
  "Khoảng tạm tắt không trùng với lịch báo động nào đang bật":
      "Interval pozastavenia sa neprekrýva so žiadnym zapnutým plánom alarmu",
  "Cài đặt báo động": "Nastavenia alarmu",
  "Điều khiển cách cảm biến này kích hoạt cảnh báo.":
      "Nastavte, ako tento senzor spúšťa upozornenia.",
  "Tham gia báo động": "Zapojiť do alarmu",
  "Tắt để cảm biến không tạo báo động.":
      "Vypnutím zabránite tomu, aby senzor spustil alarm.",
  "Bật còi vật lý": "Zapnúť fyzickú sirénu",
  "Cho phép kích hoạt còi trong nhà.": "Povoliť aktiváciu sirény v dome.",
  "Đánh thức màn hình": "Prebudiť obrazovku",
  "Hiển thị cảnh báo toàn màn hình trên điện thoại.":
      "Zobraziť upozornenie na celú obrazovku telefónu.",
  "Độ trễ kích hoạt": "Oneskorenie aktivácie",
  "Chỉ áp dụng cho cảm biến an ninh.": "Platí iba pre bezpečnostné senzory.",
  "Cảm biến khẩn cấp luôn kích hoạt ngay lập tức.":
      "Núdzové senzory sa vždy aktivujú okamžite.",
  "Ngay lập tức": "Okamžite",
  "giây": "sekúnd",
  "Đã lưu cấu hình báo động": "Nastavenie alarmu bolo uložené",
  "Không thể lưu cấu hình báo động": "Nastavenie alarmu sa nepodarilo uložiť",
  "Chỉ chủ nhà và quản trị viên có thể thay đổi cài đặt này.":
      "Toto nastavenie môžu zmeniť iba vlastník a správcovia.",
  "Thông tin chi tiết": "Podrobnosti",
  "Thông báo báo động": "Oznámenia alarmu",
  "Cài đặt nhắc nhở": "Nastavenia pripomienok",
  "Nhắc nhở theo lịch": "Plánované pripomienky",
  "Danh sách thông báo": "Zoznam oznámení",
  "Cài đặt thông báo": "Nastavenia oznámení",
  "Sử dụng báo động theo lịch đã thiết lập":
      "Používať alarm podľa nastaveného plánu",
  "Chỉ gửi thông báo, không kích hoạt báo động":
      "Iba odoslať oznámenie, nespúšťať alarm",
  "Toàn bộ báo động của nhà đang tắt; hệ thống chỉ gửi thông báo.":
      "Všetky alarmy domova sú vypnuté; systém iba odosiela oznámenia.",
  "Chỉ Chủ nhà có thể bật chế độ này.": "Tento režim môže zapnúť iba vlastník.",
  "Bật Không bảo vệ?": "Zapnúť režim Bez ochrany?",
  "Cảm biến vừa phát hiện một sự kiện.": "Senzor práve zistil udalosť.",
  "Chỉ Chủ nhà mới có quyền bật chế độ Không bảo vệ":
      "Režim Bez ochrany môže zapnúť iba vlastník",
  "Đã chuyển nhà sang Không bảo vệ": "Domov bol prepnutý do režimu Bez ochrany",
  "Đã chuyển sang Không bảo vệ nhưng chưa gửi được thông báo":
      "Prepnuté do režimu Bez ochrany, ale oznámenie sa nepodarilo odoslať",
  "Giám sát toàn diện": "Komplexné sledovanie",
  "Không bảo vệ": "Bez ochrany",
  "Không bảo vệ đang bật": "Režim Bez ochrany je zapnutý",
  "Nhà đã chuyển sang Không bảo vệ": "Domov bol prepnutý do režimu Bez ochrany",
  "Thông báo cảm biến": "Oznámenia senzorov",
  "Thông báo thông thường khi cảm biến phát hiện sự kiện.":
      "Bežné oznámenie, keď senzor zistí udalosť.",
  "Tôi hiểu, tiếp tục": "Rozumiem, pokračovať",
  "Cảnh báo an ninh đã kết thúc": "Bezpečnostné upozornenie sa skončilo",
  "Sự cố nguy hiểm đã kết thúc": "Nebezpečný incident sa skončil",
  "Cảnh báo đã được kết thúc.": "Upozornenie bolo ukončené.",
  "Vẫn còn cảnh báo khác đang hoạt động.":
      "Ďalšie upozornenia sú stále aktívne.",
  "Báo động đã hoạt động trở lại": "Alarm je znova aktívny",
  "Thời gian tạm dừng báo động đã kết thúc.":
      "Pozastavenie alarmu sa skončilo.",
  "MQTT đã kết nối trở lại": "MQTT je znova pripojené",
  "Còi báo động đã được tắt": "Siréna alarmu bola vypnutá",
  "Sự cố vẫn đang được theo dõi.": "Incident sa stále sleduje.",
  "Bảo vệ tự động đã bật": "Automatická ochrana bola zapnutá",
  "Toàn bộ thành viên đã rời khỏi nhà.": "Všetci členovia odišli z domu.",
  "Bảo vệ tự động đã tắt": "Automatická ochrana bola vypnutá",
  "Có thành viên đã trở về nhà.": "Niektorý člen sa vrátil domov.",
  "Thiết bị đã được xoá": "Zariadenie bolo odstránené",
  "Không thể xoá thiết bị": "Zariadenie sa nepodarilo odstrániť",
  "Hãy thử lại thao tác xoá thiết bị.": "Skúste zariadenie odstrániť znova.",
  "Chế độ Bảo vệ đã được tắt.": "Režim ochrany bol vypnutý.",
  "Nhà đang ở chế độ Bình thường.": "Domov je v normálnom režime.",
  "Pin thiết bị đã ổn định": "Batéria zariadenia je opäť v poriadku",
  "Hub đã kết nối trở lại": "Hub je znova pripojený",
  "Đã chuyển về Bình thường nhưng chưa gửi được thông báo":
      "Prepnuté späť na Normálny, ale oznámenie sa nepodarilo odoslať",
  "Chung cho nhà": "Spoločné pre domov",
  "Áp dụng cho toàn bộ thành viên và có thể bật còi vật lý.":
      "Platí pre všetkých členov a môže aktivovať fyzickú sirénu.",
  "Cá nhân": "Osobné",
  "Lịch cá nhân hoạt động độc lập và không bật còi vật lý.":
      "Osobný plán funguje nezávisle a neaktivuje fyzickú sirénu.",
  "Cài đặt này chỉ áp dụng cho tài khoản của bạn.":
      "Toto nastavenie platí iba pre váš účet.",
  "Chỉ chủ nhà và quản trị viên có thể thay đổi phần chung cho nhà.":
      "Spoločné nastavenia domova môžu meniť iba vlastník a správcovia.",
  "Tham gia hệ thống báo động": "Zapojiť do systému alarmu",
  "Cảm biến khẩn cấp luôn tham gia hệ thống báo động.":
      "Núdzové senzory sú vždy zapojené do systému alarmu.",
  "Tắt để thiết bị không tạo bất kỳ báo động nào.":
      "Vypnutím zabránite zariadeniu v spustení akéhokoľvek alarmu.",
  "Lịch báo động chung": "Spoločný plán alarmu",
  "Lịch báo động cá nhân": "Osobný plán alarmu",
  "Hiển thị cảnh báo toàn màn hình trên điện thoại của bạn.":
      "Zobraziť upozornenie na celú obrazovku vášho telefónu.",
  "Lặp lại cảnh báo": "Opakovať upozornenie",
  "Báo động chung": "Spoločný alarm",
  "Báo động cá nhân": "Osobný alarm",
  "Đã cài đặt": "Nastavené",
  "Chưa cài đặt": "Nenastavené",
  "Lịch chung và lịch cá nhân hoạt động song song, không còn phải chọn một trong hai.":
      "Spoločný a osobný plán fungujú súbežne; už nie je potrebné vyberať iba jeden z nich.",
  "Cài nhanh chung": "Rýchle spoločné nastavenie",
  "Cài nhanh cá nhân": "Rýchle osobné nastavenie",
  "Thiết lập nhanh lịch cá nhân": "Rýchle nastavenie osobného plánu",
  "Thiết lập nhanh lịch chung": "Rýchle nastavenie spoločného plánu",
  "Lịch này chỉ áp dụng cho bạn và không bật còi vật lý.":
      "Tento plán platí iba pre vás a neaktivuje fyzickú sirénu.",
  "Lịch này áp dụng cho toàn bộ thành viên trong nhà.":
      "Tento plán platí pre všetkých členov domova.",
  "Đã áp dụng lịch báo động": "Plán alarmu bol použitý",
  "Không thể lưu lịch báo động": "Plán alarmu sa nepodarilo uložiť",
  "Nhà chưa có thiết bị an ninh":
      "Domov zatiaľ nemá žiadne bezpečnostné zariadenia",
  "Nhận cảnh báo theo lịch chung của nhà":
      "Prijímať upozornenia podľa spoločného plánu domova",
  "Tắt để không nhận thông báo hoặc cảnh báo toàn màn hình từ lịch chung. Còi vật lý của nhà vẫn hoạt động.":
      "Vypnutím nebudete dostávať oznámenia ani celoobrazovkové upozornenia zo spoločného plánu. Fyzická siréna v dome zostane aktívna.",
};

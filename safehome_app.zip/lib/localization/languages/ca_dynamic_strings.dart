const Map<String, String> caDynamicStrings = {
  "Bảo vệ - Tự động": "Protecció - Automàtica",
  "Bảo vệ - Thủ công": "Protecció - Manual",
  "Tự động": "Automàtic",
  "Thủ công": "Manual",
  "\$displayMemberName đã gia nhập nhà \"\$homeName\".":
      "\$displayMemberName s'ha unit a la llar \"\$homeName\".",
  "NGUY HIỂM": "PERILL",
  "Nguy hiểm & Khẩn cấp": "Perill i emergència",
  "TẮT CÒI": "ATURA LA SIRENA",
  "Tắt còi báo động?": "Vols aturar la sirena d'alarma?",
  "Còi vật lý sẽ dừng, nhưng cảnh báo vẫn tiếp tục cho đến khi sự cố được xử lý.\n\nBạn chắc chắn muốn tắt còi?":
      "La sirena física s'aturarà, però l'alerta continuarà fins que es resolgui l'incident.\n\nSegur que vols aturar la sirena?",
  "Đã gửi lệnh tắt còi. Cảnh báo vẫn đang được theo dõi.":
      "S'ha enviat l'ordre d'aturar la sirena. L'alerta continua sota supervisió.",
  "Không tìm thấy cảnh báo đang hoạt động hoặc chưa thể gửi lệnh tắt còi.":
      "No s'ha trobat cap alerta activa o no s'ha pogut enviar l'ordre d'aturar la sirena.",
  "TẮT CÒI TRONG NHÀ": "ATURA LA SIRENA DE LA LLAR",
  "Đã tắt còi trong nhà. Cảnh báo vẫn tiếp tục cho đến khi được xử lý.":
      "La sirena de la llar s'ha aturat. L'alerta continuarà fins que es resolgui.",
  "\$name đang chuẩn bị gửi tin...": "\$name està escrivint...",
  "\$name1 và \$name2 đang chuẩn bị gửi tin...":
      "\$name1 i \$name2 estan escrivint...",
  "\$name và \$otherCount người khác đang chuẩn bị gửi tin...":
      "\$name i \$otherCount persones més estan escrivint...",
  "Kênh báo động cũ để giữ tương thích":
      "Canal d'alarma antic mantingut per compatibilitat",
  "SafeHome báo động toàn màn hình": "Alarma SafeHome a pantalla completa",
  "Mở cảnh báo toàn màn hình; âm còi phát từ trang báo động":
      "Obre l'alerta a pantalla completa; el so de la sirena es reprodueix des de la pàgina d'alarma",
  "SafeHome cảnh báo khẩn cấp": "Alerta d'emergència SafeHome",
  "Cảnh báo khẩn cấp ưu tiên cao trước khi mở toàn màn hình":
      "Alerta d'emergència d'alta prioritat abans d'obrir la pantalla completa",
  "SafeHome nhắc nhở toàn màn hình": "Recordatori SafeHome a pantalla completa",
  "Nhắc nhở SafeHome toàn màn hình không âm thanh":
      "Recordatori SafeHome silenciós a pantalla completa",
  "SafeHome nhắc nhở ưu tiên cao": "Recordatori SafeHome d'alta prioritat",
  "Nhắc nhở SafeHome ưu tiên cao, không mở toàn màn hình":
      "Recordatori SafeHome d'alta prioritat sense pantalla completa",
  "Tin nhắn mới trong các nhà SafeHome": "Missatges nous a les llars SafeHome",
  "Hành động này sẽ thay đổi thời gian báo động của một số thiết bị hôm nay.\n\nBáo động của các thiết bị thuộc trường \"Nguy hiểm khẩn cấp\" và báo động ở chế độ \"Bảo vệ\" sẽ không bị ảnh hưởng bởi chức năng này.":
      "Aquesta acció canviarà avui l’hora de l’alarma d’alguns dispositius.\n\nLes alarmes dels dispositius de la categoria «Perill d’emergència» i les alarmes en mode «Protecció» no es veuran afectades per aquesta funció.",
  "🆘 \$count nhà nguy hiểm\$suffix": "🆘 \$count llars en perill\$suffix",
  "FCM token đã sẵn sàng, nhưng tính năng tự động khi rời nhà còn thiếu điều kiện.":
      "El token FCM està preparat, però a la funció automàtica en sortir de casa encara li falta una condició.",
  "Đã kích hoạt SOS": "SOS activat",
  "Phát hiện chập điện": "S'ha detectat un curtcircuit",
  "Phát hiện quá dòng": "S'ha detectat sobreintensitat",
  "Phát hiện quá áp": "S'ha detectat sobretensió",
  "Thiết bị điện quá nhiệt": "Dispositiu elèctric sobreescalfat",
  "Tài khoản đang được sử dụng": "El compte està en ús",
  "Hiện tại tài khoản này đang đăng nhập trên một thiết bị khác. Nếu tiếp tục, tài khoản trên thiết bị đó sẽ tự đăng xuất.":
      "Aquest compte té una sessió iniciada en un altre dispositiu. Si continues, la sessió d'aquell dispositiu es tancarà automàticament.",
  "Tiếp tục đăng nhập": "Continua iniciant sessió",
  "Tài khoản đã được đăng nhập trên một thiết bị khác.":
      "S'ha iniciat sessió amb el compte en un altre dispositiu.",
  "KHẨN CẤP": "EMERGÈNCIA",
  "CẦN CHÚ Ý": "REQUEREIX ATENCIÓ",
  "THÔNG TIN": "INFORMACIÓ",
  "BÁO ĐỘNG": "ALARMA",
  "Cảm biến đã trở lại trạng thái an toàn.":
      "El sensor ha tornat a un estat segur.",
  "Người dùng đã tắt cảnh báo.": "Un usuari ha desactivat l'alerta.",
  "Khung giờ bảo vệ đã kết thúc.": "El període de protecció ha finalitzat.",
  "Cảnh báo tức thời đã tự kết thúc.":
      "L'alerta immediata ha finalitzat automàticament.",
  "Điều kiện cảnh báo không còn hoạt động.":
      "La condició d'alerta ja no està activa.",
  "Cảnh báo đã kết thúc: \$reason": "L'alerta ha finalitzat: \$reason",
};

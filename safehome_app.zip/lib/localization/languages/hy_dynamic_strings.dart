const Map<String, String> hyDynamicStrings = {
  "Bảo vệ - Tự động": "Պաշտպանություն - Ավտոմատ",
  "Bảo vệ - Thủ công": "Պաշտպանություն - Ձեռքով",
  "Tự động": "Ավտոմատ",
  "Thủ công": "Ձեռքով",
  "\$displayMemberName đã gia nhập nhà \"\$homeName\".":
      "\$displayMemberName-ը միացել է «\$homeName» տանը։",
  "NGUY HIỂM": "ՎՏԱՆԳ",
  "Nguy hiểm & Khẩn cấp": "Վտանգ և արտակարգ իրավիճակ",
  "TẮT CÒI": "ԱՆՋԱՏԵԼ ՇՉԱԿԸ",
  "Tắt còi báo động?": "Անջատե՞լ ահազանգի շչակը։",
  "Còi vật lý sẽ dừng, nhưng cảnh báo vẫn tiếp tục cho đến khi sự cố được xử lý.\n\nBạn chắc chắn muốn tắt còi?":
      "Ֆիզիկական շչակը կդադարի, բայց նախազգուշացումը կշարունակվի մինչև միջադեպի լուծումը։\n\nՎստա՞հ եք, որ ցանկանում եք անջատել շչակը։",
  "Đã gửi lệnh tắt còi. Cảnh báo vẫn đang được theo dõi.":
      "Շչակն անջատելու հրամանն ուղարկվել է։ Նախազգուշացումը դեռ վերահսկվում է։",
  "Không tìm thấy cảnh báo đang hoạt động hoặc chưa thể gửi lệnh tắt còi.":
      "Ակտիվ նախազգուշացում չի գտնվել կամ շչակն անջատելու հրամանը չի հաջողվել ուղարկել։",
  "TẮT CÒI TRONG NHÀ": "ԱՆՋԱՏԵԼ ՏԱՆ ՇՉԱԿԸ",
  "Đã tắt còi trong nhà. Cảnh báo vẫn tiếp tục cho đến khi được xử lý.":
      "Տան շչակն անջատվել է։ Նախազգուշացումը կշարունակվի մինչև լուծումը։",
  "\$name đang chuẩn bị gửi tin...": "\$name-ը գրում է...",
  "\$name1 và \$name2 đang chuẩn bị gửi tin...":
      "\$name1-ը և \$name2-ը գրում են...",
  "\$name và \$otherCount người khác đang chuẩn bị gửi tin...":
      "\$name-ը և ևս \$otherCount հոգի գրում են...",
  "Kênh báo động cũ để giữ tương thích":
      "Հին ահազանգի ալիքը պահպանվել է համատեղելիության համար",
  "SafeHome báo động toàn màn hình": "SafeHome-ի ամբողջէկրան ահազանգ",
  "Mở cảnh báo toàn màn hình; âm còi phát từ trang báo động":
      "Բացում է ամբողջէկրան նախազգուշացումը․ շչակի ձայնը հնչում է ահազանգի էջից",
  "SafeHome cảnh báo khẩn cấp": "SafeHome-ի արտակարգ նախազգուշացում",
  "Cảnh báo khẩn cấp ưu tiên cao trước khi mở toàn màn hình":
      "Բարձր առաջնահերթությամբ արտակարգ նախազգուշացում՝ մինչև ամբողջ էկրան բացելը",
  "SafeHome nhắc nhở toàn màn hình": "SafeHome-ի ամբողջէկրան հիշեցում",
  "Nhắc nhở SafeHome toàn màn hình không âm thanh":
      "SafeHome-ի անձայն ամբողջէկրան հիշեցում",
  "SafeHome nhắc nhở ưu tiên cao":
      "SafeHome-ի բարձր առաջնահերթությամբ հիշեցում",
  "Nhắc nhở SafeHome ưu tiên cao, không mở toàn màn hình":
      "SafeHome-ի բարձր առաջնահերթությամբ հիշեցում՝ առանց ամբողջ էկրանի",
  "Tin nhắn mới trong các nhà SafeHome":
      "Նոր հաղորդագրություններ SafeHome տներում",
  "Hành động này sẽ thay đổi thời gian báo động của một số thiết bị hôm nay.\n\nBáo động của các thiết bị thuộc trường \"Nguy hiểm khẩn cấp\" và báo động ở chế độ \"Bảo vệ\" sẽ không bị ảnh hưởng bởi chức năng này.":
      "Այս գործողությունն այսօր կփոխի որոշ սարքերի տագնապի ժամը։\n\n«Արտակարգ վտանգ» կատեգորիայի սարքերի տագնապները և «Պաշտպանություն» ռեժիմի տագնապները չեն ազդվի այս գործառույթից։",
  "🆘 \$count nhà nguy hiểm\$suffix": "🆘 \$count վտանգավոր տուն\$suffix",
  "FCM token đã sẵn sàng, nhưng tính năng tự động khi rời nhà còn thiếu điều kiện.":
      "FCM թոքենը պատրաստ է, սակայն տնից հեռանալիս ավտոմատ գործառույթի համար դեռ մի պայման բացակայում է։",
  "Đã kích hoạt SOS": "SOS-ն ակտիվացված է",
  "Phát hiện chập điện": "Հայտնաբերվել է կարճ միացում",
  "Phát hiện quá dòng": "Հայտնաբերվել է գերհոսանք",
  "Phát hiện quá áp": "Հայտնաբերվել է գերլարում",
  "Thiết bị điện quá nhiệt": "Էլեկտրական սարքը գերտաքացել է",
  "Tài khoản đang được sử dụng": "Հաշիվն օգտագործվում է",
  "Hiện tại tài khoản này đang đăng nhập trên một thiết bị khác. Nếu tiếp tục, tài khoản trên thiết bị đó sẽ tự đăng xuất.":
      "Այս հաշիվը ներկայում մուտք է գործել մեկ այլ սարքում։ Եթե շարունակեք, այդ սարքի հաշվից ավտոմատ դուրս կգրվի։",
  "Tiếp tục đăng nhập": "Շարունակել մուտքը",
  "Tài khoản đã được đăng nhập trên một thiết bị khác.":
      "Հաշիվը մուտք է գործել մեկ այլ սարքում։",
  "KHẨN CẤP": "ԱՐՏԱԿԱՐԳ",
  "CẦN CHÚ Ý": "ՊԱՀԱՆՋՈՒՄ Է ՈՒՇԱԴՐՈՒԹՅՈՒՆ",
  "THÔNG TIN": "ՏԵՂԵԿԱՏՎՈՒԹՅՈՒՆ",
  "BÁO ĐỘNG": "ԱՀԱԶԱՆԳ",
  "Cảm biến đã trở lại trạng thái an toàn.":
      "Սենսորը վերադարձել է անվտանգ վիճակի։",
  "Người dùng đã tắt cảnh báo.": "Օգտատերն անջատել է նախազգուշացումը։",
  "Khung giờ bảo vệ đã kết thúc.": "Պաշտպանության ժամանակահատվածն ավարտվել է։",
  "Cảnh báo tức thời đã tự kết thúc.":
      "Անմիջական նախազգուշացումն ինքնաբերաբար ավարտվել է։",
  "Điều kiện cảnh báo không còn hoạt động.":
      "Նախազգուշացման պայմանն այլևս ակտիվ չէ։",
  "Cảnh báo đã kết thúc: \$reason": "Նախազգուշացումն ավարտվել է․ \$reason",
};

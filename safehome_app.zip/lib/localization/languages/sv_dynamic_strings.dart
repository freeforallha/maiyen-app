const Map<String, String> svDynamicStrings = {
  "Bảo vệ - Tự động": "Skydd - Automatiskt",
  "Bảo vệ - Thủ công": "Skydd - Manuellt",
  "Tự động": "Automatiskt",
  "Thủ công": "Manuellt",
  "\$displayMemberName đã gia nhập nhà \"\$homeName\".":
      "\$displayMemberName gick med i \"\$homeName\".",
  "NGUY HIỂM": "FARA",
  "Nguy hiểm & Khẩn cấp": "Fara och nödläge",
  "TẮT CÒI": "STOPPA SIRENEN",
  "Tắt còi báo động?": "Stoppa larmsirenen?",
  "Còi vật lý sẽ dừng, nhưng cảnh báo vẫn tiếp tục cho đến khi sự cố được xử lý.\n\nBạn chắc chắn muốn tắt còi?":
      "Den fysiska sirenen stoppas, men larmet förblir aktivt tills incidenten har hanterats.\n\nÄr du säker på att du vill stoppa sirenen?",
  "Đã gửi lệnh tắt còi. Cảnh báo vẫn đang được theo dõi.":
      "Kommandot att stoppa sirenen har skickats. Larmet övervakas fortfarande.",
  "Không tìm thấy cảnh báo đang hoạt động hoặc chưa thể gửi lệnh tắt còi.":
      "Inget aktivt larm hittades, eller så kunde kommandot att stoppa sirenen inte skickas.",
  "TẮT CÒI TRONG NHÀ": "TYSTA HEMMETS SIREN",
  "Đã tắt còi trong nhà. Cảnh báo vẫn tiếp tục cho đến khi được xử lý.":
      "Hemmets siren är tystad. Larmet förblir aktivt tills det har hanterats.",
  "\$name đang chuẩn bị gửi tin...": "\$name skriver...",
  "\$name1 và \$name2 đang chuẩn bị gửi tin...":
      "\$name1 och \$name2 skriver...",
  "\$name và \$otherCount người khác đang chuẩn bị gửi tin...":
      "\$name och \$otherCount andra skriver...",
  "Kênh báo động cũ để giữ tương thích":
      "Den äldre larmkanalen behålls för kompatibilitet",
  "SafeHome báo động toàn màn hình": "SafeHome-larm i helskärm",
  "Mở cảnh báo toàn màn hình; âm còi phát từ trang báo động":
      "Öppnar helskärmslarm; sirenljudet spelas från larmsidan",
  "SafeHome cảnh báo khẩn cấp": "SafeHome-nödprioritet",
  "Cảnh báo khẩn cấp ưu tiên cao trước khi mở toàn màn hình":
      "Högprioriterat nödlarm innan helskärmen öppnas",
  "SafeHome nhắc nhở toàn màn hình": "SafeHome-schema i helskärm",
  "Nhắc nhở SafeHome toàn màn hình không âm thanh":
      "Tyst SafeHome-påminnelse i helskärm",
  "SafeHome nhắc nhở ưu tiên cao": "Prioritet för SafeHome-påminnelse",
  "Nhắc nhở SafeHome ưu tiên cao, không mở toàn màn hình":
      "Högprioriterad SafeHome-påminnelse utan helskärm",
  "Tin nhắn mới trong các nhà SafeHome": "Nya meddelanden i SafeHome-hem",
  "Hành động này sẽ thay đổi thời gian báo động của một số thiết bị hôm nay.\n\nBáo động của các thiết bị thuộc trường \"Nguy hiểm khẩn cấp\" và báo động ở chế độ \"Bảo vệ\" sẽ không bị ảnh hưởng bởi chức năng này.":
      "Den här åtgärden ändrar alarmtiden för vissa enheter i dag.\n\nLarm från enheter i kategorin ”Akut fara” och larm i läget ”Skydd” påverkas inte av den här funktionen.",
  "🆘 \$count nhà nguy hiểm\$suffix": "🆘 \$count hem i fara\$suffix",
  "FCM token đã sẵn sàng, nhưng tính năng tự động khi rời nhà còn thiếu điều kiện.":
      "FCM-token är klart, men Automatiskt bortaläge saknar ett krav.",
  "Đã kích hoạt SOS": "SOS har aktiverats",
  "Phát hiện chập điện": "Kortslutning upptäckt",
  "Phát hiện quá dòng": "Överström upptäckt",
  "Phát hiện quá áp": "Överspänning upptäckt",
  "Thiết bị điện quá nhiệt": "Elektrisk enhet överhettas",
  "Tài khoản đang được sử dụng": "Kontot används",
  "Hiện tại tài khoản này đang đăng nhập trên một thiết bị khác. Nếu tiếp tục, tài khoản trên thiết bị đó sẽ tự đăng xuất.":
      "Det här kontot är för närvarande inloggat på en annan enhet. Om du fortsätter loggas kontot på den enheten ut automatiskt.",
  "Tiếp tục đăng nhập": "Fortsätt logga in",
  "Tài khoản đã được đăng nhập trên một thiết bị khác.":
      "Det här kontot loggades in på en annan enhet.",
  "KHẨN CẤP": "NÖDLÄGE",
  "CẦN CHÚ Ý": "VARNING",
  "THÔNG TIN": "INFORMATION",
  "BÁO ĐỘNG": "LARM",
  "Cảm biến đã trở lại trạng thái an toàn.":
      "Sensorn återgick till ett säkert tillstånd.",
  "Người dùng đã tắt cảnh báo.": "Larmet stoppades av en användare.",
  "Khung giờ bảo vệ đã kết thúc.": "Skyddsschemat har upphört.",
  "Cảnh báo tức thời đã tự kết thúc.":
      "Det tillfälliga larmet upphörde automatiskt.",
  "Điều kiện cảnh báo không còn hoạt động.":
      "Larmvillkoret är inte längre aktivt.",
  "Cảnh báo đã kết thúc: \$reason": "Larmet har upphört: \$reason",
};

const Map<String, String> nlDynamicStrings = {
  "Bảo vệ - Tự động": "Beveiliging - Automatisch",
  "Bảo vệ - Thủ công": "Beveiliging - Handmatig",
  "Tự động": "Automatisch",
  "Thủ công": "Handmatig",
  "\$displayMemberName đã gia nhập nhà \"\$homeName\".":
      "\$displayMemberName is lid geworden van \"\$homeName\".",
  "NGUY HIỂM": "GEVAAR",
  "Nguy hiểm & Khẩn cấp": "Gevaar en noodgevallen",
  "TẮT CÒI": "SIRENE UITSCHAKELEN",
  "Tắt còi báo động?": "Alarmsirene uitschakelen?",
  "Còi vật lý sẽ dừng, nhưng cảnh báo vẫn tiếp tục cho đến khi sự cố được xử lý.\n\nBạn chắc chắn muốn tắt còi?":
      "De fysieke sirene stopt, maar de waarschuwing blijft actief totdat het incident is opgelost.\n\nWeet je zeker dat je de sirene wilt uitschakelen?",
  "Đã gửi lệnh tắt còi. Cảnh báo vẫn đang được theo dõi.":
      "De opdracht om de sirene uit te schakelen is verzonden. De waarschuwing wordt nog steeds bewaakt.",
  "Không tìm thấy cảnh báo đang hoạt động hoặc chưa thể gửi lệnh tắt còi.":
      "Er is geen actieve waarschuwing gevonden of de opdracht om de sirene uit te schakelen kon nog niet worden verzonden.",
  "TẮT CÒI TRONG NHÀ": "SIRENE IN HUIS UITSCHAKELEN",
  "Đã tắt còi trong nhà. Cảnh báo vẫn tiếp tục cho đến khi được xử lý.":
      "De sirene in huis is uitgeschakeld. De waarschuwing blijft actief totdat het incident is opgelost.",
  "\$name đang chuẩn bị gửi tin...": "\$name is een bericht aan het typen...",
  "\$name1 và \$name2 đang chuẩn bị gửi tin...":
      "\$name1 en \$name2 zijn een bericht aan het typen...",
  "\$name và \$otherCount người khác đang chuẩn bị gửi tin...":
      "\$name en \$otherCount anderen zijn een bericht aan het typen...",
  "Kênh báo động cũ để giữ tương thích":
      "Oud alarmkanaal voor achterwaartse compatibiliteit",
  "SafeHome báo động toàn màn hình": "SafeHome-alarm op volledig scherm",
  "Mở cảnh báo toàn màn hình; âm còi phát từ trang báo động":
      "Open de waarschuwing op volledig scherm; het sirenegeluid wordt afgespeeld vanaf de alarmpagina",
  "SafeHome cảnh báo khẩn cấp": "SafeHome-noodwaarschuwing",
  "Cảnh báo khẩn cấp ưu tiên cao trước khi mở toàn màn hình":
      "Noodwaarschuwing met hoge prioriteit vóór het openen op volledig scherm",
  "SafeHome nhắc nhở toàn màn hình": "SafeHome-herinnering op volledig scherm",
  "Nhắc nhở SafeHome toàn màn hình không âm thanh":
      "Stille SafeHome-herinnering op volledig scherm",
  "SafeHome nhắc nhở ưu tiên cao": "SafeHome-herinnering met hoge prioriteit",
  "Nhắc nhở SafeHome ưu tiên cao, không mở toàn màn hình":
      "SafeHome-herinnering met hoge prioriteit, zonder volledig scherm",
  "Tin nhắn mới trong các nhà SafeHome": "Nieuwe berichten in SafeHome-huizen",
  "Hành động này sẽ thay đổi thời gian báo động của một số thiết bị hôm nay.\n\nBáo động của các thiết bị thuộc trường \"Nguy hiểm khẩn cấp\" và báo động ở chế độ \"Bảo vệ\" sẽ không bị ảnh hưởng bởi chức năng này.":
      "Deze actie wijzigt vandaag de alarmtijd van sommige apparaten.\n\nAlarmen van apparaten in de categorie “Noodgevaar” en alarmen in de modus “Beveiliging” worden niet door deze functie beïnvloed.",
  "🆘 \$count nhà nguy hiểm\$suffix": "🆘 \$count huizen in gevaar\$suffix",
  "FCM token đã sẵn sàng, nhưng tính năng tự động khi rời nhà còn thiếu điều kiện.":
      "De FCM-token is gereed, maar voor de automatische functie bij vertrek ontbreken nog voorwaarden.",
  "Đã kích hoạt SOS": "SOS geactiveerd",
  "Phát hiện chập điện": "Kortsluiting gedetecteerd",
  "Phát hiện quá dòng": "Overstroom gedetecteerd",
  "Phát hiện quá áp": "Overspanning gedetecteerd",
  "Thiết bị điện quá nhiệt": "Elektrisch apparaat oververhit",
  "Tài khoản đang được sử dụng": "Account is in gebruik",
  "Hiện tại tài khoản này đang đăng nhập trên một thiết bị khác. Nếu tiếp tục, tài khoản trên thiết bị đó sẽ tự đăng xuất.":
      "Dit account is momenteel aangemeld op een ander apparaat. Als je doorgaat, wordt het account op dat apparaat automatisch afgemeld.",
  "Tiếp tục đăng nhập": "Doorgaan met aanmelden",
  "Tài khoản đã được đăng nhập trên một thiết bị khác.":
      "Het account is aangemeld op een ander apparaat.",
  "KHẨN CẤP": "NOODGEVAL",
  "CẦN CHÚ Ý": "AANDACHT VEREIST",
  "THÔNG TIN": "INFORMATIE",
  "BÁO ĐỘNG": "ALARM",
  "Cảm biến đã trở lại trạng thái an toàn.":
      "De sensor is teruggekeerd naar een veilige status.",
  "Người dùng đã tắt cảnh báo.":
      "De gebruiker heeft de waarschuwing uitgeschakeld.",
  "Khung giờ bảo vệ đã kết thúc.": "Het beveiligingsvenster is beëindigd.",
  "Cảnh báo tức thời đã tự kết thúc.":
      "De onmiddellijke waarschuwing is automatisch beëindigd.",
  "Điều kiện cảnh báo không còn hoạt động.":
      "De waarschuwingsvoorwaarde is niet langer actief.",
  "Cảnh báo đã kết thúc: \$reason": "Waarschuwing beëindigd: \$reason",
};

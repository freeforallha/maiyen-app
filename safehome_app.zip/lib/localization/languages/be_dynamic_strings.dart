const Map<String, String> beDynamicStrings = {
  "Bảo vệ - Tự động": "Ахова — Аўтаматычная",
  "Bảo vệ - Thủ công": "Ахова — Ручная",
  "Tự động": "Аўтаматычна",
  "Thủ công": "Уручную",
  "\$displayMemberName đã gia nhập nhà \"\$homeName\".":
      "\$displayMemberName далучыўся да дома \"\$homeName\".",
  "NGUY HIỂM": "НЕБЯСПЕКА",
  "Nguy hiểm & Khẩn cấp": "Небяспека і надзвычайная сітуацыя",
  "TẮT CÒI": "ВЫКЛЮЧЫЦЬ СІРЭНУ",
  "Tắt còi báo động?": "Выключыць сірэну трывогі?",
  "Còi vật lý sẽ dừng, nhưng cảnh báo vẫn tiếp tục cho đến khi sự cố được xử lý.\n\nBạn chắc chắn muốn tắt còi?":
      "Фізічная сірэна спыніцца, але папярэджанне будзе працягвацца, пакуль інцыдэнт не будзе вырашаны.\n\nВы ўпэўнены, што хочаце выключыць сірэну?",
  "Đã gửi lệnh tắt còi. Cảnh báo vẫn đang được theo dõi.":
      "Каманда на выключэнне сірэны адпраўлена. Папярэджанне ўсё яшчэ кантралюецца.",
  "Không tìm thấy cảnh báo đang hoạt động hoặc chưa thể gửi lệnh tắt còi.":
      "Актыўнае папярэджанне не знойдзена або не ўдалося адправіць каманду на выключэнне сірэны.",
  "TẮT CÒI TRONG NHÀ": "ВЫКЛЮЧЫЦЬ СІРЭНУ Ў ДОМЕ",
  "Đã tắt còi trong nhà. Cảnh báo vẫn tiếp tục cho đến khi được xử lý.":
      "Сірэна ў доме выключана. Папярэджанне будзе працягвацца, пакуль інцыдэнт не будзе вырашаны.",
  "\$name đang chuẩn bị gửi tin...": "\$name піша...",
  "\$name1 và \$name2 đang chuẩn bị gửi tin...": "\$name1 і \$name2 пішуць...",
  "\$name và \$otherCount người khác đang chuẩn bị gửi tin...":
      "\$name і яшчэ \$otherCount пішуць...",
  "Kênh báo động cũ để giữ tương thích":
      "Стары канал трывогі захаваны для сумяшчальнасці",
  "SafeHome báo động toàn màn hình": "Поўнаэкранная трывога SafeHome",
  "Mở cảnh báo toàn màn hình; âm còi phát từ trang báo động":
      "Адкрывае поўнаэкраннае папярэджанне; гук сірэны прайграецца са старонкі трывогі",
  "SafeHome cảnh báo khẩn cấp": "Надзвычайнае папярэджанне SafeHome",
  "Cảnh báo khẩn cấp ưu tiên cao trước khi mở toàn màn hình":
      "Надзвычайнае папярэджанне высокага прыярытэту перад адкрыццём на ўвесь экран",
  "SafeHome nhắc nhở toàn màn hình": "Поўнаэкранны напамін SafeHome",
  "Nhắc nhở SafeHome toàn màn hình không âm thanh":
      "Бязгучны поўнаэкранны напамін SafeHome",
  "SafeHome nhắc nhở ưu tiên cao": "Напамін SafeHome высокага прыярытэту",
  "Nhắc nhở SafeHome ưu tiên cao, không mở toàn màn hình":
      "Напамін SafeHome высокага прыярытэту без поўнаэкраннага рэжыму",
  "Tin nhắn mới trong các nhà SafeHome": "Новыя паведамленні ў дамах SafeHome",
  "Hành động này sẽ thay đổi thời gian báo động của một số thiết bị hôm nay.\n\nBáo động của các thiết bị thuộc trường \"Nguy hiểm khẩn cấp\" và báo động ở chế độ \"Bảo vệ\" sẽ không bị ảnh hưởng bởi chức năng này.":
      "Гэта дзеянне зменіць сёння час трывогі для некаторых прылад.\n\nТрывогі прылад з катэгорыі «Надзвычайная небяспека» і трывогі ў рэжыме «Ахова» не будуць закрануты гэтай функцыяй.",
  "🆘 \$count nhà nguy hiểm\$suffix": "🆘 \$count дамоў у небяспецы\$suffix",
  "FCM token đã sẵn sàng, nhưng tính năng tự động khi rời nhà còn thiếu điều kiện.":
      "Токен FCM гатовы, але для аўтаматычнага рэжыму пры выхадзе з дому яшчэ не выканана адна ўмова.",
  "Đã kích hoạt SOS": "SOS актываваны",
  "Phát hiện chập điện": "Выяўлена кароткае замыканне",
  "Phát hiện quá dòng": "Выяўлены звышток",
  "Phát hiện quá áp": "Выяўлена перанапружанне",
  "Thiết bị điện quá nhiệt": "Электрычная прылада перагрэлася",
  "Tài khoản đang được sử dụng": "Уліковы запіс выкарыстоўваецца",
  "Hiện tại tài khoản này đang đăng nhập trên một thiết bị khác. Nếu tiếp tục, tài khoản trên thiết bị đó sẽ tự đăng xuất.":
      "Гэты ўліковы запіс зараз увайшоў на іншай прыладзе. Калі працягнуць, на той прыладзе будзе выкананы аўтаматычны выхад.",
  "Tiếp tục đăng nhập": "Працягнуць уваход",
  "Tài khoản đã được đăng nhập trên một thiết bị khác.":
      "Уліковы запіс быў адкрыты на іншай прыладзе.",
  "KHẨN CẤP": "НАДЗВЫЧАЙНАЯ СІТУАЦЫЯ",
  "CẦN CHÚ Ý": "ПАТРАБУЕ ЎВАГІ",
  "THÔNG TIN": "ІНФАРМАЦЫЯ",
  "BÁO ĐỘNG": "ТРЫВОГА",
  "Cảm biến đã trở lại trạng thái an toàn.": "Датчык вярнуўся ў бяспечны стан.",
  "Người dùng đã tắt cảnh báo.": "Карыстальнік выключыў папярэджанне.",
  "Khung giờ bảo vệ đã kết thúc.": "Перыяд аховы скончыўся.",
  "Cảnh báo tức thời đã tự kết thúc.":
      "Імгненнае папярэджанне завяршылася аўтаматычна.",
  "Điều kiện cảnh báo không còn hoạt động.":
      "Умова папярэджання больш не дзейнічае.",
  "Cảnh báo đã kết thúc: \$reason": "Папярэджанне завершана: \$reason",
};

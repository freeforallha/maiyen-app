const Map<String, String> sqDynamicStrings = {
  "Bảo vệ - Tự động": "Mbrojtje - Automatike",
  "Bảo vệ - Thủ công": "Mbrojtje - Manuale",
  "Tự động": "Automatike",
  "Thủ công": "Manuale",
  "\$displayMemberName đã gia nhập nhà \"\$homeName\".":
      "\$displayMemberName u bashkua me \"\$homeName\".",
  "NGUY HIỂM": "RREZIK",
  "Nguy hiểm & Khẩn cấp": "Rrezik dhe emergjencë",
  "TẮT CÒI": "NDALO SIRENËN",
  "Tắt còi báo động?": "Të ndalohet sirena e alarmit?",
  "Còi vật lý sẽ dừng, nhưng cảnh báo vẫn tiếp tục cho đến khi sự cố được xử lý.\n\nBạn chắc chắn muốn tắt còi?":
      "Sirena fizike do të ndalet, por alarmi do të mbetet aktiv derisa incidenti të trajtohet.\n\nJeni të sigurt se doni ta ndaloni sirenën?",
  "Đã gửi lệnh tắt còi. Cảnh báo vẫn đang được theo dõi.":
      "Komanda për ndalimin e sirenës u dërgua. Alarmi po monitorohet ende.",
  "Không tìm thấy cảnh báo đang hoạt động hoặc chưa thể gửi lệnh tắt còi.":
      "Nuk u gjet alarm aktiv ose komanda për ndalimin e sirenës nuk mund të dërgohej.",
  "TẮT CÒI TRONG NHÀ": "HESHT SIRENËN E SHTËPISË",
  "Đã tắt còi trong nhà. Cảnh báo vẫn tiếp tục cho đến khi được xử lý.":
      "Sirena e shtëpisë është heshtur. Alarmi mbetet aktiv derisa të trajtohet.",
  "\$name đang chuẩn bị gửi tin...": "\$name po shkruan...",
  "\$name1 và \$name2 đang chuẩn bị gửi tin...":
      "\$name1 dhe \$name2 po shkruajnë...",
  "\$name và \$otherCount người khác đang chuẩn bị gửi tin...":
      "\$name dhe \$otherCount të tjerë po shkruajnë...",
  "Kênh báo động cũ để giữ tương thích":
      "Kanali i vjetër i Alarmit ruhet për pajtueshmëri",
  "SafeHome báo động toàn màn hình": "Alarm SafeHome në ekran të plotë",
  "Mở cảnh báo toàn màn hình; âm còi phát từ trang báo động":
      "Hap alarmet në ekran të plotë; tingulli i sirenës luhet nga faqja e Alarmit",
  "SafeHome cảnh báo khẩn cấp": "Përparësi emergjence SafeHome",
  "Cảnh báo khẩn cấp ưu tiên cao trước khi mở toàn màn hình":
      "Alarm emergjence me përparësi të lartë para se të hapet ekrani i plotë",
  "SafeHome nhắc nhở toàn màn hình": "Orari SafeHome në ekran të plotë",
  "Nhắc nhở SafeHome toàn màn hình không âm thanh":
      "Kujtesë e heshtur SafeHome në ekran të plotë",
  "SafeHome nhắc nhở ưu tiên cao": "Përparësi e Kujtesës SafeHome",
  "Nhắc nhở SafeHome ưu tiên cao, không mở toàn màn hình":
      "Kujtesë SafeHome me përparësi të lartë pa ekran të plotë",
  "Tin nhắn mới trong các nhà SafeHome": "Mesazhe të reja në shtëpitë SafeHome",
  "Hành động này sẽ thay đổi thời gian báo động của một số thiết bị hôm nay.\n\nBáo động của các thiết bị thuộc trường \"Nguy hiểm khẩn cấp\" và báo động ở chế độ \"Bảo vệ\" sẽ không bị ảnh hưởng bởi chức năng này.":
      "Ky veprim do të ndryshojë sot orën e alarmit për disa pajisje.\n\nAlarmet e pajisjeve në kategorinë “Rrezik emergjent” dhe alarmet në modalitetin “Mbrojtje” nuk do të ndikohen nga kjo veçori.",
  "🆘 \$count nhà nguy hiểm\$suffix": "🆘 \$count shtëpi në rrezik\$suffix",
  "FCM token đã sẵn sàng, nhưng tính năng tự động khi rời nhà còn thiếu điều kiện.":
      "Tokeni FCM është gati, por Largimit automatik i mungon një kërkesë.",
  "Đã kích hoạt SOS": "SOS u aktivizua",
  "Phát hiện chập điện": "U zbulua qark i shkurtër",
  "Phát hiện quá dòng": "U zbulua mbirrymë",
  "Phát hiện quá áp": "U zbulua mbitension",
  "Thiết bị điện quá nhiệt": "Pajisja elektrike po mbinxehet",
  "Tài khoản đang được sử dụng": "Llogaria është në përdorim",
  "Hiện tại tài khoản này đang đăng nhập trên một thiết bị khác. Nếu tiếp tục, tài khoản trên thiết bị đó sẽ tự đăng xuất.":
      "Kjo llogari është aktualisht e hapur në një pajisje tjetër. Nëse vazhdoni, llogaria në atë pajisje do të dalë automatikisht.",
  "Tiếp tục đăng nhập": "Vazhdo hyrjen",
  "Tài khoản đã được đăng nhập trên một thiết bị khác.":
      "Kjo llogari u hap në një pajisje tjetër.",
  "KHẨN CẤP": "EMERGJENCË",
  "CẦN CHÚ Ý": "PARALAJMËRIM",
  "THÔNG TIN": "INFORMACION",
  "BÁO ĐỘNG": "ALARM",
  "Cảm biến đã trở lại trạng thái an toàn.":
      "Sensori u kthye në gjendje të sigurt.",
  "Người dùng đã tắt cảnh báo.": "Alarmi u ndal nga një përdorues.",
  "Khung giờ bảo vệ đã kết thúc.": "Orari i mbrojtjes përfundoi.",
  "Cảnh báo tức thời đã tự kết thúc.":
      "Alarmi i përkohshëm përfundoi automatikisht.",
  "Điều kiện cảnh báo không còn hoạt động.":
      "Kushti i alarmit nuk është më aktiv.",
  "Cảnh báo đã kết thúc: \$reason": "Alarmi përfundoi: \$reason",
};

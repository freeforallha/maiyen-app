const Map<String, String> elDynamicStrings = {
  "Bảo vệ - Tự động": "Προστασία - Αυτόματη",
  "Bảo vệ - Thủ công": "Προστασία - Χειροκίνητη",
  "Tự động": "Αυτόματο",
  "Thủ công": "Χειροκίνητο",
  "\$displayMemberName đã gia nhập nhà \"\$homeName\".":
      "Ο/Η \$displayMemberName συμμετείχε στο \"\$homeName\".",
  "NGUY HIỂM": "ΚΙΝΔΥΝΟΣ",
  "Nguy hiểm & Khẩn cấp": "Κίνδυνος και έκτακτη ανάγκη",
  "TẮT CÒI": "ΔΙΑΚΟΠΗ ΣΕΙΡΗΝΑΣ",
  "Tắt còi báo động?": "Διακοπή της σειρήνας συναγερμού;",
  "Còi vật lý sẽ dừng, nhưng cảnh báo vẫn tiếp tục cho đến khi sự cố được xử lý.\n\nBạn chắc chắn muốn tắt còi?":
      "Η φυσική σειρήνα θα σταματήσει, αλλά η ειδοποίηση θα παραμείνει ενεργή μέχρι να αντιμετωπιστεί το συμβάν.\n\nΕίστε βέβαιοι ότι θέλετε να σταματήσετε τη σειρήνα;",
  "Đã gửi lệnh tắt còi. Cảnh báo vẫn đang được theo dõi.":
      "Η εντολή διακοπής σειρήνας στάλθηκε. Η ειδοποίηση εξακολουθεί να παρακολουθείται.",
  "Không tìm thấy cảnh báo đang hoạt động hoặc chưa thể gửi lệnh tắt còi.":
      "Δεν βρέθηκε ενεργή ειδοποίηση ή δεν ήταν δυνατή η αποστολή της εντολής διακοπής σειρήνας.",
  "TẮT CÒI TRONG NHÀ": "ΣΙΓΑΣΗ ΣΕΙΡΗΝΑΣ ΣΠΙΤΙΟΥ",
  "Đã tắt còi trong nhà. Cảnh báo vẫn tiếp tục cho đến khi được xử lý.":
      "Η σειρήνα του σπιτιού έχει σιγήσει. Η ειδοποίηση παραμένει ενεργή μέχρι να αντιμετωπιστεί.",
  "\$name đang chuẩn bị gửi tin...": "Ο/Η \$name πληκτρολογεί...",
  "\$name1 và \$name2 đang chuẩn bị gửi tin...":
      "Οι \$name1 και \$name2 πληκτρολογούν...",
  "\$name và \$otherCount người khác đang chuẩn bị gửi tin...":
      "Ο/Η \$name και \$otherCount ακόμη πληκτρολογούν...",
  "Kênh báo động cũ để giữ tương thích":
      "Το παλαιό κανάλι Συναγερμού διατηρείται για συμβατότητα",
  "SafeHome báo động toàn màn hình": "Συναγερμός SafeHome πλήρους οθόνης",
  "Mở cảnh báo toàn màn hình; âm còi phát từ trang báo động":
      "Ανοίγει συναγερμούς πλήρους οθόνης· ο ήχος της σειρήνας αναπαράγεται από τη σελίδα Συναγερμού",
  "SafeHome cảnh báo khẩn cấp": "Προτεραιότητα έκτακτης ανάγκης SafeHome",
  "Cảnh báo khẩn cấp ưu tiên cao trước khi mở toàn màn hình":
      "Ειδοποίηση έκτακτης ανάγκης υψηλής προτεραιότητας πριν ανοίξει η πλήρης οθόνη",
  "SafeHome nhắc nhở toàn màn hình": "Πρόγραμμα SafeHome πλήρους οθόνης",
  "Nhắc nhở SafeHome toàn màn hình không âm thanh":
      "Αθόρυβη Υπενθύμιση SafeHome πλήρους οθόνης",
  "SafeHome nhắc nhở ưu tiên cao": "Προτεραιότητα Υπενθύμισης SafeHome",
  "Nhắc nhở SafeHome ưu tiên cao, không mở toàn màn hình":
      "Υπενθύμιση SafeHome υψηλής προτεραιότητας χωρίς πλήρη οθόνη",
  "Tin nhắn mới trong các nhà SafeHome": "Νέα μηνύματα σε σπίτια SafeHome",
  "Hành động này sẽ thay đổi thời gian báo động của một số thiết bị hôm nay.\n\nBáo động của các thiết bị thuộc trường \"Nguy hiểm khẩn cấp\" và báo động ở chế độ \"Bảo vệ\" sẽ không bị ảnh hưởng bởi chức năng này.":
      "Αυτή η ενέργεια θα αλλάξει σήμερα την ώρα συναγερμού ορισμένων συσκευών.\n\nΟι συναγερμοί συσκευών στην κατηγορία «Κίνδυνος έκτακτης ανάγκης» και οι συναγερμοί στη λειτουργία «Προστασία» δεν θα επηρεαστούν από αυτή τη λειτουργία.",
  "🆘 \$count nhà nguy hiểm\$suffix": "🆘 \$count σπίτια σε κίνδυνο\$suffix",
  "FCM token đã sẵn sàng, nhưng tính năng tự động khi rời nhà còn thiếu điều kiện.":
      "Το διακριτικό FCM είναι έτοιμο, αλλά λείπει μία απαίτηση για την Αυτόματη Απουσία.",
  "Đã kích hoạt SOS": "Το SOS ενεργοποιήθηκε",
  "Phát hiện chập điện": "Εντοπίστηκε βραχυκύκλωμα",
  "Phát hiện quá dòng": "Εντοπίστηκε υπερένταση",
  "Phát hiện quá áp": "Εντοπίστηκε υπέρταση",
  "Thiết bị điện quá nhiệt": "Υπερθέρμανση ηλεκτρικής συσκευής",
  "Tài khoản đang được sử dụng": "Ο λογαριασμός χρησιμοποιείται",
  "Hiện tại tài khoản này đang đăng nhập trên một thiết bị khác. Nếu tiếp tục, tài khoản trên thiết bị đó sẽ tự đăng xuất.":
      "Αυτός ο λογαριασμός είναι συνδεδεμένος σε άλλη συσκευή. Αν συνεχίσετε, ο λογαριασμός σε εκείνη τη συσκευή θα αποσυνδεθεί αυτόματα.",
  "Tiếp tục đăng nhập": "Συνέχεια σύνδεσης",
  "Tài khoản đã được đăng nhập trên một thiết bị khác.":
      "Αυτός ο λογαριασμός συνδέθηκε σε άλλη συσκευή.",
  "KHẨN CẤP": "ΕΚΤΑΚΤΗ ΑΝΑΓΚΗ",
  "CẦN CHÚ Ý": "ΠΡΟΕΙΔΟΠΟΙΗΣΗ",
  "THÔNG TIN": "ΠΛΗΡΟΦΟΡΙΑ",
  "BÁO ĐỘNG": "ΣΥΝΑΓΕΡΜΟΣ",
  "Cảm biến đã trở lại trạng thái an toàn.":
      "Ο αισθητήρας επέστρεψε σε ασφαλή κατάσταση.",
  "Người dùng đã tắt cảnh báo.": "Η ειδοποίηση διακόπηκε από έναν χρήστη.",
  "Khung giờ bảo vệ đã kết thúc.": "Το πρόγραμμα προστασίας έληξε.",
  "Cảnh báo tức thời đã tự kết thúc.": "Η προσωρινή ειδοποίηση έληξε αυτόματα.",
  "Điều kiện cảnh báo không còn hoạt động.":
      "Η συνθήκη ειδοποίησης δεν είναι πλέον ενεργή.",
  "Cảnh báo đã kết thúc: \$reason": "Η ειδοποίηση έληξε: \$reason",
};

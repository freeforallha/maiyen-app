const Map<String, String> plStrings = {
  "Không tìm thấy người dùng": "Nie znaleziono użytkownika",
  "Không đọc được số điện thoại": "Nie można odczytać numeru telefonu",
  "Tin nhắn quá dài": "Wiadomość jest zbyt długa",
  "Không gửi được tin nhắn": "Nie udało się wysłać wiadomości",
  "Bạn không có quyền sửa lịch chung của nhà":
      "Nie masz uprawnień do edytowania wspólnego harmonogramu domu",
  "Nhà của bạn": "Twój dom",
  "Tải tin cũ hơn": "Wczytaj starsze wiadomości",
  "Nhà chưa đặt tên": "Dom bez nazwy",
  "Nhà": "Dom",
  "Chưa có thông tin": "Brak informacji",
  "Chưa cập nhật": "Nie zaktualizowano",
  "Chủ nhà": "Właściciel",
  "Nhà được chia sẻ": "Udostępniony dom",
  "Địa chỉ": "Adres",
  "An ninh ra/vào": "Bezpieczeństwo wejścia",
  "Nguy hiểm khẩn cấp": "Zagrożenia i sytuacje awaryjne",
  "Điều khiển & hạ tầng": "Sterowanie i infrastruktura",
  "Môi trường": "Środowisko",
  "Toàn bộ thiết bị SafeHome": "Wszystkie urządzenia SafeHome",
  "Cửa ra/vào": "Drzwi wejściowe",
  "Cửa": "Drzwi",
  "Cửa sổ": "Okno",
  "Cổng": "Brama",
  "Khóa thông minh": "Inteligentny zamek",
  "Chuyển động": "Ruch",
  "Hiện diện": "Obecność",
  "Rung/chấn động": "Wibracje/wstrząsy",
  "Kính vỡ": "Stłuczenie szyby",
  "Báo khói": "Czujnik dymu",
  "Báo nhiệt": "Czujnik wysokiej temperatury",
  "Khí CO": "Tlenek węgla",
  "Báo gas": "Czujnik gazu",
  "Báo ngập/rò nước": "Czujnik zalania/wycieku wody",
  "Nút SOS": "Przycisk SOS",
  "Nhiệt độ/Độ ẩm": "Temperatura/Wilgotność",
  "Bụi mịn PM2.5": "Pył zawieszony PM2.5",
  "CO₂": "CO₂",
  "Chất lượng không khí": "Jakość powietrza",
  "Ổ điện thông minh": "Inteligentne gniazdko",
  "Còi báo động": "Syrena alarmowa",
  "Van thông minh": "Inteligentny zawór",
  "Camera": "Kamera",
  "Chuông cửa": "Dzwonek do drzwi",
  "Bàn phím an ninh": "Klawiatura alarmowa",
  "Bộ mở rộng sóng": "Wzmacniacz sygnału",
  "Hub trung tâm": "Centralny hub",
  "Đo điện năng": "Pomiar energii",
  "Nguồn dự phòng UPS": "Zasilanie awaryjne UPS",
  "Thiết bị đang Offline": "Urządzenie jest offline",
  "Thiết bị đang Online": "Urządzenie jest online",
  "lâu không phản hồi": "od dawna nie odpowiada",
  "Kết nối cần kiểm tra": "Połączenie wymaga sprawdzenia",
  "Vừa xong": "Przed chwilą",
  "Bị tháo": "Wykryto sabotaż",
  "Có khói": "Wykryto dym",
  "Bình thường": "Normalny",
  "Bảo vệ": "Ochrona",
  "Chế độ Bảo vệ": "Tryb ochrony",
  "Tự động Bảo vệ khi rời nhà": "Automatyczna ochrona po wyjściu z domu",
  "Đã kích hoạt": "Aktywowano",
  "Sẵn sàng": "Gotowe",
  "Đang đóng": "Zamknięte",
  "Đang mở": "Otwarte",
  "Rò rỉ gas": "Wykryto wyciek gazu",
  "Phát hiện ngập nước": "Wykryto wyciek wody",
  "Phát hiện chuyển động": "Wykryto ruch",
  "Không có chuyển động": "Nie wykryto ruchu",
  "Phát hiện hiện diện": "Wykryto obecność",
  "Không phát hiện hiện diện": "Nie wykryto obecności",
  "Phát hiện rung/chấn động": "Wykryto wibracje/wstrząsy",
  "Không có rung bất thường": "Brak nietypowych wibracji",
  "Phát hiện kính vỡ": "Wykryto stłuczenie szyby",
  "Không có cảnh báo kính vỡ": "Brak alarmu stłuczenia szyby",
  "Nhiệt độ nguy hiểm": "Wykryto niebezpiecznie wysoką temperaturę",
  "Phát hiện khí CO": "Wykryto tlenek węgla",
  "Không phát hiện khí CO": "Nie wykryto tlenku węgla",
  "Khóa đang mở": "Odblokowany",
  "Khóa đang đóng": "Zablokowany",
  "Đang bật": "Włączone",
  "Bật": "Włączone",
  "Đang tắt": "Wyłączone",
  "Đang theo dõi điện năng": "Monitorowanie zużycia energii",
  "Đang dùng nguồn dự phòng": "Zasilanie awaryjne w użyciu",
  "Nguồn điện bình thường": "Zasilanie sieciowe działa prawidłowo",
  "Còi đang bật": "Syrena aktywna",
  "Còi sẵn sàng": "Syrena gotowa",
  "Van đang mở": "Zawór otwarty",
  "Van đã đóng": "Zawór zamknięty",
  "Đang hoạt động": "Działa",
  "Đang theo dõi": "Monitorowanie",
  "Chưa nhận diện": "Nierozpoznane urządzenie",
  "Chưa có cập nhật": "Brak aktualizacji",
  "Chưa có thiết bị, hãy nhấn nút + để thêm để bắt đầu duy trì an ninh":
      "Brak urządzeń. Naciśnij +, aby dodać pierwsze i zacząć chronić dom.",
  "CHƯA AN TOÀN": "NIEBEZPIECZNIE",
  "ĐÃ AN TOÀN": "BEZPIECZNIE",
  "Nhà đang có dấu hiệu cần kiểm tra, bạn nên xem lại các trạng thái bên dưới.":
      "Dom wymaga uwagi. Sprawdź poniższe stany.",
  "Nhà đang hoạt động ổn định, bạn có thể yên tâm.":
      "Dom działa prawidłowo. Możesz czuć się bezpiecznie.",
  "Không có dấu hiệu khói hoặc SOS bất thường.":
      "Nie wykryto nietypowego dymu ani zdarzeń SOS.",
  "Chưa có nhiều hoạt động mới để phân tích sâu hơn.":
      "Za mało ostatnich zdarzeń do dokładniejszej analizy.",
  "Hub kết nối bình thường": "Hub połączony",
  "Cài đặt cảnh báo cho nhà hiện tại": "Ustawienia alertów dla tego domu",
  "Nhận cảnh báo báo động": "Otrzymuj alerty alarmowe",
  "Đang bật cho tài khoản này": "Włączone dla tego konta",
  "Đang tắt cho tài khoản này": "Wyłączone dla tego konta",
  "Hẹn giờ nhắc nhở": "Harmonogram przypomnień",
  "Nhắc kiểm tra nhà theo thời gian":
      "Zaplanuj przypomnienia o sprawdzeniu domu",
  "Hẹn giờ báo động": "Harmonogram alarmu",
  "Chưa thiết lập": "Nie ustawiono",
  "Chưa thiết lập thời gian": "Nie skonfigurowano harmonogramu",
  "Tổng hợp trạng thái nhà": "Podsumowanie stanu domu",
  "Cần xử lý ngay": "Wymaga natychmiastowego działania",
  "Đánh giá tự động": "Automatyczna ocena",
  "Tự động đánh giá": "Automatyczna ocena",
  "Tổng quan hôm nay": "Dzisiejszy przegląd",
  "Chưa có dữ liệu tổng quan": "Brak danych podsumowania",
  "Chưa có dữ liệu trạng thái": "Brak danych o stanie",
  "Chưa đủ dữ liệu để đánh giá": "Za mało danych do oceny",
  "Chưa có dữ liệu để đánh giá": "Brak danych do oceny",
  "Bấm vào để xem chi tiết": "Dotknij, aby wyświetlić szczegóły",
  "Nhấn để xem chi tiết...": "Dotknij, aby wyświetlić szczegóły...",
  "Tạm dừng": "Wstrzymano",
  "Tắt": "Wyłączone",
  "Chi tiết": "Szczegóły",
  "Tổng hợp trạng thái": "Podsumowanie stanu",
  "Không an toàn": "Niebezpiecznie",
  "Cần chú ý": "Wymaga uwagi",
  "An toàn": "Bezpiecznie",
  "Không có": "Brak",
  "Đổi tên nhóm": "Zmień nazwę grupy",
  "Huỷ": "Anuluj",
  "Lưu": "Zapisz",
  "Thêm": "Dodaj",
  "Xoá": "Usuń",
  "Đổi tên": "Zmień nazwę",
  "Nhà của tôi": "Moje domy",
  "Bỏ chọn toàn bộ nhóm": "Odznacz całą grupę",
  "Chọn toàn bộ nhóm": "Zaznacz całą grupę",
  "Bỏ chọn": "Odznacz",
  "Quay lại": "Wstecz",
  "Tìm kiếm": "Szukaj",
  "Đóng tìm kiếm": "Zamknij wyszukiwanie",
  "Giờ": "Godzina",
  "Phút": "Minuta",
  "Đặt nhắc nhở cho nhà": "Ustaw przypomnienie dla domu",
  "Đặt báo động cho nhà": "Ustaw alarm dla domu",
  "Xác nhận thay đổi": "Potwierdź zmiany",
  "Tiếp tục": "Kontynuuj",
  "Giờ nhắc nhở": "Godzina przypomnienia",
  "Giờ bắt đầu báo động": "Godzina rozpoczęcia alarmu",
  "Giờ kết thúc báo động": "Godzina zakończenia alarmu",
  "Không có nhà nào đủ điều kiện để cài":
      "Nie znaleziono domów spełniających warunki",
  "Cài đặt hoàn tất": "Konfiguracja zakończona",
  "Xác nhận rời nhà": "Potwierdź opuszczenie domu",
  "Xác nhận xoá nhà": "Potwierdź usunięcie domu",
  "Nhập mật khẩu": "Wprowadź hasło",
  "Mật khẩu tài khoản": "Hasło do konta",
  "Rời khỏi nhà": "Opuść dom",
  "Xoá nhà": "Usuń dom",
  "Sai mật khẩu": "Nieprawidłowe hasło",
  "Đã rời khỏi home": "Opuszczono dom",
  "Đã cập nhật": "Zaktualizowano",
  "Tìm home...": "Szukaj domów...",
  "Đặt vị trí nhà và bật bảo vệ tự động":
      "Ustaw lokalizację domu i włącz automatyczną ochronę",
  "Chuyển quyền chủ nhà hoặc xoá nhà": "Przenieś własność domu lub usuń dom",
  "Đặt nhắc nhở / báo động nhà đã chọn":
      "Ustaw przypomnienie/alarm dla wybranych domów",
  "Chia sẻ nhà đã chọn": "Udostępnij wybrane domy",
  "Mở danh sách chia sẻ nhà": "Otwórz listę udostępniania domów",
  "Xoá các nhà đã chọn?": "Usunąć wybrane domy?",
  "Các nhà đã chọn sẽ bị xoá vĩnh viễn.":
      "Wybrane domy zostaną trwale usunięte.",
  "Hoặc quét QR để xin gia nhập các nhà đã chọn":
      "Lub zeskanuj kod QR, aby poprosić o dostęp do wybranych domów",
  "Email người nhận": "Adres e-mail odbiorcy",
  "Chia sẻ": "Udostępnij",
  "Email chưa đăng ký": "Adres e-mail nie jest zarejestrowany",
  "Chia sẻ hoàn tất": "Udostępnianie zakończone",
  "Mở List chia sẻ nhà": "Otwórz listę udostępniania domów",
  "Không có nhà nào bạn có quyền quản lý":
      "Nie zarządzasz żadnym z wybranych domów",
  "Chưa share cho ai": "Jeszcze nikomu nie udostępniono",
  "Tìm nhà": "Szukaj domów",
  "Xoá các nhà đã chọn ?": "Usunąć wybrane domy?",
  "Thông báo Home": "Powiadomienia domu",
  "Thông báo nhà": "Powiadomienia domu",
  "Vai trò thành viên đã thay đổi": "Zmieniono rolę członka",
  "Xoá tất cả thông báo?": "Usunąć wszystkie powiadomienia?",
  "Toàn bộ thông báo nhà sẽ bị xoá.":
      "Wszystkie powiadomienia domu zostaną usunięte.",
  "Chưa có thông báo nào": "Brak powiadomień",
  "Chưa có thông báo": "Brak powiadomień",
  "Vuốt lên để tải thêm": "Przesuń w górę, aby wczytać więcej",
  "Không có thiết bị": "Brak urządzeń",
  "Chỉ chủ nhà mới được xoá nhà": "Tylko właściciel może usunąć ten dom",
  "Chỉ chủ nhà mới được chuyển quyền":
      "Tylko właściciel może przenieść własność",
  "Lưu ý khi bật báo động": "Informacja o włączeniu alarmu",
  "Báo động đã được bật": "Alarm został włączony",
  "Đã hiểu": "Rozumiem",
  "Lưu ý tạm tắt báo động": "Informacja o wstrzymaniu alarmu",
  "Đã bật báo động": "Alarm włączony",
  "Đã tắt báo động": "Alarm wyłączony",
  "Tắt báo động": "Wyłącz alarm",
  "Cả ngày": "Cały dzień",
  "Bạn không có quyền thực hiện thao tác này.":
      "Nie masz uprawnień do wykonania tej czynności.",
  "Không thể hoàn tất thao tác. Vui lòng thử lại.":
      "Nie udało się wykonać tej czynności. Spróbuj ponownie.",
  "QR gia nhập nhiều nhà không hợp lệ":
      "Nieprawidłowy kod QR do dołączenia do wielu domów",
  "Bạn đang là chủ các nhà này": "Jesteś właścicielem tych domów",
  "Một người dùng": "Użytkownik",
  "Yêu cầu gia nhập nhà": "Prośba o dołączenie do domu",
  "Đã gửi yêu cầu gia nhập nhà": "Wysłano prośbę o dołączenie",
  "QR gia nhập không hợp lệ": "Nieprawidłowy kod QR do dołączenia",
  "Bạn đang là chủ nhà này": "Jesteś już właścicielem tego domu",
  "QR này không phải mã xin gia nhập nhà":
      "Ten kod QR nie służy do dołączania do domu",
  "Bạn không có quyền thêm thiết bị":
      "Nie masz uprawnień do dodawania urządzeń",
  "Đã mở chế độ thêm thiết bị": "Włączono tryb parowania urządzeń",
  "Rời khỏi Home này?": "Opuścić ten dom?",
  "Nhà này và toàn bộ thiết bị bên trong sẽ bị xoá vĩnh viễn.":
      "Ten dom i wszystkie znajdujące się w nim urządzenia zostaną trwale usunięte.",
  "Đã xoá nhà": "Usunięto dom",
  "QR của nhà này": "Kod QR tego domu",
  "Người khác quét mã này để gửi yêu cầu gia nhập nhà.":
      "Inne osoby mogą zeskanować ten kod, aby poprosić o dostęp do domu.",
  "Chia sẻ nhà": "Udostępnij dom",
  "Quét QR để xin gia nhập nhà": "Zeskanuj kod QR, aby dołączyć do domu",
  "Quét QR xin gia nhập nhà": "Zeskanuj kod QR, aby dołączyć do domu",
  "Đưa mã QR chia sẻ nhà vào khung hình":
      "Umieść kod QR udostępnionego domu w ramce",
  "Mã QR này do chủ nhà chia sẻ":
      "Ten kod QR został udostępniony przez właściciela domu",
  "Nhập mã mời": "Wprowadź kod zaproszenia",
  "Gửi yêu cầu gia nhập": "Wyślij prośbę o dołączenie",
  "QR này không phải mã thiết bị": "Ten kod QR nie jest kodem urządzenia",
  "Xin gia nhập nhà": "Poproś o dołączenie do domu",
  "Quét mã QR chia sẻ nhà": "Zeskanuj kod QR udostępniania domu",
  "Mời thành viên bằng mã QR": "Zaproś członka kodem QR",
  "Không thể share cho chính bạn": "Nie możesz udostępnić domu samemu sobie",
  "Lời mời chia sẻ nhà": "Zaproszenie do udostępnionego domu",
  "Đã share home": "Udostępniono dom",
  "Chuyển quyền chủ nhà": "Przenieś własność",
  "Không thể chuyển quyền cho chính bạn":
      "Nie możesz przenieść własności na siebie",
  "Không tìm thấy user": "Nie znaleziono użytkownika",
  "Không tìm thấy tài khoản": "Nie znaleziono konta",
  "Xác nhận chuyển quyền": "Potwierdź przeniesienie własności",
  "Chuyển": "Przenieś",
  "Xác nhận mật khẩu": "Potwierdź hasło",
  "Yêu cầu chuyển quyền chủ nhà": "Prośba o przeniesienie własności",
  "Đã gửi yêu cầu chuyển quyền": "Wysłano prośbę o przeniesienie",
  "Đã gửi yêu cầu chuyển quyền chủ nhà":
      "Wysłano prośbę o przeniesienie własności domu",
  "Bạn không có quyền xoá thiết bị": "Nie masz uprawnień do usuwania urządzeń",
  "Xóa Device?": "Usunąć urządzenie?",
  "Đã gửi yêu cầu xoá thiết bị": "Wysłano prośbę o usunięcie urządzenia",
  "Đang xoá thiết bị": "Usuwanie urządzenia",
  "Đăng xuất?": "Wylogować się?",
  "Thêm nhà": "Dodaj dom",
  "Thêm nhà mới": "Dodaj nowy dom",
  "Tạo nhà mới": "Utwórz nowy dom",
  "Tạo một ngôi nhà mới của bạn": "Utwórz swój nowy dom",
  "Quét mã QR được chủ nhà chia sẻ":
      "Zeskanuj kod QR udostępniony przez właściciela domu",
  "Tên nhà": "Nazwa domu",
  "Số điện thoại": "Numer telefonu",
  "Nam": "Mężczyzna",
  "Nữ": "Kobieta",
  "Ngày": "Dzień",
  "Tháng": "Miesiąc",
  "Năm": "Rok",
  "Thông tin cá nhân": "Dane osobowe",
  "Thiết lập tài khoản": "Skonfiguruj konto",
  "Vui lòng nhập đủ thông tin": "Wprowadź wszystkie wymagane informacje",
  "Không thể lưu thông tin": "Nie udało się zapisać informacji",
  "Đã lưu thông tin": "Zapisano informacje",
  "Lỗi lưu profile": "Nie udało się zapisać profilu",
  "Thêm số điện thoại để dùng cho các trường hợp khẩn cấp":
      "Dodaj numer telefonu do użycia w sytuacjach awaryjnych",
  "Hoàn tất": "Gotowe",
  "Đã tạo nhà mới": "Utworzono nowy dom",
  "Về muộn": "Późny powrót",
  "Ra ngoài": "Wyjście",
  "Khác": "Inne",
  "⏸️ Tạm tắt báo động hôm nay": "⏸️ Tymczasowo wyłącz alarm na dziś",
  "Chọn giờ bắt đầu tạm tắt": "Wybierz godzinę rozpoczęcia przerwy",
  "Từ": "Od",
  "Từ giờ": "Od teraz",
  "Chọn giờ kết thúc tạm tắt": "Wybierz godzinę zakończenia przerwy",
  "Đến": "Do",
  "Đến giờ": "Do godziny",
  "Xoá lịch tạm tắt": "Usuń harmonogram przerwy",
  "Xóa lịch tạm tắt": "Usuń harmonogram przerwy",
  "Giới tính": "Płeć",
  "SĐT": "Telefon",
  "Ngày sinh": "Data urodzenia",
  "Yêu cầu & lời mời": "Prośby i zaproszenia",
  "Xem lời mời chia sẻ và xin gia nhập":
      "Wyświetl zaproszenia do udostępnienia i prośby o dołączenie",
  "Cài đặt bảo mật": "Ustawienia zabezpieczeń",
  "Quyền báo động toàn màn hình": "Uprawnienie do alarmu pełnoekranowego",
  "Báo động toàn màn hình": "Alarm pełnoekranowy",
  "Đã được cấp quyền": "Uprawnienie przyznane",
  "Chưa được cấp quyền": "Brak uprawnienia",
  "Mở cài đặt hệ thống": "Otwórz ustawienia systemu",
  "Đăng xuất": "Wyloguj się",
  "Thoát tài khoản khỏi thiết bị này": "Wyloguj konto z tego urządzenia",
  "Không có yêu cầu hoặc lời mời nào": "Brak próśb i zaproszeń",
  "Xoá tài khoản": "Usuń konto",
  "Hành động này sẽ xoá toàn bộ dữ liệu:": "Ta czynność usunie wszystkie dane:",
  "Nhà và thiết bị": "Domy i urządzenia",
  "Chia sẻ và quyền truy cập": "Udostępnianie i dostęp",
  "Toàn bộ dữ liệu liên quan": "Wszystkie powiązane dane",
  "Mật khẩu xác nhận": "Hasło potwierdzające",
  "Đã xoá tài khoản": "Usunięto konto",
  "Xoá thất bại": "Nie udało się usunąć",
  "Lỗi xoá tài khoản": "Nie udało się usunąć konta",
  "Tình trạng": "Stan",
  "Tháo/Lắp": "Sabotaż",
  "Pin": "Bateria",
  "Tín hiệu": "Sygnał",
  "Chưa liên kết": "Niepowiązane",
  "Liên lạc cuối": "Ostatni kontakt",
  "Event cuối": "Ostatnie zdarzenie",
  "Sự kiện cuối": "Ostatnie zdarzenie",
  "Lần kích hoạt cuối": "Ostatnie uruchomienie",
  "Thiết bị không còn tồn tại": "Urządzenie już nie istnieje",
  "Mất kết nối": "Rozłączono",
  "Online": "Online",
  "Offline": "Offline",
  "Loại thiết bị": "Typ urządzenia",
  "Nhiệt độ": "Temperatura",
  "Độ ẩm": "Wilgotność",
  "Công suất": "Moc",
  "Điện áp": "Napięcie",
  "Dòng điện": "Natężenie prądu",
  "Điện năng": "Energia",
  "Cường độ rung": "Siła wibracji",
  "Góc nghiêng": "Kąt nachylenia",
  "Độ mở van": "Stopień otwarcia zaworu",
  "Nguồn dự phòng": "Zasilanie awaryjne",
  "Ngập/rò nước": "Zalanie/wyciek wody",
  "Phát hiện khói": "Wykryto dym",
  "Quản lý phòng": "Zarządzanie pomieszczeniami",
  "Bạn không có quyền quản lý phòng":
      "Nie masz uprawnień do zarządzania pomieszczeniami",
  "Đổi tên phòng": "Zmień nazwę pomieszczenia",
  "Tên phòng": "Nazwa pomieszczenia",
  "Xoá phòng": "Usuń pomieszczenie",
  "Thiết bị trong phòng này sẽ được chuyển về Chưa phân phòng.":
      "Urządzenia z tego pomieszczenia zostaną przeniesione do sekcji Nieprzypisane.",
  "Thêm phòng": "Dodaj pomieszczenie",
  "Ví dụ: Phòng khách": "Przykład: Salon",
  "Phòng khách": "Salon",
  "Tên phòng đã tồn tại": "Ta nazwa pomieszczenia już istnieje",
  "Chưa phân phòng": "Nieprzypisane",
  "Phòng mặc định": "Domyślne pomieszczenie",
  "Phát hiện bất thường": "Wykryto nietypową aktywność",
  "Phát hiện cạy phá": "Wykryto próbę manipulacji",
  "Tamper detected": "Wykryto sabotaż",
  "Tamper cleared": "Alarm sabotażowy usunięty",
  "Door opened": "Drzwi otwarte",
  "Door closed": "Drzwi zamknięte",
  "Motion detected": "Wykryto ruch",
  "Battery low": "Niski poziom baterii",
  "Device offline": "Urządzenie offline",
  "Device online": "Urządzenie online",
  "Cửa mở": "Drzwi otwarte",
  "Cửa đóng": "Drzwi zamknięte",
  "Chưa đặt vị trí nhà": "Nie ustawiono lokalizacji domu",
  "Đặt vị trí nhà tại đây": "Ustaw tutaj lokalizację domu",
  "Hãy đặt vị trí nhà trước khi bật tự động Bảo vệ":
      "Ustaw lokalizację domu przed włączeniem automatycznej ochrony",
  "Bán kính bảo vệ mặc định: 150 m": "Domyślny promień ochrony: 150 m",
  "Mỗi thành viên sẽ cần cấp quyền vị trí Luôn cho phép để trạng thái rời/đến nhà hoạt động khi ứng dụng chạy nền.":
      "Każdy członek musi zezwolić na dostęp do lokalizacji „Zawsze”, aby stan poza domem/w domu działał w tle.",
  "Lưu cài đặt": "Zapisz ustawienia",
  "Đã đặt vị trí nhà": "Ustawiono lokalizację domu",
  "Đang lấy vị trí...": "Pobieranie lokalizacji...",
  "Đang lưu...": "Zapisywanie...",
  "Đổi tên hiển thị": "Zmień nazwę wyświetlaną",
  "Cập nhật thông tin nhà": "Zaktualizuj informacje o domu",
  "Nhập địa chỉ của nhà": "Wprowadź adres domu",
  "Lưu thay đổi": "Zapisz zmiany",
  "Tên này chỉ hiển thị riêng trên tài khoản của bạn.":
      "Ta nazwa jest widoczna tylko na Twoim koncie.",
  "Tên và địa chỉ sẽ được cập nhật cho toàn bộ thành viên trong nhà.":
      "Nazwa i adres zostaną zaktualizowane dla wszystkich członków domu.",
  "Một thành viên": "Członek",
  "Đã cập nhật thông tin nhà": "Zaktualizowano informacje o domu",
  "Thay tên": "Zmień nazwę",
  "Đã đổi tên thiết bị": "Zmieniono nazwę urządzenia",
  "Chưa chọn nhà để kiểm tra": "Wybierz dom do testu",
  "Hãy thực hiện kiểm tra bằng tài khoản Owner":
      "Przeprowadź test z konta właściciela",
  "Không đọc được dữ liệu nhà": "Nie można odczytać danych domu",
  "Nhà cần có ít nhất một thiết bị để test":
      "Dom musi mieć co najmniej jedno urządzenie do przeprowadzenia testu",
  "Đóng": "Zamknij",
  "Đã thiết lập": "Skonfigurowano",
  "Quét QR": "Skanuj kod QR",
  "Quét QR để thêm thiết bị": "Zeskanuj kod QR, aby dodać urządzenie",
  "Nhập HUB ID thủ công": "Wprowadź identyfikator HUB ręcznie",
  "Bạn không có quyền sắp xếp phòng":
      "Nie masz uprawnień do zmiany kolejności pomieszczeń",
  "Cảnh báo khói": "Alarm dymu",
  "Cập nhật thiết bị": "Aktualizacja urządzenia",
  "Cửa đang mở": "Drzwi są otwarte",
  "Cửa đã đóng": "Drzwi są zamknięte",
  "Firebase Rules: CÓ LỖI": "Reguły Firebase: WYKRYTO BŁĘDY",
  "Firebase Rules: ĐẠT": "Reguły Firebase: ZALICZONE",
  "Giờ không hợp lệ": "Nieprawidłowa godzina",
  "Khôi phục mật khẩu": "Zresetuj hasło",
  "Nhập email của bạn": "Wprowadź swój adres e-mail",
  "Gửi": "Wyślij",
  "Đã gửi email khôi phục": "Wysłano wiadomość e-mail do resetowania hasła",
  "Không gửi được email": "Nie udało się wysłać wiadomości e-mail",
  "Vui lòng nhập email và mật khẩu": "Wprowadź adres e-mail i hasło",
  "Mật khẩu xác nhận không khớp": "Hasła nie są zgodne",
  "Không thể tạo tài khoản": "Nie udało się utworzyć konta",
  "Sai tài khoản": "Nieprawidłowe konto",
  "Email đã tồn tại": "Ten adres e-mail już istnieje",
  "Mật khẩu quá yếu": "Hasło jest zbyt słabe",
  "Sai email hoặc mật khẩu": "Nieprawidłowy adres e-mail lub hasło",
  "Lỗi đăng nhập": "Błąd logowania",
  "Email": "E-mail",
  "Mật khẩu": "Hasło",
  "Ghi nhớ tài khoản": "Zapamiętaj konto",
  "Đăng nhập": "Zaloguj się",
  "Đăng ký mới": "Utwórz konto",
  "Quên mật khẩu?": "Nie pamiętasz hasła?",
  "Chưa có tài khoản? Đăng ký": "Nie masz konta? Zarejestruj się",
  "Đã có tài khoản? Đăng nhập": "Masz już konto? Zaloguj się",
  "Tính năng đang được phát triển": "Ta funkcja jest w trakcie opracowywania",
  "Thông báo": "Powiadomienie",
  "Chat trong nhà": "Czat domowy",
  "Tìm kiếm tin nhắn": "Szukaj wiadomości",
  "Xem thành viên": "Wyświetl członków",
  "Tìm nội dung hoặc tên người gửi": "Szukaj treści lub nazwy nadawcy",
  "Xoá từ khoá": "Wyczyść słowo kluczowe",
  "Không có kết quả": "Brak wyników",
  "Tìm ngôn ngữ": "Szukaj języka",
  "Kết quả trước": "Poprzedni wynik",
  "Kết quả tiếp theo": "Następny wynik",
  "Chưa có tin nhắn": "Brak wiadomości",
  "Không tìm thấy thành viên phù hợp": "Nie znaleziono pasujących członków",
  "Nhắc đến trong tin nhắn": "Wspomnij w wiadomości",
  "Huỷ trả lời": "Anuluj odpowiedź",
  "Nhắn gì đó...": "Napisz wiadomość...",
  "Gọi điện": "Zadzwoń",
  "Báo động thiết bị": "Alarm urządzenia",
  "Chế độ áp dụng": "Tryb stosowania",
  "Theo nhà": "Harmonogram domu",
  "Riêng tôi": "Osobisty",
  "Dùng lịch chung do Chủ nhà hoặc Quản trị viên thiết lập":
      "Użyj wspólnego harmonogramu ustawionego przez właściciela lub administratora",
  "Dùng lịch riêng chỉ áp dụng cho tài khoản của bạn":
      "Użyj osobistego harmonogramu obowiązującego tylko na Twoim koncie",
  "Thiết lập nhanh báo động": "Szybka konfiguracja alarmu",
  "Thiết lập nhanh toàn bộ thiết bị": "Szybka konfiguracja wszystkich urządzeń",
  "Áp dụng cho toàn bộ thiết bị": "Zastosuj do wszystkich urządzeń",
  "Bắt đầu": "Początek",
  "Kết thúc": "Koniec",
  "Thời gian lặp lại": "Interwał powtarzania",
  "Không lặp lại": "Bez powtarzania",
  "Quét QR HUB": "Zeskanuj kod QR HUB-a",
  "Đưa mã QR vào giữa khung": "Umieść kod QR na środku ramki",
  "Đang áp dụng...": "Stosowanie...",
  "Hôm nay đã ghi nhận cảnh báo SOS": "Dzisiaj zarejestrowano alert SOS",
  "Hôm nay đã ghi nhận cảnh báo khói": "Dzisiaj zarejestrowano alarm dymu",
  "Khói đã an toàn": "Zagrożenie dymem ustąpiło",
  "Không tìm thấy nhà của thông báo này":
      "Nie znaleziono domu powiązanego z tym powiadomieniem",
  "Không tìm thấy thiết bị trong nhà này":
      "Nie znaleziono urządzenia w tym domu",
  "Một chủ nhà": "Właściciel domu",
  "Ngôi nhà đang hoạt động ổn định": "Dom działa prawidłowo",
  "Nhiệt độ cao": "Wysoka temperatura",
  "OK": "OK",
  "Pin yếu": "Niski poziom baterii",
  "SOS đã kết thúc": "Alarm SOS zakończony",
  "SOS được kích hoạt": "Aktywowano SOS",
  "Tamper bình thường": "Brak wykrytego sabotażu",
  "Thiết bị bị tháo": "Wykryto sabotaż urządzenia",
  "Thiết bị mới": "Nowe urządzenie",
  "Thiết bị offline": "Urządzenie offline",
  "Thiết bị online": "Urządzenie online",
  "Báo động kích hoạt": "Alarm uruchomiony",
  "Báo động đã tắt": "Alarm wyłączony",
  "Tạm tắt báo động hôm nay": "Tymczasowo wyłącz alarm na dziś",
  "Độ ẩm cao": "Wysoka wilgotność",
  "Thử lại": "Spróbuj ponownie",
  "Không thể tải dữ liệu tài khoản": "Nie można wczytać danych konta",
  "Không": "Nie",
  "Đã chia sẻ nhà thành công.": "Pomyślnie udostępniono domy.",
  "Tìm nhà...": "Szukaj domów...",
  "Đã rời khỏi nhà": "Opuszczono dom",
  "Bạn sẽ rời khỏi các nhà được chia sẻ.": "Opuścisz udostępnione domy.",
  "Các nhà của bạn sẽ bị xoá.\n": "Twoje domy zostaną usunięte.\n",
  "Thao tác này sẽ thay đổi lịch báo động của toàn bộ thiết bị an ninh trong các nhà đã chọn.\n\n":
      "Ta czynność zmieni harmonogram alarmu wszystkich urządzeń zabezpieczających w wybranych domach.\n\n",
  "Thao tác này sẽ thêm nhắc nhở cho các nhà đã chọn.\n\n":
      "Ta czynność doda przypomnienie dla wybranych domów.\n\n",
  "Xác nhận thay đổi báo động": "Potwierdź zmiany alarmu",
  "Xác nhận thay đổi nhắc nhở": "Potwierdź zmiany przypomnienia",
  "Lặp lại khi sự cố vẫn còn": "Powtarzaj, dopóki problem nie ustąpi",
  "Thời gian lặp lại báo động": "Interwał powtarzania alarmu",
  "VD: Mr Chung": "Np. pan Chung",
  "🏡 Chưa có nhà nào": "🏡 Brak domów",
  "Vẫn chuyển về Bình thường": "Mimo to przełącz na tryb Normalny",
  "Tự động Bảo vệ khi rời nhà vẫn đang bật. Nếu mọi thành viên vẫn ở ngoài, hệ thống có thể tự bật lại Bảo vệ sau vài phút.":
      "Automatyczna ochrona po wyjściu z domu jest nadal włączona. Jeśli wszyscy członkowie pozostają poza domem, system może po kilku minutach ponownie włączyć tryb ochrony.",
  "Chuyển về Bình thường?": "Przełączyć na tryb Normalny?",
  "Khi bật, các thiết bị an ninh sẽ được giám sát ngay.\n\n":
      "Po włączeniu urządzenia zabezpieczające będą natychmiast monitorowane.\n\n",
  "Bật Bảo vệ thủ công?": "Włączyć ręczny tryb ochrony?",
  "Hành động này sẽ thay đổi thời gian báo động của một số thiết bị ":
      "Ta czynność zmieni dziś czas alarmu niektórych urządzeń...",
  "Hành động này sẽ tắt toàn bộ báo động của nhà ":
      "Ta czynność wyłączy wszystkie alarmy w tym domu",
  "Tắt toàn bộ báo động?": "Wyłączyć wszystkie alarmy?",
  "Không xoá được lịch tạm tắt báo động":
      "Nie można usunąć harmonogramu wstrzymania alarmu",
  "Không lưu được tạm tắt báo động": "Nie można zapisać wstrzymania alarmu",
  "Không gửi được yêu cầu xoá": "Nie udało się wysłać prośby o usunięcie",
  "Không lưu được cài đặt": "Nie udało się zapisać ustawienia",
  "Không lấy được vị trí hiện tại": "Nie udało się pobrać bieżącej lokalizacji",
  "Không thể xác nhận tài khoản hiện tại":
      "Nie można zweryfikować bieżącego konta",
  "Mật khẩu không đúng": "Nieprawidłowe hasło",
  "Không thể xác nhận mật khẩu": "Nie można zweryfikować hasła",
  "Chỉ Chủ nhà hoặc Quản trị viên mới có quyền thay đổi lặp báo động":
      "Tylko właściciel lub administrator może zmienić ustawienie powtarzania alarmu",
  "Không lưu được thời gian lặp báo động":
      "Nie udało się zapisać interwału powtarzania alarmu",
  "Chỉ Chủ nhà hoặc Quản trị viên mới có quyền thay đổi Chế độ Bảo vệ":
      "Tylko właściciel lub administrator może zmienić tryb ochrony",
  "Không thể thay đổi chế độ nhà": "Nie udało się zmienić trybu domu",
  "Đã bật Bảo vệ nhưng chưa gửi được thông báo":
      "Tryb ochrony został włączony, ale nie udało się wysłać powiadomienia",
  "Đã bật Chế độ Bảo vệ thủ công": "Włączono ręczny tryb ochrony",
  "Đã chuyển nhà về Bình thường": "Dom przełączono z powrotem na tryb Normalny",
  "60 phút": "60 minut",
  "30 phút": "30 minut",
  "15 phút": "15 minut",
  "Bạn đang xem lịch của chủ nhà. Chọn Riêng tôi để tự đặt lịch báo động.":
      "Wyświetlasz harmonogram właściciela. Wybierz „Tylko dla mnie”, aby ustawić własny harmonogram alarmu.",
  "Chọn giờ kết thúc báo động": "Wybierz godzinę zakończenia alarmu",
  "Chọn giờ bắt đầu báo động": "Wybierz godzinę rozpoczęcia alarmu",
  "Bạn không có quyền sửa lịch báo động của nhà":
      "Nie masz uprawnień do edytowania harmonogramu alarmu tego domu",
  "Không thể áp dụng báo động cho toàn bộ thiết bị":
      "Nie udało się zastosować alarmu do wszystkich urządzeń",
  "Nhà chưa có thiết bị an ninh để áp dụng":
      "W tym domu nie ma urządzeń zabezpieczających, do których można zastosować ustawienie",
  "Bạn không có quyền sửa lịch Theo nhà. Hãy chọn Riêng tôi.":
      "Nie masz uprawnień do edytowania harmonogramu domu. Wybierz „Tylko dla mnie”.",
  "Không thể lưu chế độ báo động": "Nie udało się zapisać trybu alarmu",
  "Thêm nhắc nhở": "Dodaj przypomnienie",
  "Nhắc nhở sẽ nhắc bạn kiểm tra trạng thái an toàn của ngôi nhà vào giờ đã chọn.":
      "Przypomnienie poinformuje Cię o konieczności sprawdzenia bezpieczeństwa domu o wybranej godzinie.",
  "Thêm khung giờ báo động": "Dodaj przedział czasowy alarmu",
  "Đang sử dụng nhắc nhở riêng của bạn":
      "Używasz własnych ustawień przypomnień",
  "Đang sử dụng nhắc nhở của chủ nhà":
      "Używasz ustawień przypomnień właściciela",
  "Sửa giờ nhắc nhở": "Edytuj godzinę przypomnienia",
  "Sửa giờ kết thúc báo động": "Edytuj godzinę zakończenia alarmu",
  "Sửa giờ bắt đầu báo động": "Edytuj godzinę rozpoczęcia alarmu",
  "Xoá nhắc nhở": "Usuń przypomnienie",
  "Mỗi 1 giờ": "Co godzinę",
  "Mỗi 30 phút": "Co 30 minut",
  "Mỗi 15 phút": "Co 15 minut",
  "Không báo lại": "Nie powtarzaj",
  "Báo lại khi vẫn chưa an toàn": "Powtarzaj, dopóki nadal jest niebezpiecznie",
  "Báo lại mỗi 1 giờ": "Powtarzaj co godzinę",
  "Báo lại mỗi 30 phút": "Powtarzaj co 30 minut",
  "Báo lại mỗi 15 phút": "Powtarzaj co 15 minut",
  "Quản lý nhà": "Zarządzanie domem",
  "Xoá thành viên": "Usuń członka",
  "Đã xoá thành viên": "Usunięto członka",
  "Đồng ý": "OK",
  "Bạn chắc chắn muốn rời khỏi nhà này?":
      "Czy na pewno chcesz opuścić ten dom?",
  "Xoá thành viên?": "Usunąć członka?",
  "Rời khỏi nhà?": "Opuścić ten dom?",
  "Chỉ chủ nhà mới được thay đổi vai trò":
      "Tylko właściciel może zmieniać role",
  "Bạn không có quyền xoá thành viên này":
      "Nie masz uprawnień do usunięcia tego członka",
  "Bạn": "Ty",
  "Không có email": "Brak adresu e-mail",
  "Chưa có số điện thoại": "Brak numeru telefonu",
  "Không mở được ứng dụng gọi điện": "Nie udało się otworzyć aplikacji Telefon",
  "Thành viên chưa cập nhật số điện thoại":
      "Ten członek nie dodał numeru telefonu",
  "Bảo vệ thủ công đang bật - chỉ tắt khi chuyển về Bình thường":
      "Ręczny tryb ochrony jest włączony — aby go wyłączyć, przełącz na tryb Normalny",
  "Thời gian lặp": "Interwał powtarzania",
  "Chọn 0 để chỉ báo một lần. Cài đặt này dùng cho cả Bảo vệ thủ công và Tự động Bảo vệ khi rời nhà.":
      "Wybierz 0, aby powiadomić tylko raz. To ustawienie dotyczy ręcznego trybu ochrony i automatycznej ochrony po wyjściu z domu.",
  "Lặp báo động khi sự cố vẫn còn":
      "Powtarzaj alarm, dopóki problem nie ustąpi",
  "Đang được sử dụng": "Obecnie aktywne",
  "Chuyển về sử dụng thông thường": "Przełącz z powrotem na normalne użycie",
  "Chế độ nhà": "Tryb domu",
  "Thiết bị SOS chưa ghi nhận cảnh báo.":
      "Urządzenie SOS nie zarejestrowało alarmu.",
  "Cảm biến khói chưa ghi nhận bất thường.":
      "Czujnik dymu nie wykrył nieprawidłowości.",
  "Bạn hoặc thành viên đã chủ động bật Bảo vệ.":
      "Ty lub inny członek ręcznie włączyliście tryb ochrony.",
  "SafeHome tự bật Bảo vệ vì bạn đã rời khỏi nhà.":
      "SafeHome automatycznie włączył tryb ochrony, ponieważ opuściłeś dom.",
  "Nhà đang ở chế độ dùng bình thường.":
      "Dom jest obecnie używany w trybie normalnym.",
  "Bảo vệ thủ công đang bật": "Ręczny tryb ochrony jest włączony",
  "Bảo vệ tự động đang bật": "Automatyczny tryb ochrony jest włączony",
  "Bảo vệ đang tắt": "Tryb ochrony jest wyłączony",
  "Bạn đã mở ứng dụng gần đây để kiểm tra trạng thái.":
      "Niedawno otworzyłeś aplikację, aby sprawdzić stan.",
  "Bạn nên mở ứng dụng định kỳ để kiểm tra quyền, lịch và cảnh báo chưa đọc.":
      "Otwieraj aplikację regularnie, aby sprawdzać uprawnienia, harmonogramy i nieprzeczytane alerty.",
  "Sau vài lần sử dụng, SafeHome sẽ đánh giá thói quen kiểm tra ứng dụng tốt hơn.":
      "Po kilku użyciach SafeHome będzie lepiej oceniać Twój zwyczaj sprawdzania aplikacji.",
  "Tần suất vào ứng dụng ổn":
      "Częstotliwość sprawdzania aplikacji jest odpowiednia",
  "Đã lâu chưa vào ứng dụng kiểm tra":
      "Od ostatniego sprawdzenia aplikacji minęło dużo czasu",
  "Đang ghi nhận tần suất vào ứng dụng":
      "Trwa rejestrowanie częstotliwości sprawdzania aplikacji",
  "Cần kiểm tra quyền vị trí luôn luôn và điều kiện chạy nền.":
      "Sprawdź uprawnienie do lokalizacji „Zawsze” i warunki działania w tle.",
  "Thiết bị đủ điều kiện để Auto rời khỏi nhà hoạt động.":
      "To urządzenie spełnia wymagania automatycznej ochrony po wyjściu z domu.",
  "Bạn có thể bật khi muốn tự động chuyển Bảo vệ lúc rời nhà.":
      "Włącz tę funkcję, jeśli chcesz, aby tryb ochrony uruchamiał się automatycznie po wyjściu z domu.",
  "Auto rời khỏi nhà chưa ổn":
      "Automatyczna ochrona po wyjściu z domu nie jest gotowa",
  "Auto rời khỏi nhà đã sẵn sàng":
      "Automatyczna ochrona po wyjściu z domu jest gotowa",
  "Auto rời khỏi nhà chưa bật":
      "Automatyczna ochrona po wyjściu z domu nie jest włączona",
  "Nên thêm báo khói, SOS hoặc thiết bị khẩn cấp phù hợp với nhà.":
      "Dodaj czujnik dymu, przycisk SOS lub inne urządzenie awaryjne odpowiednie dla domu.",
  "Chưa có thiết bị khẩn cấp": "Brak urządzeń awaryjnych",
  "Đã có thiết bị khẩn cấp": "Dodano urządzenia awaryjne",
  "Nên đặt lịch báo động cho thời gian ngủ hoặc vắng nhà.":
      "Ustaw harmonogram alarmu na czas snu lub nieobecności.",
  "Nhà đã có lịch báo động hoặc lịch cảnh báo theo thiết bị.":
      "Ten dom ma harmonogram alarmu lub alerty ustawione dla poszczególnych urządzeń.",
  "Chưa cài lịch báo động": "Nie ustawiono harmonogramu alarmu",
  "Đã cài lịch báo động": "Ustawiono harmonogram alarmu",
  "Nên có ít nhất một nhắc nhở để không quên kiểm tra nhà.":
      "Ustaw co najmniej jedno przypomnienie, aby nie zapomnieć sprawdzić domu.",
  "Ứng dụng sẽ nhắc bạn kiểm tra nhà theo lịch đã đặt.":
      "Aplikacja przypomni Ci o sprawdzeniu domu zgodnie z ustawionym harmonogramem.",
  "Chưa cài đặt nhắc nhở": "Nie skonfigurowano przypomnienia",
  "Đã cài đặt nhắc nhở": "Skonfigurowano przypomnienie",
  "Hãy mở lại ứng dụng hoặc đăng nhập lại nếu thiết bị không nhận cảnh báo.":
      "Jeśli urządzenie nie otrzymuje alertów, ponownie otwórz aplikację lub zaloguj się ponownie.",
  "Thiết bị chưa đăng ký nhận cảnh báo":
      "To urządzenie nie jest zarejestrowane do odbierania alertów",
  "Thiết bị nhận cảnh báo bình thường":
      "Urządzenie może prawidłowo odbierać alerty",
  "iOS quản lý chạy nền chặt hơn Android; hãy giữ thông báo và vị trí luôn luôn nếu dùng Auto rời khỏi nhà.":
      "iOS ogranicza działanie w tle bardziej niż Android; podczas korzystania z automatycznej ochrony po wyjściu z domu pozostaw włączone powiadomienia i dostęp do lokalizacji „Zawsze”.",
  "Cơ chế iOS": "Działanie w iOS",
  "Hãy kiểm tra quyền chạy nền và tự khởi động để cảnh báo không bị trễ.":
      "Sprawdź uprawnienia do działania w tle i automatycznego uruchamiania, aby alerty nie były opóźniane.",
  "Thiết bị đã xác nhận các điều kiện chạy nền quan trọng.":
      "Urządzenie potwierdziło najważniejsze warunki działania w tle.",
  "Cần kiểm tra chạy nền / tự khởi động":
      "Sprawdź działanie w tle / automatyczne uruchamianie",
  "Chạy nền ổn định": "Działanie w tle jest stabilne",
  "Một số máy Android có thể trì hoãn cảnh báo nếu tối ưu pin còn bật.":
      "Niektóre telefony z Androidem mogą opóźniać alerty, gdy optymalizacja baterii jest włączona.",
  "Điện thoại ít có khả năng trì hoãn cảnh báo SafeHome.":
      "Telefon raczej nie będzie opóźniał alertów SafeHome.",
  "Chưa tắt tối ưu pin": "Optymalizacja baterii jest nadal włączona",
  "Tối ưu pin không chặn ứng dụng":
      "Optymalizacja baterii nie blokuje aplikacji",
  "Auto rời khỏi nhà cần quyền vị trí luôn luôn để chạy ổn định.":
      "Automatyczna ochrona po wyjściu z domu wymaga dostępu do lokalizacji „Zawsze”, aby działać niezawodnie.",
  "Cần cấp quyền vị trí để Auto rời khỏi nhà hoạt động.":
      "Do działania automatycznej ochrony po wyjściu z domu wymagane jest uprawnienie do lokalizacji.",
  "Dịch vụ vị trí đang tắt nên Auto rời khỏi nhà không ổn định.":
      "Usługi lokalizacji są wyłączone, więc automatyczna ochrona po wyjściu z domu może działać niestabilnie.",
  "Chỉ cần quyền này khi dùng Auto rời khỏi nhà.":
      "To uprawnienie jest potrzebne tylko podczas korzystania z automatycznej ochrony po wyjściu z domu.",
  "Chưa cấp vị trí luôn luôn": "Brak dostępu do lokalizacji „Zawsze”",
  "Đã cấp vị trí luôn luôn": "Przyznano dostęp do lokalizacji „Zawsze”",
  "iOS không mở toàn màn hình như Android; ứng dụng dùng thông báo và âm thanh hệ thống.":
      "iOS nie otwiera alertów na pełnym ekranie jak Android; aplikacja korzysta z powiadomień i dźwięków systemowych.",
  "Android dùng cảnh báo toàn màn hình; nếu máy chặn, hãy cấp quyền trong cài đặt.":
      "Android używa alertów pełnoekranowych; jeśli telefon je blokuje, nadaj uprawnienie w ustawieniach.",
  "Cảnh báo trên iOS": "Alerty w iOS",
  "Cảnh báo toàn màn hình": "Alerty pełnoekranowe",
  "Cảnh báo có thể không hiển thị nếu thông báo bị tắt.":
      "Alerty mogą się nie wyświetlać, jeśli powiadomienia są wyłączone.",
  "Điện thoại có thể nhận thông báo SafeHome.":
      "Ten telefon może odbierać powiadomienia SafeHome.",
  "Chưa bật thông báo": "Powiadomienia nie są włączone",
  "Đã bật thông báo": "Powiadomienia są włączone",
  "Hệ thống: Sẵn sàng": "System: gotowy",
  "Hệ thống: Có thể bỏ lỡ cảnh báo": "System: alerty mogą zostać pominięte",
  "Cách bạn đang dùng ứng dụng": "Jak korzystasz z aplikacji",
  "Thiết bị của bạn": "Twoje urządzenie",
  "Kiểm tra điện thoại và cách bạn đang dùng ứng dụng.":
      "Sprawdza telefon i sposób korzystania z aplikacji.",
  "Hệ thống SafeHome": "System SafeHome",
  "Hệ thống: Đang kiểm tra...": "System: sprawdzanie...",
  "Tên": "Nazwa",
  "Bạn không có quyền thay đổi vị trí nhà":
      "Nie masz uprawnień do zmiany lokalizacji domu",
  "Hãy bật GPS để đặt vị trí nhà": "Włącz GPS, aby ustawić lokalizację domu",
  "Bạn chưa cấp quyền vị trí": "Nie przyznano uprawnienia do lokalizacji",
  "Hãy cấp quyền vị trí trong Cài đặt ứng dụng":
      "Przyznaj uprawnienie do lokalizacji w ustawieniach aplikacji",
  "Đã bật tự động Bảo vệ khi mọi người rời nhà":
      "Włączono automatyczną ochronę, gdy wszyscy opuszczą dom",
  "Đã tắt tự động Bảo vệ khi mọi người rời nhà":
      "Wyłączono automatyczną ochronę, gdy wszyscy opuszczą dom",
  "Không thể thay đổi trạng thái báo động":
      "Nie udało się zmienić stanu alarmu",
  "Đã tắt toàn bộ báo động của nhà": "Wyłączono wszystkie alarmy w domu",
  "QR này không phải mã xin gia nhập Home":
      "Ten kod QR nie służy do dołączania do domu",
  "Thêm Home": "Dodaj dom",
  "Mở cài đặt": "Otwórz ustawienia",
  "Để sau": "Później",
  "SafeHome cần quyền vị trí \"Luôn cho phép\" để nhận biết khi bạn rời hoặc trở về nhà, kể cả khi ứng dụng đang chạy nền.":
      "SafeHome potrzebuje dostępu do lokalizacji „Zawsze”, aby wykrywać wyjście z domu i powrót, także gdy aplikacja działa w tle.",
  "SafeHome hiện chỉ được truy cập vị trí khi bạn đang sử dụng ứng dụng.\n\nHãy chọn quyền Vị trí và chuyển sang \"Luôn cho phép\" để tính năng tự động Bảo vệ khi rời nhà hoạt động khi ứng dụng đang chạy nền.":
      "SafeHome ma obecnie dostęp do lokalizacji tylko podczas używania aplikacji.\n\nOtwórz uprawnienie Lokalizacja i wybierz „Zezwalaj zawsze”, aby automatyczna ochrona po wyjściu z domu działała również w tle.",
  "Cho phép vị trí luôn luôn": "Zawsze zezwalaj na dostęp do lokalizacji",
  "Các nhà của bạn sẽ bị xoá.\nCác nhà được chia sẻ sẽ được rời khỏi.":
      "Twoje domy zostaną usunięte.\nOpuścisz udostępnione domy.",
  "Thao tác này sẽ thay đổi lịch báo động của toàn bộ thiết bị an ninh trong các nhà đã chọn.\n\nNhững thành viên đang sử dụng báo động 'Theo nhà' sẽ bị ảnh hưởng.\nBáo động cá nhân ở chế độ 'Riêng tôi' sẽ không bị thay đổi.":
      "Ta czynność zmieni harmonogramy alarmów wszystkich urządzeń zabezpieczających w wybranych domach.\n\nWpłynie to na członków korzystających z ustawień alarmu domu.\nOsobiste ustawienia alarmu nie zostaną zmienione.",
  "Thao tác này sẽ thêm nhắc nhở cho các nhà đã chọn.\n\nNhững thành viên đang sử dụng nhắc nhở 'Theo nhà' sẽ bị ảnh hưởng.\nNhắc nhở cá nhân ở chế độ 'Riêng tôi' sẽ không bị thay đổi.":
      "Ta czynność doda przypomnienie dla wybranych domów.\n\nWpłynie to na członków korzystających z ustawień przypomnień domu.\nOsobiste ustawienia przypomnień nie zostaną zmienione.",
  "Khi bật, các thiết bị an ninh sẽ được giám sát ngay.\n\nTự động Bảo vệ khi rời nhà sẽ tạm dừng. Chế độ này không tự tắt khi có người về nhà và chỉ được tắt khi một thành viên có quyền chủ động chuyển về Bình thường.":
      "Po włączeniu urządzenia zabezpieczające będą natychmiast monitorowane.\n\nAutomatyczna ochrona po wyjściu z domu zostanie wstrzymana. Ten tryb nie wyłączy się automatycznie po czyimś powrocie i może go wyłączyć tylko uprawniony członek, przełączając dom na tryb Normalny.",
  "Hành động này sẽ thay đổi thời gian báo động của một số thiết bị trong hôm nay...":
      "Ta czynność zmieni dziś czas alarmu niektórych urządzeń...",
  "Hành động này sẽ tắt toàn bộ báo động của nhà dưới mọi hình thức. Bạn sẽ không còn nhận được cảnh báo khi có nguy hiểm trên điện thoại nữa.":
      "Ta czynność wyłączy wszystkie alarmy tego domu niezależnie od trybu. Nie będziesz już otrzymywać alertów o zagrożeniu na telefonie.",
  "Báo động đang sử dụng chế độ Theo nhà.\n\nBạn sẽ nhận cảnh báo theo lịch báo động chung do Chủ nhà hoặc Quản trị viên thiết lập.":
      "Alarm korzysta z ustawień domu.\n\nBędziesz otrzymywać alerty zgodnie ze wspólnymi harmonogramami ustawionymi przez właściciela lub administratora.",
  "Báo động đang sử dụng chế độ Riêng tôi.\n\nBạn sẽ nhận cảnh báo theo lịch báo động riêng đã thiết lập cho tài khoản này.":
      "Alarm korzysta z ustawień osobistych.\n\nBędziesz otrzymywać alerty zgodnie z osobistymi harmonogramami alarmu ustawionymi dla tego konta.",
  "Không thể đăng nhập bằng Google": "Nie udało się zalogować przez Google",
  "Không đặt được mật khẩu": "Nie udało się ustawić hasła",
  "Chấp nhận": "Akceptuj",
  "Cho phép": "Zezwól",
  "Không thể chấp nhận lời mời. Vui lòng thử lại.":
      "Nie udało się zaakceptować zaproszenia. Spróbuj ponownie.",
  "Không thể chấp nhận lời xin vào nhà. Vui lòng thử lại.":
      "Nie udało się zaakceptować prośby o dołączenie do domu. Spróbuj ponownie.",
  "Từ chối": "Odrzuć",
  "Lời mời từ chủ nhà": "Zaproszenie od właściciela",
  "Nhận quyền chủ nhà": "Przejmij własność domu",
  "Một người dùng SafeHome": "Użytkownik SafeHome",
  "Lời mời gia nhập": "Zaproszenie do dołączenia",
  "Lời xin vào nhà": "Prośba o dołączenie do domu",
  "Nhập HUB ID": "Wprowadź identyfikator HUB",
  "VD: HUB_001": "Np.: HUB_001",
  "Pair": "Sparuj",
  "Mật khẩu tối thiểu 6 ký tự": "Hasło musi mieć co najmniej 6 znaków",
  "Mật khẩu nhập lại không khớp": "Hasła nie są zgodne",
  "Tạo mật khẩu": "Utwórz hasło",
  "Mật khẩu mới": "Nowe hasło",
  "Nhập lại mật khẩu": "Wprowadź hasło ponownie",
  "Xác nhận tắt cảnh báo": "Potwierdź wyłączenie alertu",
  "HỦY": "ANULUJ",
  "XÁC NHẬN": "POTWIERDŹ",
  "CẦN KIỂM TRA": "WYMAGA SPRAWDZENIA",
  "KIỂM TRA NHÀ": "SPRAWDŹ DOM",
  "ĐÓNG NHẮC NHỞ": "ZAMKNIJ PRZYPOMNIENIE",
  "SafeHome Security Alert": "Alert bezpieczeństwa SafeHome",
  "Hãy chọn quyền vị trí Luôn cho phép trong Cài đặt ứng dụng":
      "Wybierz dostęp do lokalizacji „Zawsze” w ustawieniach aplikacji",
  "Tài khoản Google cần tạo thêm mật khẩu để dùng các chức năng bảo mật.":
      "Aby korzystać z funkcji zabezpieczeń, konto Google wymaga dodatkowego hasła.",
  "Báo động": "Alarm",
  "Bạn không có quyền thực hiện thao tác này。":
      "Nie masz uprawnień do wykonania tej czynności.",
  "Cài đặt": "Ustawienia",
  "Cập nhật": "Aktualizuj",
  "Chọn ngôn ngữ": "Wybierz język",
  "Chưa có dữ liệu thiết bị để đánh giá": "Brak danych urządzenia do oceny",
  "Chuyển quyền sở hữu cho thành viên khác":
      "Przenieś własność na innego członka",
  "Có": "Tak",
  "Cửa đã đóng an toàn": "Drzwi bezpiecznie zamknięte",
  "Đã xảy ra lỗi. Vui lòng thử lại.": "Wystąpił błąd. Spróbuj ponownie.",
  "Đang kiểm tra kết nối Hub": "Sprawdzanie połączenia z hubem",
  "Đang mở khi nhà ở chế độ Bảo vệ": "Otwarte, gdy dom jest w trybie ochrony",
  "Đang mở trong giờ báo động": "Otwarte w godzinach alarmu",
  "Đang tải...": "Wczytywanie...",
  "Hồ sơ, yêu cầu và lời mời tham gia": "Profil, prośby i zaproszenia",
  "Hub chưa gửi trạng thái": "Brak stanu huba",
  "Hub mất kết nối": "Hub rozłączony",
  "Hub tín hiệu bình thường": "Hub połączony",
  "Khóa đang mở khi nhà ở chế độ Bảo vệ":
      "Zamek odblokowany, gdy dom jest w trybie ochrony",
  "Khóa đang mở trong giờ báo động": "Zamek odblokowany w godzinach alarmu",
  "Không có thông báo": "Brak powiadomień",
  "Khu vực nguy hiểm": "Strefa zagrożenia",
  "Kiểm tra thiết bị trong nhà này": "Sprawdź urządzenia w tym domu",
  "Mất điện lưới": "Brak zasilania sieciowego",
  "Mời người khác tham gia nhà này": "Zaproś kogoś do tego domu",
  "Môi trường hiện tại": "Bieżące warunki",
  "MQTT mất kết nối": "MQTT rozłączony",
  "Ngôn ngữ": "Język",
  "Nhà đã chia sẻ": "Udostępniony dom",
  "Nhà đang hoạt động bình thường": "Dom działa prawidłowo",
  "Nhập email": "Wprowadź adres e-mail",
  "Phòng": "Pomieszczenie",
  "Quản trị viên": "Administrator",
  "Nhắc nhở": "Przypomnienie",
  "SafeHome": "SafeHome",
  "Sóng yếu": "Słaby sygnał",
  "SOS": "SOS",
  "Tài khoản & hệ thống": "Konto i system",
  "Tài khoản cá nhân": "Konto osobiste",
  "Tạo tài khoản": "Utwórz konto",
  "Thành viên": "Członek",
  "Thành viên trong nhà": "Członkowie domu",
  "Thành viên đang ở trong nhà": "Członkowie obecni w domu",
  "Thành viên đang ở ngoài": "Członkowie poza domem",
  "Thành viên chưa xác định vị trí": "Członkowie o nieznanej lokalizacji",
  "Thay đổi ngôn ngữ hiển thị": "Zmień język wyświetlania",
  "Thêm, đổi tên và sắp xếp phòng":
      "Dodawaj, zmieniaj nazwy i kolejność pomieszczeń",
  "Thiết bị đang được giám sát": "Urządzenie jest monitorowane",
  "Tiếng Anh": "Angielski",
  "Tiếng Hàn": "Koreański",
  "Tiếng Nhật": "Japoński",
  "Tiếng Trung": "Chiński",
  "Tiếng Việt": "Wietnamski",
  "Toàn bộ thiết bị": "Wszystkie urządzenia",
  "Vai trò": "Rola",
  "Về nhà": "W domu",
  "Xem và quản lý quyền thành viên":
      "Wyświetlaj role członków i zarządzaj nimi",
  "Xóa": "Usuń",
  "Xóa nhà": "Usuń dom",
  "Xoá toàn bộ dữ liệu và thiết bị": "Usuń wszystkie dane i urządzenia",
  "TẮT CẢNH BÁO": "WYŁĄCZ ALERT",
  "Đã tạo nhà": "Utworzono dom",
  "Chế độ Bảo vệ thủ công đã bật": "Włączono ręczny tryb ochrony",
  "Báo động không lặp lại.": "Alarm nie będzie powtarzany.",
  "Báo động lặp sau \$securityModeRepeatMinutes phút nếu sự cố vẫn còn.":
      "Alarm zostanie powtórzony po \$securityModeRepeatMinutes minutach, jeśli problem nadal będzie występować.",
  "\$actorName đã bật Chế độ Bảo vệ thủ công cho \"\$homeName\". Chế độ này chỉ tắt khi một thành viên có quyền chủ động chuyển về Bình thường. \$repeatMessage":
      "Ręczny tryb ochrony dla „\$homeName” został włączony przez: \$actorName. Ten tryb wyłączy się dopiero, gdy uprawniony członek ręcznie przełączy dom na tryb Normalny. \$repeatMessage",
  "Bạn đã bật báo động cho nhà \"\$homeName\".":
      "Włączono alarm dla domu „\$homeName”.",
  "Bạn đã tắt toàn bộ báo động của nhà \"\$homeName\".":
      "Wyłączono wszystkie alarmy domu „\$homeName”.",
  "Thành viên mới": "Nowy członek",
  "Thành viên rời nhà": "Członek opuścił dom",
  "\$displayMemberName đã rời khỏi nhà \"\$homeName\".":
      "Odnotowano wyjście użytkownika \$displayMemberName z domu „\$homeName”.",
  "\$actorName đã đổi vai trò của \$memberName từ \$oldRoleName thành \$newRoleName trong nhà \"\$homeName\".":
      "Rola użytkownika \$memberName w domu „\$homeName” została zmieniona przez \$actorName z \$oldRoleName na \$newRoleName.",
  "Còn \$count tin nhắn chưa đọc": "\$count nieprzeczytanych wiadomości",
  "Hãy an tâm nghỉ ngơi.": "Możesz spokojnie odpocząć.",
  "Có thiết bị chưa an toàn.": "Niektóre urządzenia nie są bezpieczne.",
  "SafeHome đang cập nhật vị trí": "SafeHome aktualizuje lokalizację",
  "Đang theo dõi để tự động bật Chế độ Bảo vệ.":
      "Monitorowanie w celu automatycznego włączenia trybu ochrony.",
  "Dùng vị trí để tự động bật Chế độ Bảo vệ khi mọi người rời nhà.":
      "Lokalizacja służy do automatycznego włączenia trybu ochrony, gdy wszyscy opuszczą dom.",
  "CẢNH BÁO SOS": "ALERT SOS",
  "CẢNH BÁO KHÓI / CHÁY": "ALERT DYMU / POŻARU",
  "CẢNH BÁO NGẬP NƯỚC": "ALERT ZALANIA",
  "CẢNH BÁO RÒ KHÍ": "ALERT WYCIEKU GAZU",
  "CẢNH BÁO CỬA": "ALERT DRZWI",
  "CẢNH BÁO AN NINH": "ALERT BEZPIECZEŃSTWA",
  "Không thể xác nhận với SafeHome. Hãy kiểm tra kết nối và thử lại.":
      "Nie można potwierdzić w SafeHome. Sprawdź połączenie i spróbuj ponownie.",
  "Chỉ tắt cảnh báo khi bạn đã kiểm tra tình trạng trong nhà.\n\nBạn chắc chắn muốn tắt cảnh báo?":
      "Wyłącz alert dopiero po sprawdzeniu sytuacji w domu.\n\nCzy na pewno chcesz wyłączyć alert?",
  "🚨 SafeHome phát hiện cảnh báo": "🚨 SafeHome wykrył alert",
  "Mở SafeHome để kiểm tra ngay.": "Otwórz SafeHome i sprawdź teraz.",
  "\$count tin nhắn mới": "\$count nowych wiadomości",
  "Tin nhắn HomeChat": "Wiadomość HomeChat",
  "\$senderName đã gửi một tin nhắn": "Nowa wiadomość od: \$senderName",
  "Bạn có tin nhắn mới": "Masz nową wiadomość",
  "Chế độ Bảo vệ sẽ chỉ báo động một lần": "Tryb ochrony wyśle alert tylko raz",
  "Chế độ Bảo vệ sẽ lặp báo động sau \$minutes phút":
      "Tryb ochrony powtórzy alert po \$minutes minutach",
  "Đã gửi yêu cầu gia nhập \$count nhà":
      "Wysłano prośby o dołączenie do \$count domów",
  "\$requesterName đang xin gia nhập nhà \"\$homeName\".":
      "\$requesterName prosi o dołączenie do „\$homeName”.",
  "Bạn đã xoá nhà \"\$homeName\".": "Usunięto dom „\$homeName”.",
  "Bạn đã gửi yêu cầu chuyển quyền chủ nhà \"\$homeName\" cho \$email.":
      "Wysłano do \$email prośbę o przeniesienie własności domu „\$homeName”.",
  "\$actorName muốn chuyển quyền chủ nhà \"\$homeName\" cho bạn.":
      "\$actorName chce przenieść na Ciebie własność domu „\$homeName”.",
  "\$actorName đã mời bạn tham gia nhà \"\$homeName\".":
      "\$actorName zaprasza Cię do domu „\$homeName”.",
  "SafeHome đang xoá thiết bị \"\$deviceName\" khỏi nhà \"\$homeName\".":
      "SafeHome usuwa urządzenie „\$deviceName” z domu „\$homeName”.",
  "Thiết bị \"\$deviceName\" đã xuất hiện trong \"\$homeName\".":
      "Urządzenie „\$deviceName” pojawiło się w domu „\$homeName”.",
  "Bạn đã tạo nhà \"\$name\".": "Utworzono dom „\$name”.",
  "\$actorName đã cập nhật tên nhà thành \"\$newName\" và thay đổi địa chỉ.":
      "Nazwa domu została zaktualizowana przez \$actorName na „\$newName”, a adres został zmieniony.",
  "\$actorName đã đổi tên nhà thành \"\$newName\".":
      "Nazwa domu została zmieniona przez \$actorName na „\$newName”.",
  "\$actorName đã cập nhật địa chỉ của nhà \"\$newName\".":
      "Adres domu „\$newName” został zaktualizowany przez \$actorName.",
  "\$actorName đã đổi tên thiết bị \"\$oldDeviceName\" thành \"\$newName\" trong nhà \"\$homeName\".":
      "Nazwa urządzenia „\$oldDeviceName” w domu „\$homeName” została zmieniona przez \$actorName na „\$newName”.",
  "Đang ghép nối: \$seconds giây": "Parowanie: \$seconds s",
  "Chế độ thêm thiết bị đã được mở trong nhà \"\$homeName\" trong \$seconds giây.":
      "Parowanie urządzeń w domu „\$homeName” zostało włączone na \$seconds sekund.",
  "Khoảng thời gian phải nằm trong khung báo động (\$start → \$end)":
      "Okres przerwy musi mieścić się w harmonogramie alarmu (\$start → \$end)",
  "\$passCount/\$total bài test đạt\n\n":
      "\$passCount/\$total testów zakończonych pomyślnie\n\n",
  "\$name chưa cập nhật số điện thoại trong hồ sơ.":
      "W profilu użytkownika \$name nie ma numeru telefonu.",
  "Tin nhắn mới trong \$homeName": "Nowa wiadomość w \$homeName",
  "\$current/\$total kết quả": "\$current/\$total wyników",
  "Đang trả lời \$name": "Odpowiedź do: \$name",
  "\"\$name\" phát hiện khói trong \"\$homeName\".":
      "Urządzenie „\$name” wykryło dym w „\$homeName”.",
  "\"\$name\" đã trở lại trạng thái bình thường.":
      "Urządzenie „\$name” wróciło do stanu normalnego.",
  "\"\$name\" vừa kích hoạt SOS trong \"\$homeName\".":
      "Urządzenie „\$name” właśnie uruchomiło SOS w „\$homeName”.",
  "\"\$name\" đã hết trạng thái SOS.":
      "Stan SOS urządzenia „\$name” zakończył się.",
  "\"\$name\" báo bị tháo/cạy trong \"\$homeName\".":
      "Urządzenie „\$name” zgłosiło sabotaż w „\$homeName”.",
  "\"\$name\" đã hết cảnh báo tháo/cạy.":
      "Alert sabotażowy urządzenia „\$name” zakończył się.",
  "\"\$name\" đã đóng trong \"\$homeName\".":
      "Urządzenie „\$name” zostało zamknięte w „\$homeName”.",
  "\"\$name\" đang mở trong \"\$homeName\".":
      "Urządzenie „\$name” jest otwarte w „\$homeName”.",
  "\"\$name\" trong \"\$homeName\" đang yếu pin.":
      "Urządzenie „\$name” w „\$homeName” ma niski poziom baterii.",
  "\"\$name\" trong \"\$homeName\" đã mất kết nối.":
      "Urządzenie „\$name” w „\$homeName” utraciło połączenie.",
  "\"\$name\" trong \"\$homeName\" đã kết nối trở lại.":
      "Urządzenie „\$name” w „\$homeName” ponownie jest online.",
  "\"\$name\" ghi nhận nhiệt độ cao trong \"\$homeName\".":
      "Urządzenie „\$name” zarejestrowało wysoką temperaturę w „\$homeName”.",
  "\"\$name\" ghi nhận độ ẩm cao trong \"\$homeName\".":
      "Urządzenie „\$name” zarejestrowało wysoką wilgotność w „\$homeName”.",
  "Có nút SOS vừa được kích hoạt": "Uruchomiono przycisk SOS",
  "Có dấu hiệu khói hoặc cháy": "Wykryto dym lub pożar",
  "Có dấu hiệu ngập nước": "Wykryto zalanie",
  "Có dấu hiệu rò khí": "Wykryto wyciek gazu",
  "Có cửa đang mở hoặc thiết bị bị tháo":
      "Drzwi są otwarte lub wykryto sabotaż urządzenia",
  "Có thiết bị đang cảnh báo": "Urządzenie zgłasza alert",
  "Nếu chưa có ai xác nhận, SafeHome sẽ chuyển sang gọi điện khẩn cấp.":
      "Jeśli nikt nie potwierdzi, SafeHome rozpocznie połączenie alarmowe.",
  "Báo lại lúc \$time nếu vấn đề chưa được xử lý.":
      "Alert zostanie powtórzony o \$time, jeśli problem nie zostanie rozwiązany.",
  "Sẽ báo lại theo lịch báo động đã cài nếu vấn đề chưa được xử lý.":
      "Alert zostanie powtórzony zgodnie z harmonogramem alarmu, jeśli problem nie zostanie rozwiązany.",
  "\"\$deviceName\" đã đóng trong \"\$resolvedHomeName\".":
      "„\$deviceName” zostało zamknięte w „\$resolvedHomeName”.",
  "\"\$deviceName\" đang mở trong \"\$resolvedHomeName\".":
      "„\$deviceName” jest otwarte w „\$resolvedHomeName”.",
  "\$count nhà đã chọn": "Wybrano \$count domów",
  "🚨 \$count nhà không an toàn\$suffix":
      "🚨 \$count niebezpiecznych domów\$suffix",
  "⚠️ \$count nhà cần chú ý\$suffix": "⚠️ \$count domów wymaga uwagi\$suffix",
  "✅ \$count nhà an toàn": "✅ \$count bezpiecznych domów",
  "\$count nhà đang được theo dõi": "Monitorowane domy: \$count",
  "\$minutes phút": "\$minutes min",
  "Đã cài nhắc nhở cho \$updatedHomes nhà.":
      "Ustawiono przypomnienie dla \$updatedHomes domów.",
  "Đã cài báo động cho \$updatedDevices thiết bị trong \$updatedHomes nhà.\n":
      "Ustawiono alarm dla \$updatedDevices urządzeń w \$updatedHomes domach.\n",
  "Đã chia sẻ các nhà bạn có quyền.\n\n\$skipped nhà bị bỏ qua vì bạn không có quyền chia sẻ.":
      "Udostępniono domy, którymi możesz zarządzać.\n\nPominięto \$skipped domów, ponieważ nie masz uprawnień do ich udostępniania.",
  "Đã áp dụng báo động cho \$count thiết bị an ninh":
      "Zastosowano alarm do \$count urządzeń zabezpieczających",
  "Áp dụng cùng một lịch cho \$count thiết bị an ninh":
      "Zastosuj ten sam harmonogram do \$count urządzeń zabezpieczających",
  "\$count phút trước": "\$count minut temu",
  "\$count giờ trước": "\$count godzin temu",
  "\${count}h trước": "\${count} godz. temu",
  "\${hours}h\$minutes' trước": "\${hours} godz. \$minutes min temu",
  "\$count ngày trước": "\$count dni temu",
  "\$count tháng trước": "\$count miesięcy temu",
  "Bạn chắc chắn muốn xoá \$name khỏi nhà này?":
      "Czy na pewno chcesz usunąć użytkownika \$name z tego domu?",
  "\$targetEmail\nXin gia nhập \"\$homeName\"":
      "\$targetEmail\nProsi o dołączenie do „\$homeName”",
  "Xin gia nhập \"\$homeName\"": "Prosi o dołączenie do „\$homeName”",
  "Bạn được mời nhận quyền nhà \"\$homeName\"":
      "Zaproszono Cię do przejęcia własności domu „\$homeName”",
  "\$ownerEmail\nMời bạn gia nhập \"\$homeName\"":
      "\$ownerEmail\nZaprasza Cię do domu „\$homeName”",
  "Mời bạn gia nhập \"\$homeName\"": "Zaprasza Cię do domu „\$homeName”",
  "Cần kiểm tra: \$joined": "Wymaga uwagi: \$joined",
  "Cập nhật \$value": "Zaktualizowano \$value",
  "Hãy thêm thiết bị SafeHome đầu tiên để bắt đầu theo dõi nhà.":
      "Dodaj pierwsze urządzenie SafeHome, aby rozpocząć monitorowanie tego domu.",
  "Kiểm tra cảnh báo khẩn cấp trước, sau đó liên hệ thành viên trong nhà nếu cần.":
      "Najpierw sprawdź alerty awaryjne, a następnie w razie potrzeby skontaktuj się z domownikami.",
  "Không có thành viên nào ở nhà nhưng cửa hoặc khóa đang mở, hãy kiểm tra ngay.":
      "Nikogo nie ma w domu, ale drzwi lub zamek są otwarte. Sprawdź to natychmiast.",
  "Kiểm tra cửa hoặc khóa đang mở trước khi giữ nhà ở chế độ Bảo vệ.":
      "Sprawdź otwarte drzwi lub zamek przed pozostawieniem domu w trybie ochrony.",
  "Có thể vẫn có người ở nhà; nếu đúng, nên chuyển về Bình thường.":
      "Ktoś może nadal być w domu. Jeśli tak, przełącz na tryb Normalny.",
  "Có thành viên chưa xác định vị trí, hãy nhắc họ mở ứng dụng hoặc kiểm tra quyền vị trí.":
      "Lokalizacja niektórych członków jest nieznana. Poproś ich o otwarcie aplikacji lub sprawdzenie uprawnienia do lokalizacji.",
  "Có thiết bị mất kết nối, hãy kiểm tra pin, nguồn hoặc vị trí đặt thiết bị.":
      "Urządzenie utraciło połączenie. Sprawdź baterię, zasilanie lub miejsce instalacji.",
  "Có thiết bị pin yếu, nên thay pin sớm để tránh mất cảnh báo.":
      "Urządzenie ma niski poziom baterii. Wymień ją wkrótce, aby nie przegapić alertów.",
  "Bạn chưa đặt nhắc nhở, nên tạo lịch nhắc kiểm tra nhà định kỳ.":
      "Nie ustawiono przypomnienia. Utwórz harmonogram regularnego sprawdzania domu.",
  "Bạn chưa đặt lịch báo động, nên bật bảo vệ theo khung giờ thường vắng nhà.":
      "Nie ustawiono harmonogramu alarmu. Włącz ochronę w godzinach, gdy zwykle nikogo nie ma w domu.",
  "Không có việc cần xử lý ngay, bạn chỉ cần tiếp tục theo dõi trạng thái nhà.":
      "Nie ma niczego wymagającego natychmiastowego działania. Kontynuuj monitorowanie stanu domu.",
  "Lặp sau \$minutes phút": "Powtórz po \$minutes minutach",
  "Đang dùng • \$repeatText": "Aktywne • \$repeatText",
  "Giám sát an ninh • \$repeatText":
      "Monitorowanie bezpieczeństwa • \$repeatText",
  "Gia đình: \$mode": "Tryb domu: \$mode",
  "Gợi ý xử lý": "Sugerowane działania",
  "Phát hiện \$count vấn đề cần xử lý":
      "Wykryto \$count problemów wymagających działania",
  "Hôm nay các cửa đã được sử dụng \$count lần":
      "Dzisiaj użyto drzwi \$count razy",
  "Đã ghi nhận \$count hoạt động gần đây":
      "Zarejestrowano \$count ostatnich aktywności",
  "Hệ thống: Cần kiểm tra \$issueCount mục":
      "System: \$issueCount elementów wymaga sprawdzenia",
  "FCM token đã sẵn sàng trên điện thoại này.":
      "Token FCM jest gotowy na tym telefonie.",
  "FCM token đã sẵn sàng, nhưng Auto rời khỏi nhà còn thiếu điều kiện.":
      "Token FCM jest gotowy, ale automatyczna ochrona po wyjściu z domu nie spełnia jeszcze jednego wymagania.",
  "Hiện có \$emergencyTotal thiết bị khẩn cấp. Khuyến nghị tối thiểu: báo khói và SOS.":
      "Znaleziono \$emergencyTotal urządzeń awaryjnych. Zalecane minimum: czujnik dymu i SOS.",
  "Bạn chắc chắn muốn chuyển quyền chủ nhà cho:\n\$targetEmail?":
      "Czy na pewno chcesz przenieść własność domu na:\n\$targetEmail?",
  "\$count cửa đã đóng an toàn": "\$count bezpiecznie zamkniętych drzwi",
  "\$count cửa và khóa đã an toàn": "\$count zabezpieczonych drzwi i zamków",
  "\$count thiết bị đang được theo dõi": "Monitorowane urządzenia: \$count",
  "Cập nhật \$timeText": "Zaktualizowano \$timeText",
  "Dữ liệu gần nhất cập nhật \$count phút trước":
      "Ostatnia aktualizacja danych: \$count minut temu",
  "Dữ liệu gần nhất cập nhật \$count giờ trước":
      "Ostatnia aktualizacja danych: \$count godzin temu",
  "Thành viên trong nhà: \$count": "Członkowie w domu: \$count",
  "Thành viên bên ngoài: \$count": "Członkowie poza domem: \$count",
  "Chưa xác định vị trí: \$count": "Nieznana lokalizacja: \$count",
  "Môi trường hiện tại: \$environment": "Bieżące warunki: \$environment",
  "\$name: Đang mở khi nhà ở chế độ Bảo vệ":
      "\$name: otwarte, gdy dom jest w trybie ochrony",
  "An tâm hơn trong từng ngôi nhà": "Spokój w każdym domu",
  "Báo động SafeHome": "Alarm SafeHome",
  "Có cảnh báo an ninh cần kiểm tra ngay.":
      "Alert bezpieczeństwa wymaga natychmiastowego sprawdzenia.",
  "Có cảnh báo cần kiểm tra": "Alert wymaga sprawdzenia",
  "Tự đóng sau \$time": "Zamknie się automatycznie za \$time",
  "Ngày trong tuần": "Dni tygodnia",
  "Hoặc": "Lub",
  "Giờ bắt đầu và kết thúc không được trùng nhau":
      "Godzina rozpoczęcia i zakończenia nie mogą być takie same",
  "Giờ kết thúc phải sau thời điểm hiện tại":
      "Godzina zakończenia musi być późniejsza niż bieżąca",
  "Khoảng tạm tắt không hợp lệ": "Nieprawidłowy przedział wstrzymania alarmu",
  "Khoảng tạm tắt không trùng với lịch báo động nào đang bật":
      "Przedział wstrzymania nie pokrywa się z żadnym aktywnym harmonogramem alarmu",
  "Cài đặt báo động": "Ustawienia alarmu",
  "Điều khiển cách cảm biến này kích hoạt cảnh báo.":
      "Określ, w jaki sposób ten czujnik uruchamia alerty.",
  "Tham gia báo động": "Udział w alarmach",
  "Tắt để cảm biến không tạo báo động.":
      "Wyłącz, aby ten czujnik nie uruchamiał alarmu.",
  "Bật còi vật lý": "Włącz fizyczną syrenę",
  "Cho phép kích hoạt còi trong nhà.": "Zezwól na uruchomienie syreny w domu.",
  "Đánh thức màn hình": "Wybudź ekran",
  "Hiển thị cảnh báo toàn màn hình trên điện thoại.":
      "Wyświetl alert pełnoekranowy na telefonie.",
  "Độ trễ kích hoạt": "Opóźnienie uruchomienia",
  "Chỉ áp dụng cho cảm biến an ninh.":
      "Dotyczy tylko czujników bezpieczeństwa.",
  "Cảm biến khẩn cấp luôn kích hoạt ngay lập tức.":
      "Czujniki awaryjne zawsze uruchamiają się natychmiast.",
  "Ngay lập tức": "Natychmiast",
  "giây": "sek.",
  "Đã lưu cấu hình báo động": "Zapisano konfigurację alarmu",
  "Không thể lưu cấu hình báo động":
      "Nie udało się zapisać konfiguracji alarmu",
  "Chỉ chủ nhà và quản trị viên có thể thay đổi cài đặt này.":
      "Tylko właściciel i administratorzy mogą zmienić to ustawienie.",
  "Thông tin chi tiết": "Szczegóły urządzenia",
  "Thông báo báo động": "Powiadomienie alarmowe",
  "Cài đặt nhắc nhở": "Ustawienia przypomnień",
  "Nhắc nhở theo lịch": "Zaplanowane przypomnienie",
  "Danh sách thông báo": "Powiadomienia",
  "Cài đặt thông báo": "Ustawienia powiadomień",
  "Sử dụng báo động theo lịch đã thiết lập":
      "Użyj skonfigurowanego harmonogramu alarmu",
  "Chỉ gửi thông báo, không kích hoạt báo động":
      "Wysyłaj tylko powiadomienia; nie uruchamiaj alarmu",
  "Toàn bộ báo động của nhà đang tắt; hệ thống chỉ gửi thông báo.":
      "Wszystkie alarmy domu są wyłączone; system będzie wysyłał tylko powiadomienia.",
  "Chỉ Chủ nhà có thể bật chế độ này.":
      "Tylko właściciel może włączyć ten tryb.",
  "Bật Không bảo vệ?": "Włączyć tryb Bez ochrony?",
  "Cảm biến vừa phát hiện một sự kiện.": "Czujnik właśnie wykrył zdarzenie.",
  "Chỉ Chủ nhà mới có quyền bật chế độ Không bảo vệ":
      "Tylko właściciel może włączyć tryb Bez ochrony",
  "Đã chuyển nhà sang Không bảo vệ": "Dom przełączono na tryb Bez ochrony",
  "Đã chuyển sang Không bảo vệ nhưng chưa gửi được thông báo":
      "Przełączono na tryb Bez ochrony, ale nie udało się wysłać powiadomienia",
  "Giám sát toàn diện": "Pełne monitorowanie",
  "Không bảo vệ": "Bez ochrony",
  "Không bảo vệ đang bật": "Tryb Bez ochrony jest włączony",
  "Nhà đã chuyển sang Không bảo vệ":
      "Dom został przełączony na tryb Bez ochrony",
  "Thông báo cảm biến": "Powiadomienia czujników",
  "Thông báo thông thường khi cảm biến phát hiện sự kiện.":
      "Standardowe powiadomienia, gdy czujnik wykryje zdarzenie.",
  "Tôi hiểu, tiếp tục": "Rozumiem, kontynuuj",
  "Cảnh báo an ninh đã kết thúc": "Alert bezpieczeństwa zakończony",
  "Sự cố nguy hiểm đã kết thúc": "Zagrożenie zakończone",
  "Cảnh báo đã được kết thúc.": "Alert zakończony.",
  "Vẫn còn cảnh báo khác đang hoạt động.": "Inny alert jest nadal aktywny.",
  "Báo động đã hoạt động trở lại": "Alarm jest ponownie aktywny",
  "Thời gian tạm dừng báo động đã kết thúc.":
      "Okres wstrzymania alarmu zakończył się.",
  "MQTT đã kết nối trở lại": "MQTT ponownie połączony",
  "Còi báo động đã được tắt": "Wyłączono fizyczną syrenę",
  "Sự cố vẫn đang được theo dõi.": "Zdarzenie jest nadal monitorowane.",
  "Bảo vệ tự động đã bật": "Włączono automatyczną ochronę",
  "Toàn bộ thành viên đã rời khỏi nhà.": "Wszyscy członkowie opuścili dom.",
  "Bảo vệ tự động đã tắt": "Wyłączono automatyczną ochronę",
  "Có thành viên đã trở về nhà.": "Jeden z członków wrócił do domu.",
  "Thiết bị đã được xoá": "Urządzenie zostało usunięte",
  "Không thể xoá thiết bị": "Nie można usunąć urządzenia",
  "Hãy thử lại thao tác xoá thiết bị.": "Spróbuj ponownie usunąć urządzenie.",
  "Chế độ Bảo vệ đã được tắt.": "Tryb ochrony został wyłączony.",
  "Nhà đang ở chế độ Bình thường.": "Dom jest w trybie Normalnym.",
  "Pin thiết bị đã ổn định": "Poziom baterii urządzenia jest stabilny",
  "Hub đã kết nối trở lại": "Hub ponownie połączony",
  "Đã chuyển về Bình thường nhưng chưa gửi được thông báo":
      "Przełączono na tryb Normalny, ale nie udało się wysłać powiadomienia",
  "Chung cho nhà": "Wspólne dla domu",
  "Áp dụng cho toàn bộ thành viên và có thể bật còi vật lý.":
      "Dotyczy wszystkich członków i może uruchomić fizyczną syrenę.",
  "Cá nhân": "Osobiste",
  "Lịch cá nhân hoạt động độc lập và không bật còi vật lý.":
      "Osobisty harmonogram działa niezależnie i nigdy nie uruchamia fizycznej syreny.",
  "Cài đặt này chỉ áp dụng cho tài khoản của bạn.":
      "To ustawienie dotyczy tylko Twojego konta.",
  "Chỉ chủ nhà và quản trị viên có thể thay đổi phần chung cho nhà.":
      "Tylko właściciel i administratorzy mogą zmieniać wspólne ustawienia domu.",
  "Tham gia hệ thống báo động": "Udział w systemie alarmowym",
  "Cảm biến khẩn cấp luôn tham gia hệ thống báo động.":
      "Czujniki awaryjne zawsze uczestniczą w systemie alarmowym.",
  "Tắt để thiết bị không tạo bất kỳ báo động nào.":
      "Wyłącz, aby urządzenie nie uruchamiało żadnego alarmu.",
  "Lịch báo động chung": "Wspólny harmonogram alarmu",
  "Lịch báo động cá nhân": "Osobisty harmonogram alarmu",
  "Hiển thị cảnh báo toàn màn hình trên điện thoại của bạn.":
      "Wyświetl alert pełnoekranowy na swoim telefonie.",
  "Lặp lại cảnh báo": "Powtarzaj alert",
  "Báo động chung": "Wspólny alarm",
  "Báo động cá nhân": "Osobisty alarm",
  "Đã cài đặt": "Skonfigurowano",
  "Chưa cài đặt": "Nie skonfigurowano",
  "Lịch chung và lịch cá nhân hoạt động song song, không còn phải chọn một trong hai.":
      "Wspólne i osobiste harmonogramy działają równolegle; nie musisz już wybierać jednego z nich.",
  "Cài nhanh chung": "Szybka konfiguracja wspólna",
  "Cài nhanh cá nhân": "Szybka konfiguracja osobista",
  "Thiết lập nhanh lịch cá nhân": "Szybka konfiguracja osobistego harmonogramu",
  "Thiết lập nhanh lịch chung": "Szybka konfiguracja wspólnego harmonogramu",
  "Lịch này chỉ áp dụng cho bạn và không bật còi vật lý.":
      "Ten harmonogram dotyczy tylko Ciebie i nie uruchamia fizycznej syreny.",
  "Lịch này áp dụng cho toàn bộ thành viên trong nhà.":
      "Ten harmonogram dotyczy wszystkich członków domu.",
  "Đã áp dụng lịch báo động": "Zastosowano harmonogram alarmu",
  "Không thể lưu lịch báo động": "Nie można zapisać harmonogramu alarmu",
  "Nhà chưa có thiết bị an ninh":
      "W tym domu nie ma urządzeń zabezpieczających",
  "Nhận cảnh báo theo lịch chung của nhà":
      "Otrzymuj alerty ze wspólnego harmonogramu domu",
  "Tắt để không nhận thông báo hoặc cảnh báo toàn màn hình từ lịch chung. Còi vật lý của nhà vẫn hoạt động.":
      "Wyłącz, aby nie otrzymywać powiadomień ani alertów pełnoekranowych ze wspólnego harmonogramu. Fizyczna syrena w domu nadal będzie działać.",
};

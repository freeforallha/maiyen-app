const Map<String, String> huStrings = {
  "Không tìm thấy người dùng": "A felhasználó nem található",
  "Không đọc được số điện thoại": "A telefonszám nem olvasható",
  "Tin nhắn quá dài": "Az üzenet túl hosszú",
  "Không gửi được tin nhắn": "Az üzenet nem küldhető el",
  "Bạn không có quyền sửa lịch chung của nhà":
      "Nincs jogosultságod az otthon közös ütemezésének módosításához",
  "Nhà của bạn": "Az otthonod",
  "Tải tin cũ hơn": "Régebbi üzenetek betöltése",
  "Nhà chưa đặt tên": "Névtelen otthon",
  "Nhà": "Otthon",
  "Chưa có thông tin": "Nincs elérhető információ",
  "Chưa cập nhật": "Nincs frissítve",
  "Chủ nhà": "Tulajdonos",
  "Nhà được chia sẻ": "Megosztott otthon",
  "Địa chỉ": "Cím",
  "An ninh ra/vào": "Bejárati biztonság",
  "Nguy hiểm khẩn cấp": "Vészhelyzeti veszélyek",
  "Điều khiển & hạ tầng": "Vezérlés és infrastruktúra",
  "Môi trường": "Környezet",
  "Toàn bộ thiết bị SafeHome": "Minden SafeHome-eszköz",
  "Cửa ra/vào": "Bejárati ajtó",
  "Cửa": "Ajtó",
  "Cửa sổ": "Ablak",
  "Cổng": "Kapu",
  "Khóa thông minh": "Okoszár",
  "Chuyển động": "Mozgás",
  "Hiện diện": "Jelenlét",
  "Rung/chấn động": "Rezgés/ütés",
  "Kính vỡ": "Üvegtörés",
  "Báo khói": "Füstjelző",
  "Báo nhiệt": "Hőriasztó",
  "Khí CO": "Szén-monoxid",
  "Báo gas": "Gázriasztó",
  "Báo ngập/rò nước": "Vízszivárgás-érzékelő",
  "Nút SOS": "SOS gomb",
  "Nhiệt độ/Độ ẩm": "Hőmérséklet/Páratartalom",
  "Bụi mịn PM2.5": "PM2.5 finompor",
  "CO₂": "CO₂",
  "Chất lượng không khí": "Levegőminőség",
  "Ổ điện thông minh": "Okoskonnektor",
  "Còi báo động": "Sziréna",
  "Van thông minh": "Okosszelep",
  "Camera": "Kamera",
  "Chuông cửa": "Ajtócsengő",
  "Bàn phím an ninh": "Biztonsági billentyűzet",
  "Bộ mở rộng sóng": "Jelerősítő",
  "Hub trung tâm": "Központi hub",
  "Đo điện năng": "Energiafogyasztás-mérő",
  "Nguồn dự phòng UPS": "UPS tartalék tápellátás",
  "Thiết bị đang Offline": "Az eszköz offline",
  "Thiết bị đang Online": "Az eszköz online",
  "lâu không phản hồi": "régóta nem válaszol",
  "Kết nối cần kiểm tra": "A kapcsolat ellenőrzést igényel",
  "Vừa xong": "Épp most",
  "Bị tháo": "Szabotázs észlelve",
  "Có khói": "Füst észlelve",
  "Bình thường": "Normál",
  "Bảo vệ": "Védelem",
  "Chế độ Bảo vệ": "Védelmi mód",
  "Tự động Bảo vệ khi rời nhà": "Automatikus védelem távozáskor",
  "Đã kích hoạt": "Aktiválva",
  "Sẵn sàng": "Készen áll",
  "Đang đóng": "Zárva",
  "Đang mở": "Nyitva",
  "Rò rỉ gas": "Gázszivárgás észlelve",
  "Phát hiện ngập nước": "Vízszivárgás észlelve",
  "Phát hiện chuyển động": "Mozgás észlelve",
  "Không có chuyển động": "Nincs észlelt mozgás",
  "Phát hiện hiện diện": "Jelenlét észlelve",
  "Không phát hiện hiện diện": "Nincs észlelt jelenlét",
  "Phát hiện rung/chấn động": "Rezgés/ütés észlelve",
  "Không có rung bất thường": "Nincs szokatlan rezgés",
  "Phát hiện kính vỡ": "Üvegtörés észlelve",
  "Không có cảnh báo kính vỡ": "Nincs üvegtörési riasztás",
  "Nhiệt độ nguy hiểm": "Veszélyes hőmérséklet észlelve",
  "Phát hiện khí CO": "Szén-monoxid észlelve",
  "Không phát hiện khí CO": "Nincs észlelt szén-monoxid",
  "Khóa đang mở": "Nyitva",
  "Khóa đang đóng": "Zárva",
  "Đang bật": "Bekapcsolva",
  "Bật": "Bekapcsolva",
  "Đang tắt": "Kikapcsolva",
  "Đang theo dõi điện năng": "Energiafigyelés folyamatban",
  "Đang dùng nguồn dự phòng": "Tartalék tápellátásról működik",
  "Nguồn điện bình thường": "A hálózati tápellátás normális",
  "Còi đang bật": "A sziréna aktív",
  "Còi sẵn sàng": "A sziréna készen áll",
  "Van đang mở": "A szelep nyitva",
  "Van đã đóng": "A szelep zárva",
  "Đang hoạt động": "Működik",
  "Đang theo dõi": "Megfigyelés alatt",
  "Chưa nhận diện": "Ismeretlen eszköz",
  "Chưa có cập nhật": "Még nincs frissítés",
  "Chưa có thiết bị, hãy nhấn nút + để thêm để bắt đầu duy trì an ninh":
      "Még nincs eszköz. Koppints a + gombra egy eszköz hozzáadásához és otthonod védelmének megkezdéséhez.",
  "CHƯA AN TOÀN": "NEM BIZTONSÁGOS",
  "ĐÃ AN TOÀN": "BIZTONSÁGOS",
  "Nhà đang có dấu hiệu cần kiểm tra, bạn nên xem lại các trạng thái bên dưới.":
      "Az otthonod ellenőrzést igényel. Tekintsd át az alábbi állapotokat.",
  "Nhà đang hoạt động ổn định, bạn có thể yên tâm.":
      "Az otthonod megfelelően működik, nyugodt lehetsz.",
  "Không có dấu hiệu khói hoặc SOS bất thường.":
      "Nem észlelhető szokatlan füst- vagy SOS-tevékenység.",
  "Chưa có nhiều hoạt động mới để phân tích sâu hơn.":
      "Nincs elegendő friss tevékenység a részletesebb elemzéshez.",
  "Hub kết nối bình thường": "A hub megfelelően csatlakozik",
  "Cài đặt cảnh báo cho nhà hiện tại":
      "Riasztási beállítások ehhez az otthonhoz",
  "Nhận cảnh báo báo động": "Riasztási értesítések fogadása",
  "Đang bật cho tài khoản này": "Engedélyezve ennél a fióknál",
  "Đang tắt cho tài khoản này": "Letiltva ennél a fióknál",
  "Hẹn giờ nhắc nhở": "Emlékeztető ütemezése",
  "Nhắc kiểm tra nhà theo thời gian":
      "Otthonellenőrzési emlékeztetők ütemezése",
  "Hẹn giờ báo động": "Riasztás ütemezése",
  "Chưa thiết lập": "Nincs beállítva",
  "Chưa thiết lập thời gian": "Nincs beállítva ütemezés",
  "Tổng hợp trạng thái nhà": "Otthonállapot összefoglalója",
  "Cần xử lý ngay": "Azonnali intézkedés szükséges",
  "Đánh giá tự động": "Automatizált értékelés",
  "Tự động đánh giá": "Automatikus értékelés",
  "Tổng quan hôm nay": "Mai áttekintés",
  "Chưa có dữ liệu tổng quan": "Még nincs áttekintési adat",
  "Chưa có dữ liệu trạng thái": "Még nincs állapotadat",
  "Chưa đủ dữ liệu để đánh giá": "Nincs elegendő adat az értékeléshez",
  "Chưa có dữ liệu để đánh giá": "Nincs adat az értékeléshez",
  "Bấm vào để xem chi tiết": "Koppints a részletek megtekintéséhez",
  "Nhấn để xem chi tiết...": "Koppints a részletekhez...",
  "Tạm dừng": "Szüneteltetve",
  "Tắt": "Kikapcsolva",
  "Chi tiết": "Részletek",
  "Tổng hợp trạng thái": "Állapotösszegzés",
  "Không an toàn": "Nem biztonságos",
  "Cần chú ý": "Figyelmet igényel",
  "An toàn": "Biztonságos",
  "Không có": "Nincs",
  "Đổi tên nhóm": "Csoport átnevezése",
  "Huỷ": "Mégse",
  "Lưu": "Mentés",
  "Thêm": "Hozzáadás",
  "Xoá": "Törlés",
  "Đổi tên": "Átnevezés",
  "Nhà của tôi": "Otthonaim",
  "Bỏ chọn toàn bộ nhóm": "A teljes csoport kijelölésének megszüntetése",
  "Chọn toàn bộ nhóm": "A teljes csoport kijelölése",
  "Bỏ chọn": "Kijelölés megszüntetése",
  "Quay lại": "Vissza",
  "Tìm kiếm": "Keresés",
  "Đóng tìm kiếm": "Keresés bezárása",
  "Giờ": "Óra",
  "Phút": "Perc",
  "Đặt nhắc nhở cho nhà": "Otthoni emlékeztető beállítása",
  "Đặt báo động cho nhà": "Otthoni riasztás beállítása",
  "Xác nhận thay đổi": "Módosítások megerősítése",
  "Tiếp tục": "Folytatás",
  "Giờ nhắc nhở": "Emlékeztető ideje",
  "Giờ bắt đầu báo động": "Riasztás kezdési ideje",
  "Giờ kết thúc báo động": "Riasztás befejezési ideje",
  "Không có nhà nào đủ điều kiện để cài": "Nem található megfelelő otthon",
  "Cài đặt hoàn tất": "A beállítás befejeződött",
  "Xác nhận rời nhà": "Kilépés megerősítése az otthonból",
  "Xác nhận xoá nhà": "Otthon törlésének megerősítése",
  "Nhập mật khẩu": "Add meg a jelszót",
  "Mật khẩu tài khoản": "Fiók jelszava",
  "Rời khỏi nhà": "Kilépés az otthonból",
  "Xoá nhà": "Otthon törlése",
  "Sai mật khẩu": "Helytelen jelszó",
  "Đã rời khỏi home": "Kiléptél az otthonból",
  "Đã cập nhật": "Frissítve",
  "Tìm home...": "Otthonok keresése...",
  "Đặt vị trí nhà và bật bảo vệ tự động":
      "Állítsd be az otthon helyét és engedélyezd az automatikus védelmet",
  "Chuyển quyền chủ nhà hoặc xoá nhà":
      "Tulajdonjog átadása vagy az otthon törlése",
  "Đặt nhắc nhở / báo động nhà đã chọn":
      "Emlékeztető/riasztás beállítása a kijelölt otthonokhoz",
  "Chia sẻ nhà đã chọn": "Kijelölt otthonok megosztása",
  "Mở danh sách chia sẻ nhà": "Otthonmegosztási lista megnyitása",
  "Xoá các nhà đã chọn?": "Törlöd a kijelölt otthonokat?",
  "Các nhà đã chọn sẽ bị xoá vĩnh viễn.":
      "A kijelölt otthonok véglegesen törlődnek.",
  "Hoặc quét QR để xin gia nhập các nhà đã chọn":
      "Vagy olvass be egy QR-kódot a kijelölt otthonokhoz való hozzáférés kéréséhez",
  "Email người nhận": "Címzett e-mail-címe",
  "Chia sẻ": "Megosztás",
  "Email chưa đăng ký": "Az e-mail-cím nincs regisztrálva",
  "Chia sẻ hoàn tất": "Megosztás befejezve",
  "Mở List chia sẻ nhà": "Otthonmegosztási lista megnyitása",
  "Không có nhà nào bạn có quyền quản lý": "Egyik kijelölt otthont sem kezeled",
  "Chưa share cho ai": "Még nincs megosztva senkivel",
  "Tìm nhà": "Otthonok keresése",
  "Xoá các nhà đã chọn ?": "Törlöd a kijelölt otthonokat?",
  "Thông báo Home": "Otthoni értesítések",
  "Thông báo nhà": "Otthoni értesítések",
  "Vai trò thành viên đã thay đổi": "A tag szerepköre megváltozott",
  "Xoá tất cả thông báo?": "Törlöd az összes értesítést?",
  "Toàn bộ thông báo nhà sẽ bị xoá.": "Az otthon összes értesítése törlődik.",
  "Chưa có thông báo nào": "Még nincsenek értesítések",
  "Chưa có thông báo": "Nincsenek értesítések",
  "Vuốt lên để tải thêm": "Húzd felfelé további elemek betöltéséhez",
  "Không có thiết bị": "Nincsenek eszközök",
  "Chỉ chủ nhà mới được xoá nhà": "Csak a tulajdonos törölheti ezt az otthont",
  "Chỉ chủ nhà mới được chuyển quyền":
      "Csak a tulajdonos adhatja át a tulajdonjogot",
  "Lưu ý khi bật báo động": "Megjegyzés a riasztás bekapcsolásához",
  "Báo động đã được bật": "A riasztás engedélyezve",
  "Đã hiểu": "Értem",
  "Lưu ý tạm tắt báo động": "Megjegyzés a riasztás szüneteltetéséhez",
  "Đã bật báo động": "A riasztás bekapcsolva",
  "Đã tắt báo động": "A riasztás kikapcsolva",
  "Tắt báo động": "Riasztás leállítása",
  "Cả ngày": "Egész nap",
  "Bạn không có quyền thực hiện thao tác này.":
      "Nincs jogosultságod ehhez a művelethez.",
  "Không thể hoàn tất thao tác. Vui lòng thử lại.":
      "A művelet nem hajtható végre. Próbáld újra.",
  "QR gia nhập nhiều nhà không hợp lệ":
      "Érvénytelen, több otthonhoz csatlakoztató QR-kód",
  "Bạn đang là chủ các nhà này": "Ezeknek az otthonoknak te vagy a tulajdonosa",
  "Một người dùng": "Egy felhasználó",
  "Yêu cầu gia nhập nhà": "Otthonhoz csatlakozási kérelem",
  "Đã gửi yêu cầu gia nhập nhà": "A csatlakozási kérelem elküldve",
  "QR gia nhập không hợp lệ": "Érvénytelen csatlakozási QR-kód",
  "Bạn đang là chủ nhà này": "Már te vagy ennek az otthonnak a tulajdonosa",
  "QR này không phải mã xin gia nhập nhà":
      "Ez a QR-kód nem otthoni csatlakozási kód",
  "Bạn không có quyền thêm thiết bị":
      "Nincs jogosultságod eszközök hozzáadásához",
  "Đã mở chế độ thêm thiết bị": "Az eszközpárosítás engedélyezve",
  "Rời khỏi Home này?": "Kilépsz ebből az otthonból?",
  "Nhà này và toàn bộ thiết bị bên trong sẽ bị xoá vĩnh viễn.":
      "Ez az otthon és minden benne lévő eszköz véglegesen törlődik.",
  "Đã xoá nhà": "Az otthon törölve",
  "QR của nhà này": "Ennek az otthonnak a QR-kódja",
  "Người khác quét mã này để gửi yêu cầu gia nhập nhà.":
      "Mások beolvashatják ezt a kódot, hogy hozzáférést kérjenek az otthonhoz.",
  "Chia sẻ nhà": "Otthon megosztása",
  "Quét QR để xin gia nhập nhà": "QR-kód beolvasása otthonhoz csatlakozáshoz",
  "Quét QR xin gia nhập nhà": "QR-kód beolvasása az otthonhoz csatlakozáshoz",
  "Đưa mã QR chia sẻ nhà vào khung hình":
      "Helyezd a megosztott otthon QR-kódját a keretbe",
  "Mã QR này do chủ nhà chia sẻ":
      "Ezt a QR-kódot az otthon tulajdonosa osztotta meg",
  "Nhập mã mời": "Add meg a meghívókódot",
  "Gửi yêu cầu gia nhập": "Csatlakozási kérelem küldése",
  "QR này không phải mã thiết bị": "Ez a QR-kód nem eszközkód",
  "Xin gia nhập nhà": "Csatlakozás kérése az otthonhoz",
  "Quét mã QR chia sẻ nhà": "Otthonmegosztási QR-kód beolvasása",
  "Mời thành viên bằng mã QR": "Tag meghívása QR-kóddal",
  "Không thể share cho chính bạn": "Nem oszthatod meg saját magaddal",
  "Lời mời chia sẻ nhà": "Otthonmegosztási meghívó",
  "Đã share home": "Az otthon megosztva",
  "Chuyển quyền chủ nhà": "Tulajdonjog átadása",
  "Không thể chuyển quyền cho chính bạn":
      "Nem adhatod át a tulajdonjogot saját magadnak",
  "Không tìm thấy user": "A felhasználó nem található",
  "Không tìm thấy tài khoản": "A fiók nem található",
  "Xác nhận chuyển quyền": "Tulajdonjog-átadás megerősítése",
  "Chuyển": "Átadás",
  "Xác nhận mật khẩu": "Jelszó megerősítése",
  "Yêu cầu chuyển quyền chủ nhà": "Tulajdonjog-átadási kérelem",
  "Đã gửi yêu cầu chuyển quyền": "Az átadási kérelem elküldve",
  "Đã gửi yêu cầu chuyển quyền chủ nhà":
      "A tulajdonjog-átadási kérelem elküldve",
  "Bạn không có quyền xoá thiết bị": "Nincs jogosultságod eszközök törléséhez",
  "Xóa Device?": "Törlöd ezt az eszközt?",
  "Đã gửi yêu cầu xoá thiết bị": "Az eszköztörlési kérelem elküldve",
  "Đang xoá thiết bị": "Eszköz törlése folyamatban",
  "Đăng xuất?": "Kijelentkezel?",
  "Thêm nhà": "Otthon hozzáadása",
  "Thêm nhà mới": "Új otthon hozzáadása",
  "Tạo nhà mới": "Új otthon létrehozása",
  "Tạo một ngôi nhà mới của bạn": "Hozz létre egy új otthont",
  "Quét mã QR được chủ nhà chia sẻ":
      "Olvasd be a tulajdonos által megosztott QR-kódot",
  "Tên nhà": "Otthon neve",
  "Số điện thoại": "Telefonszám",
  "Nam": "Férfi",
  "Nữ": "Nő",
  "Ngày": "Nap",
  "Tháng": "Hónap",
  "Năm": "Év",
  "Thông tin cá nhân": "Személyes adatok",
  "Thiết lập tài khoản": "Fiók beállítása",
  "Vui lòng nhập đủ thông tin": "Add meg az összes szükséges adatot",
  "Không thể lưu thông tin": "Az adatok nem menthetők",
  "Đã lưu thông tin": "Az adatok mentve",
  "Lỗi lưu profile": "A profil mentése sikertelen",
  "Thêm số điện thoại để dùng cho các trường hợp khẩn cấp":
      "Adj meg egy telefonszámot vészhelyzetekhez",
  "Hoàn tất": "Kész",
  "Đã tạo nhà mới": "Az új otthon létrehozva",
  "Về muộn": "Későn érek haza",
  "Ra ngoài": "Elmegyek",
  "Khác": "Egyéb",
  "⏸️ Tạm tắt báo động hôm nay": "⏸️ Riasztás szüneteltetése mára",
  "Chọn giờ bắt đầu tạm tắt": "Válaszd ki a szünet kezdetét",
  "Từ": "Ettől",
  "Từ giờ": "Mostantól",
  "Chọn giờ kết thúc tạm tắt": "Válaszd ki a szünet végét",
  "Đến": "Eddig",
  "Đến giờ": "Eddig az időpontig",
  "Xoá lịch tạm tắt": "Szüneteltetési ütemezés törlése",
  "Xóa lịch tạm tắt": "Szüneteltetési ütemezés törlése",
  "Giới tính": "Nem",
  "SĐT": "Telefon",
  "Ngày sinh": "Születési dátum",
  "Yêu cầu & lời mời": "Kérelmek és meghívók",
  "Xem lời mời chia sẻ và xin gia nhập":
      "Megosztási meghívók és csatlakozási kérelmek megtekintése",
  "Cài đặt bảo mật": "Biztonsági beállítások",
  "Quyền báo động toàn màn hình": "Teljes képernyős riasztási engedély",
  "Báo động toàn màn hình": "Teljes képernyős riasztás",
  "Đã được cấp quyền": "Engedély megadva",
  "Chưa được cấp quyền": "Nincs engedélyezve",
  "Mở cài đặt hệ thống": "Rendszerbeállítások megnyitása",
  "Đăng xuất": "Kijelentkezés",
  "Thoát tài khoản khỏi thiết bị này":
      "Fiók kijelentkeztetése erről az eszközről",
  "Không có yêu cầu hoặc lời mời nào": "Nincsenek kérelmek vagy meghívók",
  "Xoá tài khoản": "Fiók törlése",
  "Hành động này sẽ xoá toàn bộ dữ liệu:": "Ez a művelet minden adatot töröl:",
  "Nhà và thiết bị": "Otthonok és eszközök",
  "Chia sẻ và quyền truy cập": "Megosztás és hozzáférés",
  "Toàn bộ dữ liệu liên quan": "Minden kapcsolódó adat",
  "Mật khẩu xác nhận": "Megerősítő jelszó",
  "Đã xoá tài khoản": "A fiók törölve",
  "Xoá thất bại": "A törlés sikertelen",
  "Lỗi xoá tài khoản": "A fiók törlése sikertelen",
  "Tình trạng": "Állapot",
  "Tháo/Lắp": "Szabotázsérzékelés",
  "Pin": "Akkumulátor",
  "Tín hiệu": "Jel",
  "Chưa liên kết": "Nincs társítva",
  "Liên lạc cuối": "Utolsó kapcsolat",
  "Event cuối": "Utolsó esemény",
  "Sự kiện cuối": "Utolsó esemény",
  "Lần kích hoạt cuối": "Utolsó aktiválás",
  "Thiết bị không còn tồn tại": "Az eszköz már nem létezik",
  "Mất kết nối": "Leválasztva",
  "Online": "Online",
  "Offline": "Offline",
  "Loại thiết bị": "Eszköztípus",
  "Nhiệt độ": "Hőmérséklet",
  "Độ ẩm": "Páratartalom",
  "Công suất": "Teljesítmény",
  "Điện áp": "Feszültség",
  "Dòng điện": "Áramerősség",
  "Điện năng": "Energia",
  "Cường độ rung": "Rezgéserősség",
  "Góc nghiêng": "Dőlésszög",
  "Độ mở van": "Szelepnyitás",
  "Nguồn dự phòng": "Tartalék tápellátás",
  "Ngập/rò nước": "Elárasztás/vízszivárgás",
  "Phát hiện khói": "Füst észlelve",
  "Quản lý phòng": "Helyiségek kezelése",
  "Bạn không có quyền quản lý phòng":
      "Nincs jogosultságod a helyiségek kezeléséhez",
  "Đổi tên phòng": "Helyiség átnevezése",
  "Tên phòng": "Helyiség neve",
  "Xoá phòng": "Helyiség törlése",
  "Thiết bị trong phòng này sẽ được chuyển về Chưa phân phòng.":
      "Az ebben a helyiségben lévő eszközök a Nincs hozzárendelve csoportba kerülnek.",
  "Thêm phòng": "Helyiség hozzáadása",
  "Ví dụ: Phòng khách": "Példa: Nappali",
  "Phòng khách": "Nappali",
  "Tên phòng đã tồn tại": "A helyiség neve már létezik",
  "Chưa phân phòng": "Nincs hozzárendelve",
  "Phòng mặc định": "Alapértelmezett helyiség",
  "Phát hiện bất thường": "Rendellenes tevékenység észlelve",
  "Phát hiện cạy phá": "Felfeszítési kísérlet észlelve",
  "Tamper detected": "Szabotázs észlelve",
  "Tamper cleared": "A szabotázsriasztás megszűnt",
  "Door opened": "Az ajtó nyitva",
  "Door closed": "Az ajtó zárva",
  "Motion detected": "Mozgás észlelve",
  "Battery low": "Alacsony töltöttség",
  "Device offline": "Eszköz offline",
  "Device online": "Eszköz online",
  "Cửa mở": "Az ajtó nyitva",
  "Cửa đóng": "Az ajtó zárva",
  "Chưa đặt vị trí nhà": "Az otthon helye nincs beállítva",
  "Đặt vị trí nhà tại đây": "Állítsd be itt az otthon helyét",
  "Hãy đặt vị trí nhà trước khi bật tự động Bảo vệ":
      "Az automatikus védelem bekapcsolása előtt állítsd be az otthon helyét",
  "Bán kính bảo vệ mặc định: 150 m": "Alapértelmezett védelmi sugár: 150 m",
  "Mỗi thành viên sẽ cần cấp quyền vị trí Luôn cho phép để trạng thái rời/đến nhà hoạt động khi ứng dụng chạy nền.":
      "Minden tagnak engedélyeznie kell a Mindig helyhozzáférést, hogy a távol/otthon állapot a háttérben is működjön.",
  "Lưu cài đặt": "Beállítások mentése",
  "Đã đặt vị trí nhà": "Az otthon helye beállítva",
  "Đang lấy vị trí...": "Hely lekérése...",
  "Đang lưu...": "Mentés...",
  "Đổi tên hiển thị": "Megjelenített név módosítása",
  "Cập nhật thông tin nhà": "Otthon adatainak frissítése",
  "Nhập địa chỉ của nhà": "Adja meg az otthon címét",
  "Lưu thay đổi": "Módosítások mentése",
  "Tên này chỉ hiển thị riêng trên tài khoản của bạn.":
      "Ez a név csak az Ön fiókjában jelenik meg.",
  "Tên và địa chỉ sẽ được cập nhật cho toàn bộ thành viên trong nhà.":
      "A név és a cím az otthon minden tagjánál frissül.",
  "Một thành viên": "Egy tag",
  "Đã cập nhật thông tin nhà": "Az otthon adatai frissítve",
  "Thay tên": "Átnevezés",
  "Đã đổi tên thiết bị": "Az eszköz átnevezve",
  "Chưa chọn nhà để kiểm tra": "Nincs kiválasztva otthon a teszthez",
  "Hãy thực hiện kiểm tra bằng tài khoản Owner":
      "A tesztet a Tulajdonos fiókkal végezze el",
  "Không đọc được dữ liệu nhà": "Az otthon adatai nem olvashatók",
  "Nhà cần có ít nhất một thiết bị để test":
      "A teszthez az otthonnak legalább egy eszközzel kell rendelkeznie",
  "Đóng": "Bezárás",
  "Đã thiết lập": "Beállítva",
  "Quét QR": "QR-kód beolvasása",
  "Quét QR để thêm thiết bị": "Olvassa be a QR-kódot eszköz hozzáadásához",
  "Nhập HUB ID thủ công": "HUB-azonosító kézi megadása",
  "Bạn không có quyền sắp xếp phòng":
      "Nincs jogosultsága a helyiségek átrendezéséhez",
  "Cảnh báo khói": "Füstriasztás",
  "Cập nhật thiết bị": "Eszközfrissítés",
  "Cửa đang mở": "Az ajtó nyitva van",
  "Cửa đã đóng": "Az ajtó zárva van",
  "Firebase Rules: CÓ LỖI": "Firebase Rules: HIBÁK TALÁLHATÓK",
  "Firebase Rules: ĐẠT": "Firebase Rules: MEGFELELT",
  "Giờ không hợp lệ": "Érvénytelen időpont",
  "Khôi phục mật khẩu": "Jelszó visszaállítása",
  "Nhập email của bạn": "Adja meg e-mail-címét",
  "Gửi": "Küldés",
  "Đã gửi email khôi phục": "A jelszó-visszaállító e-mail elküldve",
  "Không gửi được email": "Az e-mail nem küldhető el",
  "Vui lòng nhập email và mật khẩu": "Adja meg e-mail-címét és jelszavát",
  "Mật khẩu xác nhận không khớp": "A jelszavak nem egyeznek",
  "Không thể tạo tài khoản": "A fiók nem hozható létre",
  "Sai tài khoản": "Helytelen fiók",
  "Email đã tồn tại": "Az e-mail-cím már létezik",
  "Mật khẩu quá yếu": "A jelszó túl gyenge",
  "Sai email hoặc mật khẩu": "Helytelen e-mail-cím vagy jelszó",
  "Lỗi đăng nhập": "Bejelentkezési hiba",
  "Email": "E-mail",
  "Mật khẩu": "Jelszó",
  "Ghi nhớ tài khoản": "Fiók megjegyzése",
  "Đăng nhập": "Bejelentkezés",
  "Đăng ký mới": "Új fiók létrehozása",
  "Quên mật khẩu?": "Elfelejtette a jelszavát?",
  "Chưa có tài khoản? Đăng ký": "Nincs fiókja? Regisztráljon",
  "Đã có tài khoản? Đăng nhập": "Már van fiókja? Jelentkezzen be",
  "Tính năng đang được phát triển": "Ez a funkció fejlesztés alatt áll",
  "Thông báo": "Értesítés",
  "Chat trong nhà": "Otthoni csevegés",
  "Tìm kiếm tin nhắn": "Üzenetek keresése",
  "Xem thành viên": "Tagok megtekintése",
  "Tìm nội dung hoặc tên người gửi": "Keresés tartalom vagy feladónév alapján",
  "Xoá từ khoá": "Kulcsszó törlése",
  "Không có kết quả": "Nincs találat",
  "Tìm ngôn ngữ": "Nyelv keresése",
  "Kết quả trước": "Előző találat",
  "Kết quả tiếp theo": "Következő találat",
  "Chưa có tin nhắn": "Még nincsenek üzenetek",
  "Không tìm thấy thành viên phù hợp": "Nem található megfelelő tag",
  "Nhắc đến trong tin nhắn": "Megemlítés az üzenetben",
  "Huỷ trả lời": "Válasz megszakítása",
  "Nhắn gì đó...": "Írjon üzenetet...",
  "Gọi điện": "Hívás",
  "Báo động thiết bị": "Eszközriasztás",
  "Chế độ áp dụng": "Alkalmazási mód",
  "Theo nhà": "Otthoni ütemezés",
  "Riêng tôi": "Személyes",
  "Dùng lịch chung do Chủ nhà hoặc Quản trị viên thiết lập":
      "A Tulajdonos vagy Adminisztrátor által beállított közös ütemezés használata",
  "Dùng lịch riêng chỉ áp dụng cho tài khoản của bạn":
      "Csak az Ön fiókjára érvényes személyes ütemezés használata",
  "Thiết lập nhanh báo động": "Riasztás gyors beállítása",
  "Thiết lập nhanh toàn bộ thiết bị": "Összes eszköz gyors beállítása",
  "Áp dụng cho toàn bộ thiết bị": "Alkalmazás minden eszközre",
  "Bắt đầu": "Kezdés",
  "Kết thúc": "Befejezés",
  "Thời gian lặp lại": "Ismétlési időköz",
  "Không lặp lại": "Nincs ismétlés",
  "Quét QR HUB": "HUB QR-kód beolvasása",
  "Đưa mã QR vào giữa khung": "Helyezze a QR-kódot a keret közepére",
  "Đang áp dụng...": "Alkalmazás...",
  "Hôm nay đã ghi nhận cảnh báo SOS": "Ma SOS-riasztás került rögzítésre",
  "Hôm nay đã ghi nhận cảnh báo khói": "Ma füstriasztás került rögzítésre",
  "Khói đã an toàn": "A füstveszély megszűnt",
  "Không tìm thấy nhà của thông báo này":
      "Az értesítéshez tartozó otthon nem található",
  "Không tìm thấy thiết bị trong nhà này":
      "Az eszköz nem található ebben az otthonban",
  "Một chủ nhà": "Egy tulajdonos",
  "Ngôi nhà đang hoạt động ổn định": "Az otthon megfelelően működik",
  "Nhiệt độ cao": "Magas hőmérséklet",
  "OK": "OK",
  "Pin yếu": "Alacsony töltöttség",
  "SOS đã kết thúc": "Az SOS-jelzés megszűnt",
  "SOS được kích hoạt": "SOS aktiválva",
  "Tamper bình thường": "A manipulációs riasztás megszűnt",
  "Thiết bị bị tháo": "Manipuláció észlelve",
  "Thiết bị mới": "Új eszköz",
  "Thiết bị offline": "Az eszköz offline",
  "Thiết bị online": "Az eszköz online",
  "Báo động kích hoạt": "Riasztás aktiválva",
  "Báo động đã tắt": "A riasztás kikapcsolva",
  "Tạm tắt báo động hôm nay": "Riasztás ideiglenes szüneteltetése mára",
  "Độ ẩm cao": "Magas páratartalom",
  "Thử lại": "Újrapróbálkozás",
  "Không thể tải dữ liệu tài khoản": "A fiók adatai nem tölthetők be",
  "Không": "Nem",
  "Đã chia sẻ nhà thành công.": "Az otthonok megosztása sikeres.",
  "Tìm nhà...": "Otthonok keresése...",
  "Đã rời khỏi nhà": "Kilépett az otthonból",
  "Bạn sẽ rời khỏi các nhà được chia sẻ.":
      "Ki fog lépni a megosztott otthonokból.",
  "Các nhà của bạn sẽ bị xoá.\n": "Az Ön otthonai törlődnek.\n",
  "Thao tác này sẽ thay đổi lịch báo động của toàn bộ thiết bị an ninh trong các nhà đã chọn.\n\n":
      "Ez a művelet módosítja a kiválasztott otthonok összes biztonsági eszközének riasztási ütemezését.\n\n",
  "Thao tác này sẽ thêm nhắc nhở cho các nhà đã chọn.\n\n":
      "Ez a művelet emlékeztetőt ad a kiválasztott otthonokhoz.\n\n",
  "Xác nhận thay đổi báo động": "Riasztási módosítások megerősítése",
  "Xác nhận thay đổi nhắc nhở": "Emlékeztető módosításainak megerősítése",
  "Lặp lại khi sự cố vẫn còn": "Ismétlés, amíg a probléma fennáll",
  "Thời gian lặp lại báo động": "Riasztás ismétlési ideje",
  "VD: Mr Chung": "Pl.: Chung úr",
  "🏡 Chưa có nhà nào": "🏡 Még nincs otthon",
  "Vẫn chuyển về Bình thường": "Mégis váltás Normál módra",
  "Tự động Bảo vệ khi rời nhà vẫn đang bật. Nếu mọi thành viên vẫn ở ngoài, hệ thống có thể tự bật lại Bảo vệ sau vài phút.":
      "Az automatikus Védelem távollétkor továbbra is be van kapcsolva. Ha minden tag még mindig távol van, a rendszer néhány perc múlva újra bekapcsolhatja a Védelmet.",
  "Chuyển về Bình thường?": "Váltás Normál módra?",
  "Khi bật, các thiết bị an ninh sẽ được giám sát ngay.\n\n":
      "Bekapcsoláskor a biztonsági eszközök figyelése azonnal megkezdődik.\n\n",
  "Bật Bảo vệ thủ công?": "Kézi Védelem bekapcsolása?",
  "Hành động này sẽ thay đổi thời gian báo động của một số thiết bị ":
      "Ez a művelet ma megváltoztatja egyes eszközök riasztási idejét",
  "Hành động này sẽ tắt toàn bộ báo động của nhà ":
      "Ez a művelet kikapcsolja az otthon összes riasztását",
  "Tắt toàn bộ báo động?": "Minden riasztás kikapcsolása?",
  "Không xoá được lịch tạm tắt báo động":
      "A riasztásszünet ütemezése nem törölhető",
  "Không lưu được tạm tắt báo động": "A riasztásszünet nem menthető",
  "Không gửi được yêu cầu xoá": "A törlési kérelem nem küldhető el",
  "Không lưu được cài đặt": "A beállítás nem menthető",
  "Không lấy được vị trí hiện tại": "Az aktuális hely nem állapítható meg",
  "Không thể xác nhận tài khoản hiện tại": "Az aktuális fiók nem ellenőrizhető",
  "Mật khẩu không đúng": "Helytelen jelszó",
  "Không thể xác nhận mật khẩu": "A jelszó nem ellenőrizhető",
  "Chỉ Chủ nhà hoặc Quản trị viên mới có quyền thay đổi lặp báo động":
      "Csak a Tulajdonos vagy egy Adminisztrátor módosíthatja a riasztás ismétlési beállítását",
  "Không lưu được thời gian lặp báo động":
      "A riasztás ismétlési ideje nem menthető",
  "Chỉ Chủ nhà hoặc Quản trị viên mới có quyền thay đổi Chế độ Bảo vệ":
      "Csak a Tulajdonos vagy egy Adminisztrátor módosíthatja a Védelem módot",
  "Không thể thay đổi chế độ nhà": "Az otthon módja nem módosítható",
  "Đã bật Bảo vệ nhưng chưa gửi được thông báo":
      "A Védelem mód be van kapcsolva, de az értesítés nem küldhető el",
  "Đã bật Chế độ Bảo vệ thủ công": "A kézi Védelem mód bekapcsolva",
  "Đã chuyển nhà về Bình thường": "Az otthon visszaállt Normál módra",
  "60 phút": "60 perc",
  "30 phút": "30 perc",
  "15 phút": "15 perc",
  "Bạn đang xem lịch của chủ nhà. Chọn Riêng tôi để tự đặt lịch báo động.":
      "A Tulajdonos ütemezését látja. Saját riasztási ütemezés beállításához válassza a Személyes lehetőséget.",
  "Chọn giờ kết thúc báo động": "Riasztás befejezési idejének kiválasztása",
  "Chọn giờ bắt đầu báo động": "Riasztás kezdési idejének kiválasztása",
  "Bạn không có quyền sửa lịch báo động của nhà":
      "Nincs jogosultsága az otthon Riasztási ütemezésének módosításához",
  "Không thể áp dụng báo động cho toàn bộ thiết bị":
      "A Riasztás nem alkalmazható minden eszközre",
  "Nhà chưa có thiết bị an ninh để áp dụng":
      "Ebben az otthonban nincs alkalmazható biztonsági eszköz",
  "Bạn không có quyền sửa lịch Theo nhà. Hãy chọn Riêng tôi.":
      "Nincs jogosultsága az Otthoni beállítások módosításához. Válassza a Személyes lehetőséget.",
  "Không thể lưu chế độ báo động": "A Riasztási mód nem menthető",
  "Thêm nhắc nhở": "Emlékeztető hozzáadása",
  "Nhắc nhở sẽ nhắc bạn kiểm tra trạng thái an toàn của ngôi nhà vào giờ đã chọn.":
      "Az Emlékeztető a kiválasztott időpontban emlékezteti az otthon biztonsági állapotának ellenőrzésére.",
  "Thêm khung giờ báo động": "Riasztási időszak hozzáadása",
  "Đang sử dụng nhắc nhở riêng của bạn":
      "Saját Emlékeztető-beállítások használata",
  "Đang sử dụng nhắc nhở của chủ nhà":
      "A Tulajdonos Emlékeztető-beállításainak használata",
  "Sửa giờ nhắc nhở": "Emlékeztető időpontjának szerkesztése",
  "Sửa giờ kết thúc báo động": "Riasztás befejezési idejének szerkesztése",
  "Sửa giờ bắt đầu báo động": "Riasztás kezdési idejének szerkesztése",
  "Xoá nhắc nhở": "Emlékeztető törlése",
  "Mỗi 1 giờ": "Óránként",
  "Mỗi 30 phút": "30 percenként",
  "Mỗi 15 phút": "15 percenként",
  "Không báo lại": "Ne ismételje",
  "Báo lại khi vẫn chưa an toàn": "Ismétlés, amíg nem biztonságos",
  "Báo lại mỗi 1 giờ": "Ismétlés óránként",
  "Báo lại mỗi 30 phút": "Ismétlés 30 percenként",
  "Báo lại mỗi 15 phút": "Ismétlés 15 percenként",
  "Quản lý nhà": "Otthon kezelése",
  "Xoá thành viên": "Tag eltávolítása",
  "Đã xoá thành viên": "A tag eltávolítva",
  "Đồng ý": "Rendben",
  "Bạn chắc chắn muốn rời khỏi nhà này?":
      "Biztosan ki szeretne lépni ebből az otthonból?",
  "Xoá thành viên?": "Tag eltávolítása?",
  "Rời khỏi nhà?": "Kilépés az otthonból?",
  "Chỉ chủ nhà mới được thay đổi vai trò":
      "Csak a Tulajdonos módosíthatja a szerepköröket",
  "Bạn không có quyền xoá thành viên này":
      "Nincs jogosultsága ennek a tagnak az eltávolításához",
  "Bạn": "Ön",
  "Không có email": "Nincs e-mail-cím",
  "Chưa có số điện thoại": "Még nincs telefonszám",
  "Không mở được ứng dụng gọi điện": "A telefonalkalmazás nem nyitható meg",
  "Thành viên chưa cập nhật số điện thoại":
      "Ez a tag még nem adott meg telefonszámot",
  "Bảo vệ thủ công đang bật - chỉ tắt khi chuyển về Bình thường":
      "A kézi Védelem be van kapcsolva — csak Normál módra váltással kapcsolható ki",
  "Thời gian lặp": "Ismétlési időköz",
  "Chọn 0 để chỉ báo một lần. Cài đặt này dùng cho cả Bảo vệ thủ công và Tự động Bảo vệ khi rời nhà.":
      "Válassza a 0 értéket az egyszeri riasztáshoz. Ez a beállítás a kézi Védelemre és az automatikus Védelemre távollétkor is vonatkozik.",
  "Lặp báo động khi sự cố vẫn còn":
      "Riasztás ismétlése, amíg a probléma fennáll",
  "Đang được sử dụng": "Jelenleg aktív",
  "Chuyển về sử dụng thông thường": "Visszaállás normál használatra",
  "Chế độ nhà": "Otthon módja",
  "Thiết bị SOS chưa ghi nhận cảnh báo.":
      "Az SOS-eszköz nem rögzített riasztást.",
  "Cảm biến khói chưa ghi nhận bất thường.":
      "A füstérzékelő nem észlelt rendellenességet.",
  "Bạn hoặc thành viên đã chủ động bật Bảo vệ.":
      "Ön vagy egy tag kézzel bekapcsolta a Védelmet.",
  "SafeHome tự bật Bảo vệ vì bạn đã rời khỏi nhà.":
      "A SafeHome automatikusan bekapcsolta a Védelmet, mert Ön elhagyta az otthont.",
  "Nhà đang ở chế độ dùng bình thường.":
      "Az otthon jelenleg normál használatban van.",
  "Bảo vệ thủ công đang bật": "A kézi Védelem be van kapcsolva",
  "Bảo vệ tự động đang bật": "Az automatikus Védelem be van kapcsolva",
  "Bảo vệ đang tắt": "A Védelem ki van kapcsolva",
  "Bạn đã mở ứng dụng gần đây để kiểm tra trạng thái.":
      "Nemrég megnyitotta az alkalmazást az állapot ellenőrzéséhez.",
  "Bạn nên mở ứng dụng định kỳ để kiểm tra quyền, lịch và cảnh báo chưa đọc.":
      "Rendszeresen nyissa meg az alkalmazást az engedélyek, ütemezések és olvasatlan riasztások ellenőrzéséhez.",
  "Sau vài lần sử dụng, SafeHome sẽ đánh giá thói quen kiểm tra ứng dụng tốt hơn.":
      "Néhány használat után a SafeHome pontosabban tudja értékelni az alkalmazás ellenőrzési szokásait.",
  "Tần suất vào ứng dụng ổn": "Az alkalmazás ellenőrzési gyakorisága megfelelő",
  "Đã lâu chưa vào ứng dụng kiểm tra": "Már régen ellenőrizte az alkalmazást",
  "Đang ghi nhận tần suất vào ứng dụng":
      "Az alkalmazás ellenőrzési gyakoriságának rögzítése folyamatban",
  "Cần kiểm tra quyền vị trí luôn luôn và điều kiện chạy nền.":
      "Ellenőrizze a „Mindig” helyengedélyt és a háttérben futás feltételeit.",
  "Thiết bị đủ điều kiện để Auto rời khỏi nhà hoạt động.":
      "Ez az eszköz megfelel az Automatikus távollét követelményeinek.",
  "Bạn có thể bật khi muốn tự động chuyển Bảo vệ lúc rời nhà.":
      "Kapcsolja be, ha azt szeretné, hogy a Védelem automatikusan bekapcsoljon, amikor elhagyja az otthont.",
  "Auto rời khỏi nhà chưa ổn": "Az Automatikus távollét nem áll készen",
  "Auto rời khỏi nhà đã sẵn sàng": "Az Automatikus távollét készen áll",
  "Auto rời khỏi nhà chưa bật": "Az Automatikus távollét nincs bekapcsolva",
  "Nên thêm báo khói, SOS hoặc thiết bị khẩn cấp phù hợp với nhà.":
      "Érdemes füstérzékelőt, SOS- vagy más, az otthonhoz megfelelő vészhelyzeti eszközt hozzáadni.",
  "Chưa có thiết bị khẩn cấp": "Még nincs vészhelyzeti eszköz",
  "Đã có thiết bị khẩn cấp": "Vészhelyzeti eszközök hozzáadva",
  "Nên đặt lịch báo động cho thời gian ngủ hoặc vắng nhà.":
      "Állítson be Riasztási ütemezést alváshoz vagy távolléthez.",
  "Nhà đã có lịch báo động hoặc lịch cảnh báo theo thiết bị.":
      "Az otthon rendelkezik Riasztási ütemezéssel vagy eszközszintű figyelmeztetési ütemezéssel.",
  "Chưa cài lịch báo động": "A Riasztási ütemezés nincs beállítva",
  "Đã cài lịch báo động": "A Riasztási ütemezés be van állítva",
  "Nên có ít nhất một nhắc nhở để không quên kiểm tra nhà.":
      "Állítson be legalább egy Emlékeztetőt, hogy ne felejtse el ellenőrizni az otthont.",
  "Ứng dụng sẽ nhắc bạn kiểm tra nhà theo lịch đã đặt.":
      "Az alkalmazás a beállított ütemezés szerint emlékezteti az otthon ellenőrzésére.",
  "Chưa cài đặt nhắc nhở": "Az Emlékeztető nincs beállítva",
  "Đã cài đặt nhắc nhở": "Az Emlékeztető be van állítva",
  "Hãy mở lại ứng dụng hoặc đăng nhập lại nếu thiết bị không nhận cảnh báo.":
      "Nyissa meg újra az alkalmazást, vagy jelentkezzen be újra, ha ez az eszköz nem kap riasztásokat.",
  "Thiết bị chưa đăng ký nhận cảnh báo":
      "Ez az eszköz nincs regisztrálva riasztások fogadására",
  "Thiết bị nhận cảnh báo bình thường":
      "Ez az eszköz megfelelően fogadja a riasztásokat",
  "iOS quản lý chạy nền chặt hơn Android; hãy giữ thông báo và vị trí luôn luôn nếu dùng Auto rời khỏi nhà.":
      "Az iOS szigorúbban kezeli a háttérben futást, mint az Android; az Automatikus távollét használatakor tartsa bekapcsolva az értesítéseket és a „Mindig” helyhozzáférést.",
  "Cơ chế iOS": "iOS működés",
  "Hãy kiểm tra quyền chạy nền và tự khởi động để cảnh báo không bị trễ.":
      "Ellenőrizze a háttérben futás és az automatikus indítás engedélyét, hogy a riasztások ne késsenek.",
  "Thiết bị đã xác nhận các điều kiện chạy nền quan trọng.":
      "Az eszköz megerősítette a fontos háttérműködési feltételeket.",
  "Cần kiểm tra chạy nền / tự khởi động":
      "Háttérben futás / automatikus indítás ellenőrzése",
  "Chạy nền ổn định": "A háttérben futás stabil",
  "Một số máy Android có thể trì hoãn cảnh báo nếu tối ưu pin còn bật.":
      "Egyes Android-telefonok késleltethetik a riasztásokat, amíg az akkumulátor-optimalizálás be van kapcsolva.",
  "Điện thoại ít có khả năng trì hoãn cảnh báo SafeHome.":
      "A telefon várhatóan nem késlelteti a SafeHome riasztásait.",
  "Chưa tắt tối ưu pin": "Az akkumulátor-optimalizálás még be van kapcsolva",
  "Tối ưu pin không chặn ứng dụng":
      "Az akkumulátor-optimalizálás nem blokkolja az alkalmazást",
  "Auto rời khỏi nhà cần quyền vị trí luôn luôn để chạy ổn định.":
      "Az Automatikus távollét megbízható működéséhez „Mindig” helyengedély szükséges.",
  "Cần cấp quyền vị trí để Auto rời khỏi nhà hoạt động.":
      "Az Automatikus távollét működéséhez helyengedély szükséges.",
  "Dịch vụ vị trí đang tắt nên Auto rời khỏi nhà không ổn định.":
      "A helymeghatározási szolgáltatás ki van kapcsolva, ezért az Automatikus távollét működése bizonytalan lehet.",
  "Chỉ cần quyền này khi dùng Auto rời khỏi nhà.":
      "Erre az engedélyre csak az Automatikus távollét használatakor van szükség.",
  "Chưa cấp vị trí luôn luôn": "A „Mindig” helyhozzáférés nincs engedélyezve",
  "Đã cấp vị trí luôn luôn": "A „Mindig” helyhozzáférés engedélyezve",
  "iOS không mở toàn màn hình như Android; ứng dụng dùng thông báo và âm thanh hệ thống.":
      "Az iOS nem nyit teljes képernyős riasztást úgy, mint az Android; az alkalmazás rendszerértesítéseket és rendszerhangot használ.",
  "Android dùng cảnh báo toàn màn hình; nếu máy chặn, hãy cấp quyền trong cài đặt.":
      "Az Android teljes képernyős riasztásokat használ; ha a telefon blokkolja őket, engedélyezze a beállításokban.",
  "Cảnh báo trên iOS": "iOS-riasztások",
  "Cảnh báo toàn màn hình": "Teljes képernyős riasztások",
  "Cảnh báo có thể không hiển thị nếu thông báo bị tắt.":
      "A riasztások nem jelennek meg, ha az értesítések ki vannak kapcsolva.",
  "Điện thoại có thể nhận thông báo SafeHome.":
      "Ez a telefon képes SafeHome-értesítéseket fogadni.",
  "Chưa bật thông báo": "Az értesítések nincsenek bekapcsolva",
  "Đã bật thông báo": "Az értesítések be vannak kapcsolva",
  "Hệ thống: Sẵn sàng": "Rendszer: Készen áll",
  "Hệ thống: Có thể bỏ lỡ cảnh báo": "Rendszer: Riasztások maradhatnak ki",
  "Cách bạn đang dùng ứng dụng": "Az alkalmazáshasználat módja",
  "Thiết bị của bạn": "Az Ön eszköze",
  "Kiểm tra điện thoại và cách bạn đang dùng ứng dụng.":
      "Ellenőrzi a telefont és az alkalmazáshasználat módját.",
  "Hệ thống SafeHome": "SafeHome rendszer",
  "Hệ thống: Đang kiểm tra...": "Rendszer: Ellenőrzés...",
  "Tên": "Név",
  "Bạn không có quyền thay đổi vị trí nhà":
      "Nincs jogosultsága az otthon helyének módosításához",
  "Hãy bật GPS để đặt vị trí nhà":
      "Kapcsolja be a GPS-t az otthon helyének beállításához",
  "Bạn chưa cấp quyền vị trí": "A helyengedély nincs megadva",
  "Hãy cấp quyền vị trí trong Cài đặt ứng dụng":
      "Adja meg a helyengedélyt az alkalmazás beállításaiban",
  "Đã bật tự động Bảo vệ khi mọi người rời nhà":
      "Az automatikus Védelem, amikor mindenki elhagyja az otthont, be van kapcsolva",
  "Đã tắt tự động Bảo vệ khi mọi người rời nhà":
      "Az automatikus Védelem, amikor mindenki elhagyja az otthont, ki van kapcsolva",
  "Không thể thay đổi trạng thái báo động":
      "A Riasztás állapota nem módosítható",
  "Đã tắt toàn bộ báo động của nhà":
      "Az otthon összes Riasztása ki van kapcsolva",
  "QR này không phải mã xin gia nhập Home":
      "Ez a QR-kód nem Otthon-csatlakozási kód",
  "Thêm Home": "Otthon hozzáadása",
  "Mở cài đặt": "Beállítások megnyitása",
  "Để sau": "Később",
  "SafeHome cần quyền vị trí \"Luôn cho phép\" để nhận biết khi bạn rời hoặc trở về nhà, kể cả khi ứng dụng đang chạy nền.":
      "A SafeHome-nak „Mindig engedélyezett” helyhozzáférésre van szüksége ahhoz, hogy akkor is érzékelje az elindulást vagy hazatérést, amikor az alkalmazás a háttérben fut.",
  "SafeHome hiện chỉ được truy cập vị trí khi bạn đang sử dụng ứng dụng.\n\nHãy chọn quyền Vị trí và chuyển sang \"Luôn cho phép\" để tính năng tự động Bảo vệ khi rời nhà hoạt động khi ứng dụng đang chạy nền.":
      "A SafeHome jelenleg csak az alkalmazás használata közben fér hozzá a helyadatokhoz.\n\nNyissa meg a Hely engedélyt, és válassza a „Mindig engedélyezett” lehetőséget, hogy az automatikus Védelem távollétkor a háttérben is működjön.",
  "Cho phép vị trí luôn luôn": "Helyhozzáférés mindig engedélyezése",
  "Các nhà của bạn sẽ bị xoá.\nCác nhà được chia sẻ sẽ được rời khỏi.":
      "Az Ön otthonai törlődnek.\nKi fog lépni a megosztott otthonokból.",
  "Thao tác này sẽ thay đổi lịch báo động của toàn bộ thiết bị an ninh trong các nhà đã chọn.\n\nNhững thành viên đang sử dụng báo động 'Theo nhà' sẽ bị ảnh hưởng.\nBáo động cá nhân ở chế độ 'Riêng tôi' sẽ không bị thay đổi.":
      "Ez a művelet módosítja a kiválasztott otthonok összes biztonsági eszközének Riasztási ütemezését.\n\nAz Otthoni Riasztási beállításokat használó tagokat érinti.\nA Személyes módban lévő egyéni Riasztások nem változnak.",
  "Thao tác này sẽ thêm nhắc nhở cho các nhà đã chọn.\n\nNhững thành viên đang sử dụng nhắc nhở 'Theo nhà' sẽ bị ảnh hưởng.\nNhắc nhở cá nhân ở chế độ 'Riêng tôi' sẽ không bị thay đổi.":
      "Ez a művelet Emlékeztetőt ad a kiválasztott otthonokhoz.\n\nAz Otthoni Emlékeztető-beállításokat használó tagokat érinti.\nA Személyes módban lévő egyéni Emlékeztetők nem változnak.",
  "Khi bật, các thiết bị an ninh sẽ được giám sát ngay.\n\nTự động Bảo vệ khi rời nhà sẽ tạm dừng. Chế độ này không tự tắt khi có người về nhà và chỉ được tắt khi một thành viên có quyền chủ động chuyển về Bình thường.":
      "Bekapcsoláskor a biztonsági eszközök figyelése azonnal megkezdődik.\n\nAz automatikus Védelem távollétkor szünetel. Ez a mód nem kapcsol ki automatikusan, amikor valaki hazaér, és csak jogosult tag válthatja vissza kézzel Normál módra.",
  "Hành động này sẽ thay đổi thời gian báo động của một số thiết bị trong hôm nay...":
      "Ez a művelet ma megváltoztatja egyes eszközök Riasztási idejét...",
  "Hành động này sẽ tắt toàn bộ báo động của nhà dưới mọi hình thức. Bạn sẽ không còn nhận được cảnh báo khi có nguy hiểm trên điện thoại nữa.":
      "Ez a művelet az otthon minden Riasztását kikapcsolja. A telefon többé nem kap veszélyriasztásokat.",
  "Báo động đang sử dụng chế độ Theo nhà.\n\nBạn sẽ nhận cảnh báo theo lịch báo động chung do Chủ nhà hoặc Quản trị viên thiết lập.":
      "A Riasztás az Otthoni beállításokat használja.\n\nA Tulajdonos vagy Adminisztrátor által beállított közös ütemezés szerint kap riasztásokat.",
  "Báo động đang sử dụng chế độ Riêng tôi.\n\nBạn sẽ nhận cảnh báo theo lịch báo động riêng đã thiết lập cho tài khoản này.":
      "A Riasztás a Személyes beállításokat használja.\n\nAz ehhez a fiókhoz beállított egyéni Riasztási ütemezés szerint kap riasztásokat.",
  "Không thể đăng nhập bằng Google": "A Google-bejelentkezés sikertelen",
  "Không đặt được mật khẩu": "A jelszó nem állítható be",
  "Chấp nhận": "Elfogadás",
  "Cho phép": "Engedélyezés",
  "Không thể chấp nhận lời mời. Vui lòng thử lại.":
      "A meghívás nem fogadható el. Próbálja újra.",
  "Không thể chấp nhận lời xin vào nhà. Vui lòng thử lại.":
      "Az otthonhoz csatlakozási kérelem nem fogadható el. Próbálja újra.",
  "Từ chối": "Elutasítás",
  "Lời mời từ chủ nhà": "Meghívás a Tulajdonostól",
  "Nhận quyền chủ nhà": "Tulajdonjog átvétele",
  "Một người dùng SafeHome": "Egy SafeHome-felhasználó",
  "Lời mời gia nhập": "Csatlakozási meghívás",
  "Lời xin vào nhà": "Otthonhoz csatlakozási kérelem",
  "Nhập HUB ID": "HUB-azonosító megadása",
  "VD: HUB_001": "Pl.: HUB_001",
  "Pair": "Párosítás",
  "Mật khẩu tối thiểu 6 ký tự":
      "A jelszónak legalább 6 karakterből kell állnia",
  "Mật khẩu nhập lại không khớp": "A jelszavak nem egyeznek",
  "Tạo mật khẩu": "Jelszó létrehozása",
  "Mật khẩu mới": "Új jelszó",
  "Nhập lại mật khẩu": "Jelszó újbóli megadása",
  "Xác nhận tắt cảnh báo": "Riasztás leállításának megerősítése",
  "HỦY": "MÉGSE",
  "XÁC NHẬN": "MEGERŐSÍTÉS",
  "CẦN KIỂM TRA": "ELLENŐRZÉST IGÉNYEL",
  "KIỂM TRA NHÀ": "OTTHON ELLENŐRZÉSE",
  "ĐÓNG NHẮC NHỞ": "EMLÉKEZTETŐ BEZÁRÁSA",
  "SafeHome Security Alert": "SafeHome biztonsági riasztás",
  "Hãy chọn quyền vị trí Luôn cho phép trong Cài đặt ứng dụng":
      "Válassza a „Mindig engedélyezett” helyhozzáférést az alkalmazás beállításaiban",
  "Tài khoản Google cần tạo thêm mật khẩu để dùng các chức năng bảo mật.":
      "A Google-fiókhoz további jelszó szükséges a biztonsági funkciók használatához.",
  "Báo động": "Riasztás",
  "Bạn không có quyền thực hiện thao tác này。":
      "Nincs jogosultsága ennek a műveletnek a végrehajtásához.",
  "Cài đặt": "Beállítások",
  "Cập nhật": "Frissítés",
  "Chọn ngôn ngữ": "Nyelv kiválasztása",
  "Chưa có dữ liệu thiết bị để đánh giá": "Nincs értékelhető eszközadat",
  "Chuyển quyền sở hữu cho thành viên khác":
      "Tulajdonjog átruházása másik tagra",
  "Có": "Igen",
  "Cửa đã đóng an toàn": "Az ajtó biztonságosan zárva van",
  "Đã xảy ra lỗi. Vui lòng thử lại.": "Hiba történt. Próbálja újra.",
  "Đang kiểm tra kết nối Hub": "Hub-kapcsolat ellenőrzése",
  "Đang mở khi nhà ở chế độ Bảo vệ":
      "Nyitva, miközben az otthon Védelem módban van",
  "Đang mở trong giờ báo động": "Nyitva a Riasztási időszakban",
  "Đang tải...": "Betöltés...",
  "Hồ sơ, yêu cầu và lời mời tham gia": "Profil, kérelmek és meghívások",
  "Hub chưa gửi trạng thái": "A Hub állapota nem érhető el",
  "Hub mất kết nối": "A Hub nincs csatlakoztatva",
  "Hub tín hiệu bình thường": "A Hub csatlakoztatva",
  "Khóa đang mở khi nhà ở chế độ Bảo vệ":
      "A zár nyitva van, miközben az otthon Védelem módban van",
  "Khóa đang mở trong giờ báo động": "A zár nyitva van a Riasztási időszakban",
  "Không có thông báo": "Nincsenek értesítések",
  "Khu vực nguy hiểm": "Veszélyzóna",
  "Kiểm tra thiết bị trong nhà này": "Az otthon eszközeinek ellenőrzése",
  "Mất điện lưới": "Hálózati áramellátás megszűnt",
  "Mời người khác tham gia nhà này": "Meghívás az otthonhoz való csatlakozásra",
  "Môi trường hiện tại": "Jelenlegi környezet",
  "MQTT mất kết nối": "Az MQTT nincs csatlakoztatva",
  "Ngôn ngữ": "Nyelv",
  "Nhà đã chia sẻ": "Megosztott otthon",
  "Nhà đang hoạt động bình thường": "Az otthon megfelelően működik",
  "Nhập email": "E-mail-cím megadása",
  "Phòng": "Helyiség",
  "Quản trị viên": "Adminisztrátor",
  "Nhắc nhở": "Emlékeztető",
  "SafeHome": "SafeHome",
  "Sóng yếu": "Gyenge jel",
  "SOS": "SOS",
  "Tài khoản & hệ thống": "Fiók és rendszer",
  "Tài khoản cá nhân": "Személyes fiók",
  "Tạo tài khoản": "Fiók létrehozása",
  "Thành viên": "Tag",
  "Thành viên trong nhà": "Az otthon tagjai",
  "Thành viên đang ở trong nhà": "Otthon tartózkodó tagok",
  "Thành viên đang ở ngoài": "Távol lévő tagok",
  "Thành viên chưa xác định vị trí": "Ismeretlen helyű tagok",
  "Thay đổi ngôn ngữ hiển thị": "Megjelenítési nyelv módosítása",
  "Thêm, đổi tên và sắp xếp phòng":
      "Helyiségek hozzáadása, átnevezése és átrendezése",
  "Thiết bị đang được giám sát": "Az eszköz megfigyelés alatt áll",
  "Tiếng Anh": "Angol",
  "Tiếng Hàn": "Koreai",
  "Tiếng Nhật": "Japán",
  "Tiếng Trung": "Kínai",
  "Tiếng Việt": "Vietnámi",
  "Toàn bộ thiết bị": "Összes eszköz",
  "Vai trò": "Szerepkör",
  "Về nhà": "Otthon",
  "Xem và quản lý quyền thành viên": "Tagszerepkörök megtekintése és kezelése",
  "Xóa": "Törlés",
  "Xóa nhà": "Otthon törlése",
  "Xoá toàn bộ dữ liệu và thiết bị": "Minden adat és eszköz törlése",
  "TẮT CẢNH BÁO": "RIASZTÁS KIKAPCSOLÁSA",
  "Đã tạo nhà": "Az otthon létrehozva",
  "Chế độ Bảo vệ thủ công đã bật": "A kézi Védelem mód bekapcsolva",
  "Báo động không lặp lại.": "A riasztás nem ismétlődik.",
  "Báo động lặp sau \$securityModeRepeatMinutes phút nếu sự cố vẫn còn.":
      "A riasztás \$securityModeRepeatMinutes perc múlva megismétlődik, ha a probléma fennáll.",
  "\$actorName đã bật Chế độ Bảo vệ thủ công cho \"\$homeName\". Chế độ này chỉ tắt khi một thành viên có quyền chủ động chuyển về Bình thường. \$repeatMessage":
      "\$actorName bekapcsolta a kézi Védelem módot a(z) „\$homeName” otthonban. Ez a mód csak akkor kapcsol ki, amikor egy jogosult tag visszavált Normál módra. \$repeatMessage",
  "Bạn đã bật báo động cho nhà \"\$homeName\".":
      "Bekapcsolta a Riasztást a(z) „\$homeName” otthonhoz.",
  "Bạn đã tắt toàn bộ báo động của nhà \"\$homeName\".":
      "Kikapcsolta a(z) „\$homeName” otthon összes Riasztását.",
  "Thành viên mới": "Új tag",
  "Thành viên rời nhà": "Egy tag kilépett az otthonból",
  "\$displayMemberName đã rời khỏi nhà \"\$homeName\".":
      "\$displayMemberName kilépett a(z) „\$homeName” otthonból.",
  "\$actorName đã đổi vai trò của \$memberName từ \$oldRoleName thành \$newRoleName trong nhà \"\$homeName\".":
      "\$actorName módosította \$memberName szerepkörét \$oldRoleName értékről \$newRoleName értékre a(z) „\$homeName” otthonban.",
  "Còn \$count tin nhắn chưa đọc": "Még \$count olvasatlan üzenet",
  "Hãy an tâm nghỉ ngơi.": "Nyugodtan pihenhet.",
  "Có thiết bị chưa an toàn.": "Néhány eszköz nincs biztonságos állapotban.",
  "SafeHome đang cập nhật vị trí": "A SafeHome frissíti a helyadatokat",
  "Đang theo dõi để tự động bật Chế độ Bảo vệ.":
      "Megfigyelés az automatikus Védelem bekapcsolásához.",
  "Dùng vị trí để tự động bật Chế độ Bảo vệ khi mọi người rời nhà.":
      "Helyadatok használata a Védelem automatikus bekapcsolásához, amikor mindenki elhagyja az otthont.",
  "CẢNH BÁO SOS": "SOS-RIASZTÁS",
  "CẢNH BÁO KHÓI / CHÁY": "FÜST- / TŰZRIASZTÁS",
  "CẢNH BÁO NGẬP NƯỚC": "VÍZBETÖRÉSI RIASZTÁS",
  "CẢNH BÁO RÒ KHÍ": "GÁZSZIVÁRGÁSI RIASZTÁS",
  "CẢNH BÁO CỬA": "AJTÓRIASZTÁS",
  "CẢNH BÁO AN NINH": "BIZTONSÁGI RIASZTÁS",
  "Không thể xác nhận với SafeHome. Hãy kiểm tra kết nối và thử lại.":
      "A SafeHome-mal való megerősítés sikertelen. Ellenőrizze a kapcsolatot, és próbálja újra.",
  "Chỉ tắt cảnh báo khi bạn đã kiểm tra tình trạng trong nhà.\n\nBạn chắc chắn muốn tắt cảnh báo?":
      "Csak az otthon állapotának ellenőrzése után állítsa le a riasztást.\n\nBiztosan le szeretné állítani a riasztást?",
  "🚨 SafeHome phát hiện cảnh báo": "🚨 A SafeHome riasztást észlelt",
  "Mở SafeHome để kiểm tra ngay.":
      "Nyissa meg a SafeHome-ot az azonnali ellenőrzéshez.",
  "\$count tin nhắn mới": "\$count új üzenet",
  "Tin nhắn HomeChat": "HomeChat-üzenet",
  "\$senderName đã gửi một tin nhắn": "\$senderName üzenetet küldött",
  "Bạn có tin nhắn mới": "Új üzenete érkezett",
  "Chế độ Bảo vệ sẽ chỉ báo động một lần": "A Védelem mód csak egyszer riaszt",
  "Chế độ Bảo vệ sẽ lặp báo động sau \$minutes phút":
      "A Védelem mód \$minutes perc múlva megismétli a riasztást",
  "Đã gửi yêu cầu gia nhập \$count nhà":
      "Csatlakozási kérelmek elküldve \$count otthonhoz",
  "\$requesterName đang xin gia nhập nhà \"\$homeName\".":
      "\$requesterName csatlakozni szeretne a(z) „\$homeName” otthonhoz.",
  "Bạn đã xoá nhà \"\$homeName\".": "Törölte a(z) „\$homeName” otthont.",
  "Bạn đã gửi yêu cầu chuyển quyền chủ nhà \"\$homeName\" cho \$email.":
      "Tulajdonjog-átruházási kérelmet küldött a(z) „\$homeName” otthonhoz a következő címre: \$email.",
  "\$actorName muốn chuyển quyền chủ nhà \"\$homeName\" cho bạn.":
      "\$actorName át szeretné ruházni Önre a(z) „\$homeName” otthon tulajdonjogát.",
  "\$actorName đã mời bạn tham gia nhà \"\$homeName\".":
      "\$actorName meghívta Önt a(z) „\$homeName” otthonhoz.",
  "SafeHome đang xoá thiết bị \"\$deviceName\" khỏi nhà \"\$homeName\".":
      "A SafeHome eltávolítja a(z) „\$deviceName” eszközt a(z) „\$homeName” otthonból.",
  "Thiết bị \"\$deviceName\" đã xuất hiện trong \"\$homeName\".":
      "A(z) „\$deviceName” eszköz megjelent a(z) „\$homeName” otthonban.",
  "Bạn đã tạo nhà \"\$name\".": "Létrehozta a(z) „\$name” otthont.",
  "\$actorName đã cập nhật tên nhà thành \"\$newName\" và thay đổi địa chỉ.":
      "\$actorName frissítette az otthon nevét erre: „\$newName”, és módosította a címét.",
  "\$actorName đã đổi tên nhà thành \"\$newName\".":
      "\$actorName átnevezte az otthont erre: „\$newName”.",
  "\$actorName đã cập nhật địa chỉ của nhà \"\$newName\".":
      "\$actorName frissítette a(z) „\$newName” otthon címét.",
  "\$actorName đã đổi tên thiết bị \"\$oldDeviceName\" thành \"\$newName\" trong nhà \"\$homeName\".":
      "\$actorName átnevezte a(z) „\$oldDeviceName” eszközt erre: „\$newName” a(z) „\$homeName” otthonban.",
  "Đang ghép nối: \$seconds giây": "Párosítás: \$seconds mp",
  "Chế độ thêm thiết bị đã được mở trong nhà \"\$homeName\" trong \$seconds giây.":
      "Az eszközpárosítás \$seconds másodpercre bekapcsolva a(z) „\$homeName” otthonban.",
  "Khoảng thời gian phải nằm trong khung báo động (\$start → \$end)":
      "A szünet időszakának a Riasztási időszakon belül kell lennie (\$start → \$end)",
  "\$passCount/\$total bài test đạt\n\n":
      "\$passCount/\$total teszt sikeres\n\n",
  "\$name chưa cập nhật số điện thoại trong hồ sơ.":
      "\$name nem adott meg telefonszámot a profiljában.",
  "Tin nhắn mới trong \$homeName": "Új üzenet itt: \$homeName",
  "\$current/\$total kết quả": "\$current/\$total találat",
  "Đang trả lời \$name": "Válasz neki: \$name",
  "\"\$name\" phát hiện khói trong \"\$homeName\".":
      "„\$name” füstöt észlelt a(z) „\$homeName” otthonban.",
  "\"\$name\" đã trở lại trạng thái bình thường.":
      "„\$name” visszatért normál állapotba.",
  "\"\$name\" vừa kích hoạt SOS trong \"\$homeName\".":
      "„\$name” SOS-jelzést aktivált a(z) „\$homeName” otthonban.",
  "\"\$name\" đã hết trạng thái SOS.": "„\$name” SOS-állapota megszűnt.",
  "\"\$name\" báo bị tháo/cạy trong \"\$homeName\".":
      "„\$name” manipulációt jelzett a(z) „\$homeName” otthonban.",
  "\"\$name\" đã hết cảnh báo tháo/cạy.":
      "A(z) „\$name” manipulációs riasztása megszűnt.",
  "\"\$name\" đã đóng trong \"\$homeName\".":
      "„\$name” bezárult a(z) „\$homeName” otthonban.",
  "\"\$name\" đang mở trong \"\$homeName\".":
      "„\$name” nyitva van a(z) „\$homeName” otthonban.",
  "\"\$name\" trong \"\$homeName\" đang yếu pin.":
      "A(z) „\$homeName” otthonban lévő „\$name” akkumulátora gyenge.",
  "\"\$name\" trong \"\$homeName\" đã mất kết nối.":
      "A(z) „\$homeName” otthonban lévő „\$name” offline állapotba került.",
  "\"\$name\" trong \"\$homeName\" đã kết nối trở lại.":
      "A(z) „\$homeName” otthonban lévő „\$name” újra online.",
  "\"\$name\" ghi nhận nhiệt độ cao trong \"\$homeName\".":
      "„\$name” magas hőmérsékletet rögzített a(z) „\$homeName” otthonban.",
  "\"\$name\" ghi nhận độ ẩm cao trong \"\$homeName\".":
      "„\$name” magas páratartalmat rögzített a(z) „\$homeName” otthonban.",
  "Có nút SOS vừa được kích hoạt": "Egy SOS-gomb aktiválódott",
  "Có dấu hiệu khói hoặc cháy": "Füst vagy tűz jeleit észlelte a rendszer",
  "Có dấu hiệu ngập nước": "Vízbetörést észlelt a rendszer",
  "Có dấu hiệu rò khí": "Gázszivárgást észlelt a rendszer",
  "Có cửa đang mở hoặc thiết bị bị tháo":
      "Egy ajtó nyitva van, vagy egy eszközt manipuláltak",
  "Có thiết bị đang cảnh báo": "Egy eszköz riasztást jelez",
  "Nếu chưa có ai xác nhận, SafeHome sẽ chuyển sang gọi điện khẩn cấp.":
      "Ha senki sem erősíti meg, a SafeHome segélyhívást kezdeményez.",
  "Báo lại lúc \$time nếu vấn đề chưa được xử lý.":
      "Újabb riasztás ekkor: \$time, ha a probléma nincs megoldva.",
  "Sẽ báo lại theo lịch báo động đã cài nếu vấn đề chưa được xử lý.":
      "A riasztás a beállított Riasztási ütemezés szerint ismétlődik, ha a probléma nincs megoldva.",
  "\"\$deviceName\" đã đóng trong \"\$resolvedHomeName\".":
      "„\$deviceName” bezárult a(z) „\$resolvedHomeName” otthonban.",
  "\"\$deviceName\" đang mở trong \"\$resolvedHomeName\".":
      "„\$deviceName” nyitva van a(z) „\$resolvedHomeName” otthonban.",
  "\$count nhà đã chọn": "\$count otthon kiválasztva",
  "🚨 \$count nhà không an toàn\$suffix":
      "🚨 \$count nem biztonságos otthon\$suffix",
  "⚠️ \$count nhà cần chú ý\$suffix":
      "⚠️ \$count otthon figyelmet igényel\$suffix",
  "✅ \$count nhà an toàn": "✅ \$count biztonságos otthon",
  "\$count nhà đang được theo dõi": "\$count megfigyelt otthon",
  "\$minutes phút": "\$minutes perc",
  "Đã cài nhắc nhở cho \$updatedHomes nhà.":
      "Az Emlékeztető \$updatedHomes otthonhoz beállítva.",
  "Đã cài báo động cho \$updatedDevices thiết bị trong \$updatedHomes nhà.\n":
      "A Riasztás \$updatedDevices eszközhöz beállítva \$updatedHomes otthonban.\n",
  "Đã chia sẻ các nhà bạn có quyền.\n\n\$skipped nhà bị bỏ qua vì bạn không có quyền chia sẻ.":
      "A kezelhető otthonok megosztása megtörtént.\n\n\$skipped otthon kimaradt, mert nincs megosztási jogosultsága.",
  "Đã áp dụng báo động cho \$count thiết bị an ninh":
      "A Riasztás \$count biztonsági eszközre alkalmazva",
  "Áp dụng cùng một lịch cho \$count thiết bị an ninh":
      "Ugyanazon ütemezés alkalmazása \$count biztonsági eszközre",
  "\$count phút trước": "\$count perccel ezelőtt",
  "\$count giờ trước": "\$count órával ezelőtt",
  "\${count}h trước": "\${count} órája",
  "\${hours}h\$minutes' trước": "\${hours} óra \$minutes perce",
  "\$count ngày trước": "\$count nappal ezelőtt",
  "\$count tháng trước": "\$count hónappal ezelőtt",
  "Bạn chắc chắn muốn xoá \$name khỏi nhà này?":
      "Biztosan el szeretné távolítani \$name tagot ebből az otthonból?",
  "\$targetEmail\nXin gia nhập \"\$homeName\"":
      "\$targetEmail\nCsatlakozni szeretne a(z) „\$homeName” otthonhoz",
  "Xin gia nhập \"\$homeName\"":
      "Csatlakozási kérelem a(z) „\$homeName” otthonhoz",
  "Bạn được mời nhận quyền nhà \"\$homeName\"":
      "Meghívást kapott a(z) „\$homeName” otthon tulajdonjogának átvételére",
  "\$ownerEmail\nMời bạn gia nhập \"\$homeName\"":
      "\$ownerEmail\nMeghívta Önt a(z) „\$homeName” otthonhoz",
  "Mời bạn gia nhập \"\$homeName\"": "Meghívás a(z) „\$homeName” otthonhoz",
  "Cần kiểm tra: \$joined": "Figyelmet igényel: \$joined",
  "Cập nhật \$value": "Frissítve: \$value",
  "Hãy thêm thiết bị SafeHome đầu tiên để bắt đầu theo dõi nhà.":
      "Adja hozzá az első SafeHome-eszközt az otthon megfigyelésének megkezdéséhez.",
  "Kiểm tra cảnh báo khẩn cấp trước, sau đó liên hệ thành viên trong nhà nếu cần.":
      "Először ellenőrizze a vészhelyzeti riasztásokat, majd szükség esetén lépjen kapcsolatba az otthon tagjaival.",
  "Không có thành viên nào ở nhà nhưng cửa hoặc khóa đang mở, hãy kiểm tra ngay.":
      "Senki sincs otthon, de egy ajtó vagy zár nyitva van. Ellenőrizze azonnal.",
  "Kiểm tra cửa hoặc khóa đang mở trước khi giữ nhà ở chế độ Bảo vệ.":
      "Ellenőrizze a nyitott ajtót vagy zárat, mielőtt az otthont Védelem módban tartja.",
  "Có thể vẫn có người ở nhà; nếu đúng, nên chuyển về Bình thường.":
      "Lehet, hogy valaki még otthon van; ebben az esetben váltson Normál módra.",
  "Có thành viên chưa xác định vị trí, hãy nhắc họ mở ứng dụng hoặc kiểm tra quyền vị trí.":
      "Néhány tag helye ismeretlen. Kérje meg őket, hogy nyissák meg az alkalmazást, vagy ellenőrizzék a helyengedélyt.",
  "Có thiết bị mất kết nối, hãy kiểm tra pin, nguồn hoặc vị trí đặt thiết bị.":
      "Egy eszköz nincs csatlakoztatva. Ellenőrizze az akkumulátort, az áramellátást vagy az elhelyezést.",
  "Có thiết bị pin yếu, nên thay pin sớm để tránh mất cảnh báo.":
      "Egy eszköz akkumulátora gyenge. Hamarosan cserélje ki, hogy ne maradjanak ki riasztások.",
  "Bạn chưa đặt nhắc nhở, nên tạo lịch nhắc kiểm tra nhà định kỳ.":
      "Nincs beállítva Emlékeztető. Hozzon létre ütemezést az otthon rendszeres ellenőrzéséhez.",
  "Bạn chưa đặt lịch báo động, nên bật bảo vệ theo khung giờ thường vắng nhà.":
      "Nincs beállítva Riasztási ütemezés. Kapcsolja be a Védelmet azokra az időszakokra, amikor általában távol van.",
  "Không có việc cần xử lý ngay, bạn chỉ cần tiếp tục theo dõi trạng thái nhà.":
      "Nincs szükség azonnali teendőre. Folytassa az otthon állapotának figyelését.",
  "Lặp sau \$minutes phút": "Ismétlés \$minutes perc múlva",
  "Đang dùng • \$repeatText": "Aktív • \$repeatText",
  "Giám sát an ninh • \$repeatText": "Biztonsági megfigyelés • \$repeatText",
  "Gia đình: \$mode": "Otthon módja: \$mode",
  "Gợi ý xử lý": "Javasolt teendők",
  "Phát hiện \$count vấn đề cần xử lý":
      "\$count figyelmet igénylő probléma észlelve",
  "Hôm nay các cửa đã được sử dụng \$count lần":
      "Az ajtókat ma \$count alkalommal használták",
  "Đã ghi nhận \$count hoạt động gần đây":
      "\$count közelmúltbeli tevékenység rögzítve",
  "Hệ thống: Cần kiểm tra \$issueCount mục":
      "Rendszer: \$issueCount elem ellenőrzést igényel",
  "FCM token đã sẵn sàng trên điện thoại này.":
      "Az FCM-token készen áll ezen a telefonon.",
  "FCM token đã sẵn sàng, nhưng Auto rời khỏi nhà còn thiếu điều kiện.":
      "Az FCM-token készen áll, de az Automatikus távollét egyik feltétele hiányzik.",
  "Hiện có \$emergencyTotal thiết bị khẩn cấp. Khuyến nghị tối thiểu: báo khói và SOS.":
      "\$emergencyTotal vészhelyzeti eszköz található. Ajánlott minimum: füstérzékelő és SOS.",
  "Bạn chắc chắn muốn chuyển quyền chủ nhà cho:\n\$targetEmail?":
      "Biztosan át szeretné ruházni a tulajdonjogot erre a címre:\n\$targetEmail?",
  "\$count cửa đã đóng an toàn": "\$count ajtó biztonságosan zárva",
  "\$count cửa và khóa đã an toàn": "\$count ajtó és zár biztonságos",
  "\$count thiết bị đang được theo dõi": "\$count megfigyelt eszköz",
  "Cập nhật \$timeText": "Frissítve: \$timeText",
  "Dữ liệu gần nhất cập nhật \$count phút trước":
      "A legfrissebb adatok \$count perccel ezelőtt frissültek",
  "Dữ liệu gần nhất cập nhật \$count giờ trước":
      "A legfrissebb adatok \$count órával ezelőtt frissültek",
  "Thành viên trong nhà: \$count": "Otthon lévő tagok: \$count",
  "Thành viên bên ngoài: \$count": "Távol lévő tagok: \$count",
  "Chưa xác định vị trí: \$count": "Ismeretlen hely: \$count",
  "Môi trường hiện tại: \$environment": "Jelenlegi környezet: \$environment",
  "\$name: Đang mở khi nhà ở chế độ Bảo vệ":
      "\$name: Nyitva, miközben az otthon Védelem módban van",
  "An tâm hơn trong từng ngôi nhà": "Nyugalom minden otthonban",
  "Báo động SafeHome": "SafeHome-riasztás",
  "Có cảnh báo an ninh cần kiểm tra ngay.":
      "Egy biztonsági riasztás azonnali ellenőrzést igényel.",
  "Có cảnh báo cần kiểm tra": "Egy riasztás ellenőrzést igényel",
  "Tự đóng sau \$time": "Automatikusan bezárul \$time múlva",
  "Ngày trong tuần": "A hét napjai",
  "Hoặc": "Vagy",
  "Giờ bắt đầu và kết thúc không được trùng nhau":
      "A kezdési és befejezési idő nem lehet azonos",
  "Giờ kết thúc phải sau thời điểm hiện tại":
      "A befejezési időnek az aktuális idő után kell lennie",
  "Khoảng tạm tắt không hợp lệ": "Érvénytelen riasztásszüneti időszak",
  "Khoảng tạm tắt không trùng với lịch báo động nào đang bật":
      "A szünet időszaka nem esik egyetlen aktív Riasztási ütemezésbe sem",
  "Cài đặt báo động": "Riasztási beállítások",
  "Điều khiển cách cảm biến này kích hoạt cảnh báo.":
      "Beállíthatja, hogyan váltson ki riasztást ez az érzékelő.",
  "Tham gia báo động": "Riasztásokban való részvétel",
  "Tắt để cảm biến không tạo báo động.":
      "Kapcsolja ki, hogy ez az érzékelő ne hozzon létre Riasztást.",
  "Bật còi vật lý": "Fizikai sziréna engedélyezése",
  "Cho phép kích hoạt còi trong nhà.":
      "Engedélyezi a beltéri sziréna bekapcsolását.",
  "Đánh thức màn hình": "Képernyő felébresztése",
  "Hiển thị cảnh báo toàn màn hình trên điện thoại.":
      "Teljes képernyős riasztás megjelenítése a telefonon.",
  "Độ trễ kích hoạt": "Aktiválási késleltetés",
  "Chỉ áp dụng cho cảm biến an ninh.":
      "Csak biztonsági érzékelőkre vonatkozik.",
  "Cảm biến khẩn cấp luôn kích hoạt ngay lập tức.":
      "A vészhelyzeti érzékelők mindig azonnal aktiválódnak.",
  "Ngay lập tức": "Azonnal",
  "giây": "másodperc",
  "Đã lưu cấu hình báo động": "A Riasztási beállítások mentve",
  "Không thể lưu cấu hình báo động": "A Riasztási beállítások nem menthetők",
  "Chỉ chủ nhà và quản trị viên có thể thay đổi cài đặt này.":
      "Csak a Tulajdonos és az Adminisztrátorok módosíthatják ezt a beállítást.",
  "Thông tin chi tiết": "Eszköz részletei",
  "Thông báo báo động": "Riasztási értesítés",
  "Cài đặt nhắc nhở": "Emlékeztető beállításai",
  "Nhắc nhở theo lịch": "Ütemezett Emlékeztető",
  "Danh sách thông báo": "Értesítések listája",
  "Cài đặt thông báo": "Értesítési beállítások",
  "Sử dụng báo động theo lịch đã thiết lập":
      "A Riasztás használata a beállított ütemezés szerint",
  "Chỉ gửi thông báo, không kích hoạt báo động":
      "Csak értesítések küldése, Riasztás aktiválása nélkül",
  "Toàn bộ báo động của nhà đang tắt; hệ thống chỉ gửi thông báo.":
      "Az otthon összes Riasztása ki van kapcsolva; a rendszer csak értesítéseket küld.",
  "Chỉ Chủ nhà có thể bật chế độ này.":
      "Csak a Tulajdonos kapcsolhatja be ezt a módot.",
  "Bật Không bảo vệ?": "Védtelen mód bekapcsolása?",
  "Cảm biến vừa phát hiện một sự kiện.": "Egy érzékelő éppen eseményt észlelt.",
  "Chỉ Chủ nhà mới có quyền bật chế độ Không bảo vệ":
      "Csak a Tulajdonos kapcsolhatja be a Védtelen módot",
  "Đã chuyển nhà sang Không bảo vệ": "Az otthon Védtelen módra váltott",
  "Đã chuyển sang Không bảo vệ nhưng chưa gửi được thông báo":
      "Váltás Védtelen módra megtörtént, de az értesítés nem küldhető el",
  "Giám sát toàn diện": "Teljes körű megfigyelés",
  "Không bảo vệ": "Védtelen",
  "Không bảo vệ đang bật": "A Védtelen mód aktív",
  "Nhà đã chuyển sang Không bảo vệ": "Az otthon Védtelen módra váltott",
  "Thông báo cảm biến": "Érzékelőértesítések",
  "Thông báo thông thường khi cảm biến phát hiện sự kiện.":
      "Normál értesítések, amikor egy érzékelő eseményt észlel.",
  "Tôi hiểu, tiếp tục": "Értem, folytatás",
  "Cảnh báo an ninh đã kết thúc": "A biztonsági riasztás véget ért",
  "Sự cố nguy hiểm đã kết thúc": "A vészhelyzet véget ért",
  "Cảnh báo đã được kết thúc.": "A riasztás véget ért.",
  "Vẫn còn cảnh báo khác đang hoạt động.": "Egy másik riasztás még aktív.",
  "Báo động đã hoạt động trở lại": "A Riasztás ismét aktív",
  "Thời gian tạm dừng báo động đã kết thúc.":
      "A Riasztás szüneteltetési időszaka véget ért.",
  "MQTT đã kết nối trở lại": "Az MQTT újracsatlakozott",
  "Còi báo động đã được tắt": "A fizikai sziréna kikapcsolva",
  "Sự cố vẫn đang được theo dõi.":
      "Az esemény megfigyelése továbbra is folyamatban van.",
  "Bảo vệ tự động đã bật": "Az automatikus Védelem bekapcsolva",
  "Toàn bộ thành viên đã rời khỏi nhà.": "Minden tag elhagyta az otthont.",
  "Bảo vệ tự động đã tắt": "Az automatikus Védelem kikapcsolva",
  "Có thành viên đã trở về nhà.": "Egy tag hazaérkezett.",
  "Thiết bị đã được xoá": "Az eszköz eltávolítva",
  "Không thể xoá thiết bị": "Az eszköz nem távolítható el",
  "Hãy thử lại thao tác xoá thiết bị.":
      "Próbálja meg újra eltávolítani az eszközt.",
  "Chế độ Bảo vệ đã được tắt.": "A Védelem mód ki lett kapcsolva.",
  "Nhà đang ở chế độ Bình thường.": "Az otthon Normál módban van.",
  "Pin thiết bị đã ổn định": "Az eszköz akkumulátora stabil",
  "Hub đã kết nối trở lại": "A Hub újracsatlakozott",
  "Đã chuyển về Bình thường nhưng chưa gửi được thông báo":
      "Visszaváltás Normál módra megtörtént, de az értesítés nem küldhető el",
  "Chung cho nhà": "Közös otthoni",
  "Áp dụng cho toàn bộ thành viên và có thể bật còi vật lý.":
      "Minden tagra vonatkozik, és bekapcsolhatja a fizikai szirénát.",
  "Cá nhân": "Személyes",
  "Lịch cá nhân hoạt động độc lập và không bật còi vật lý.":
      "A személyes ütemezés önállóan működik, és soha nem kapcsolja be a fizikai szirénát.",
  "Cài đặt này chỉ áp dụng cho tài khoản của bạn.":
      "Ez a beállítás csak az Ön fiókjára vonatkozik.",
  "Chỉ chủ nhà và quản trị viên có thể thay đổi phần chung cho nhà.":
      "Csak a Tulajdonos és az Adminisztrátorok módosíthatják a közös otthoni beállításokat.",
  "Tham gia hệ thống báo động": "Részvétel a Riasztási rendszerben",
  "Cảm biến khẩn cấp luôn tham gia hệ thống báo động.":
      "A vészhelyzeti érzékelők mindig részt vesznek a Riasztási rendszerben.",
  "Tắt để thiết bị không tạo bất kỳ báo động nào.":
      "Kapcsolja ki, hogy az eszköz semmilyen Riasztást ne hozzon létre.",
  "Lịch báo động chung": "Közös Riasztási ütemezés",
  "Lịch báo động cá nhân": "Személyes Riasztási ütemezés",
  "Hiển thị cảnh báo toàn màn hình trên điện thoại của bạn.":
      "Teljes képernyős riasztás megjelenítése a telefonján.",
  "Lặp lại cảnh báo": "Riasztás ismétlése",
  "Báo động chung": "Közös Riasztás",
  "Báo động cá nhân": "Személyes Riasztás",
  "Đã cài đặt": "Beállítva",
  "Chưa cài đặt": "Nincs beállítva",
  "Lịch chung và lịch cá nhân hoạt động song song, không còn phải chọn một trong hai.":
      "A közös és személyes ütemezések párhuzamosan működnek; többé nem kell választani közöttük.",
  "Cài nhanh chung": "Közös gyorsbeállítás",
  "Cài nhanh cá nhân": "Személyes gyorsbeállítás",
  "Thiết lập nhanh lịch cá nhân": "Személyes ütemezés gyors beállítása",
  "Thiết lập nhanh lịch chung": "Közös ütemezés gyors beállítása",
  "Lịch này chỉ áp dụng cho bạn và không bật còi vật lý.":
      "Ez az ütemezés csak Önre vonatkozik, és nem kapcsolja be a fizikai szirénát.",
  "Lịch này áp dụng cho toàn bộ thành viên trong nhà.":
      "Ez az ütemezés az otthon minden tagjára vonatkozik.",
  "Đã áp dụng lịch báo động": "A Riasztási ütemezés alkalmazva",
  "Không thể lưu lịch báo động": "A Riasztási ütemezés nem menthető",
  "Nhà chưa có thiết bị an ninh": "Ebben az otthonban nincs biztonsági eszköz",
  "Nhận cảnh báo theo lịch chung của nhà":
      "Riasztások fogadása a közös otthoni ütemezés szerint",
  "Tắt để không nhận thông báo hoặc cảnh báo toàn màn hình từ lịch chung. Còi vật lý của nhà vẫn hoạt động.":
      "Kapcsolja ki, hogy ne kapjon értesítéseket vagy teljes képernyős riasztásokat a közös ütemezésből. Az otthoni sziréna továbbra is működik.",
};

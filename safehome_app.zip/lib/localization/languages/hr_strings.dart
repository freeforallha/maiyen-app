const Map<String, String> hrStrings = {
  "Không tìm thấy người dùng": "Korisnik nije pronađen",
  "Không đọc được số điện thoại": "Nije moguće pročitati telefonski broj",
  "Tin nhắn quá dài": "Poruka je preduga",
  "Không gửi được tin nhắn": "Poruku nije moguće poslati",
  "Bạn không có quyền sửa lịch chung của nhà":
      "Nemate dopuštenje za uređivanje zajedničkog rasporeda doma",
  "Nhà của bạn": "Vaš dom",
  "Tải tin cũ hơn": "Učitaj starije poruke",
  "Nhà chưa đặt tên": "Neimenovani dom",
  "Nhà": "Dom",
  "Chưa có thông tin": "Nema dostupnih podataka",
  "Chưa cập nhật": "Nije ažurirano",
  "Chủ nhà": "Vlasnik",
  "Nhà được chia sẻ": "Dijeljeni dom",
  "Địa chỉ": "Adresa",
  "An ninh ra/vào": "Sigurnost ulaza",
  "Nguy hiểm khẩn cấp": "Hitne opasnosti",
  "Điều khiển & hạ tầng": "Upravljanje i infrastruktura",
  "Môi trường": "Okoliš",
  "Toàn bộ thiết bị SafeHome": "Svi SafeHome uređaji",
  "Cửa ra/vào": "Ulazna vrata",
  "Cửa": "Vrata",
  "Cửa sổ": "Prozor",
  "Cổng": "Kapija",
  "Khóa thông minh": "Pametna brava",
  "Chuyển động": "Kretanje",
  "Hiện diện": "Prisutnost",
  "Rung/chấn động": "Vibracija/udar",
  "Kính vỡ": "Lom stakla",
  "Báo khói": "Detektor dima",
  "Báo nhiệt": "Detektor topline",
  "Khí CO": "Ugljični monoksid",
  "Báo gas": "Detektor plina",
  "Báo ngập/rò nước": "Detektor poplave/curenja vode",
  "Nút SOS": "SOS tipka",
  "Nhiệt độ/Độ ẩm": "Temperatura/Vlažnost",
  "Bụi mịn PM2.5": "Fine čestice PM2.5",
  "CO₂": "CO₂",
  "Chất lượng không khí": "Kvaliteta zraka",
  "Ổ điện thông minh": "Pametna utičnica",
  "Còi báo động": "Sirena",
  "Van thông minh": "Pametni ventil",
  "Camera": "Kamera",
  "Chuông cửa": "Zvono na vratima",
  "Bàn phím an ninh": "Sigurnosna tipkovnica",
  "Bộ mở rộng sóng": "Pojačivač signala",
  "Hub trung tâm": "Središnji hub",
  "Đo điện năng": "Mjerač potrošnje energije",
  "Nguồn dự phòng UPS": "UPS pričuvno napajanje",
  "Thiết bị đang Offline": "Uređaj je izvan mreže",
  "Thiết bị đang Online": "Uređaj je na mreži",
  "lâu không phản hồi": "dugo ne odgovara",
  "Kết nối cần kiểm tra": "Vezu treba provjeriti",
  "Vừa xong": "Upravo sada",
  "Bị tháo": "Otkrivena je neovlaštena manipulacija",
  "Có khói": "Otkriven je dim",
  "Bình thường": "Normalno",
  "Bảo vệ": "Zaštita",
  "Chế độ Bảo vệ": "Način zaštite",
  "Tự động Bảo vệ khi rời nhà": "Automatska zaštita pri odlasku",
  "Đã kích hoạt": "Aktivirano",
  "Sẵn sàng": "Spremno",
  "Đang đóng": "Zatvoreno",
  "Đang mở": "Otvoreno",
  "Rò rỉ gas": "Otkriveno je curenje plina",
  "Phát hiện ngập nước": "Otkriveno je curenje vode",
  "Phát hiện chuyển động": "Otkriveno je kretanje",
  "Không có chuyển động": "Nije otkriveno kretanje",
  "Phát hiện hiện diện": "Otkrivena je prisutnost",
  "Không phát hiện hiện diện": "Nije otkrivena prisutnost",
  "Phát hiện rung/chấn động": "Otkrivena je vibracija/udar",
  "Không có rung bất thường": "Nema neuobičajenih vibracija",
  "Phát hiện kính vỡ": "Otkriven je lom stakla",
  "Không có cảnh báo kính vỡ": "Nema upozorenja za lom stakla",
  "Nhiệt độ nguy hiểm": "Otkrivena je opasna temperatura",
  "Phát hiện khí CO": "Otkriven je ugljični monoksid",
  "Không phát hiện khí CO": "Nije otkriven ugljični monoksid",
  "Khóa đang mở": "Otključano",
  "Khóa đang đóng": "Zaključano",
  "Đang bật": "Uključeno",
  "Bật": "Uključeno",
  "Đang tắt": "Isključeno",
  "Đang theo dõi điện năng": "Prati se potrošnja energije",
  "Đang dùng nguồn dự phòng": "Radi na pričuvnom napajanju",
  "Nguồn điện bình thường": "Mrežno napajanje je normalno",
  "Còi đang bật": "Sirena je aktivna",
  "Còi sẵn sàng": "Sirena je spremna",
  "Van đang mở": "Ventil je otvoren",
  "Van đã đóng": "Ventil je zatvoren",
  "Đang hoạt động": "Radi",
  "Đang theo dõi": "Praćenje je aktivno",
  "Chưa nhận diện": "Neprepoznat uređaj",
  "Chưa có cập nhật": "Još nema ažuriranja",
  "Chưa có thiết bị, hãy nhấn nút + để thêm để bắt đầu duy trì an ninh":
      "Još nema uređaja. Dodirnite + kako biste dodali uređaj i počeli štititi svoj dom.",
  "CHƯA AN TOÀN": "NIJE SIGURNO",
  "ĐÃ AN TOÀN": "SIGURNO",
  "Nhà đang có dấu hiệu cần kiểm tra, bạn nên xem lại các trạng thái bên dưới.":
      "Dom pokazuje znakove koje treba provjeriti. Pregledajte stanja u nastavku.",
  "Nhà đang hoạt động ổn định, bạn có thể yên tâm.":
      "Dom radi normalno. Možete biti mirni.",
  "Không có dấu hiệu khói hoặc SOS bất thường.":
      "Nisu otkriveni neuobičajeni znakovi dima ni SOS aktivnosti.",
  "Chưa có nhiều hoạt động mới để phân tích sâu hơn.":
      "Nema dovoljno nedavnih aktivnosti za dublju analizu.",
  "Hub kết nối bình thường": "Hub je normalno povezan",
  "Cài đặt cảnh báo cho nhà hiện tại": "Postavke upozorenja za ovaj dom",
  "Nhận cảnh báo báo động": "Primaj upozorenja alarma",
  "Đang bật cho tài khoản này": "Omogućeno za ovaj račun",
  "Đang tắt cho tài khoản này": "Onemogućeno za ovaj račun",
  "Hẹn giờ nhắc nhở": "Raspored podsjetnika",
  "Nhắc kiểm tra nhà theo thời gian": "Rasporedi podsjetnike za provjeru doma",
  "Hẹn giờ báo động": "Raspored alarma",
  "Chưa thiết lập": "Nije postavljeno",
  "Chưa thiết lập thời gian": "Nema postavljenog rasporeda",
  "Tổng hợp trạng thái nhà": "Sažetak stanja doma",
  "Cần xử lý ngay": "Potrebna je hitna radnja",
  "Đánh giá tự động": "Automatizirana procjena",
  "Tự động đánh giá": "Automatska procjena",
  "Tổng quan hôm nay": "Današnji pregled",
  "Chưa có dữ liệu tổng quan": "Još nema podataka za pregled",
  "Chưa có dữ liệu trạng thái": "Još nema podataka o stanju",
  "Chưa đủ dữ liệu để đánh giá": "Nema dovoljno podataka za procjenu",
  "Chưa có dữ liệu để đánh giá": "Nema podataka za procjenu",
  "Bấm vào để xem chi tiết": "Dodirnite za prikaz pojedinosti",
  "Nhấn để xem chi tiết...": "Dodirnite za pojedinosti...",
  "Tạm dừng": "Pauzirano",
  "Tắt": "Isključeno",
  "Chi tiết": "Pojedinosti",
  "Tổng hợp trạng thái": "Sažetak stanja",
  "Không an toàn": "Nije sigurno",
  "Cần chú ý": "Zahtijeva pozornost",
  "An toàn": "Sigurno",
  "Không có": "Nema",
  "Đổi tên nhóm": "Preimenuj grupu",
  "Huỷ": "Odustani",
  "Lưu": "Spremi",
  "Thêm": "Dodaj",
  "Xoá": "Izbriši",
  "Đổi tên": "Preimenuj",
  "Nhà của tôi": "Moji domovi",
  "Bỏ chọn toàn bộ nhóm": "Poništi odabir cijele grupe",
  "Chọn toàn bộ nhóm": "Odaberi cijelu grupu",
  "Bỏ chọn": "Poništi odabir",
  "Quay lại": "Natrag",
  "Tìm kiếm": "Pretraži",
  "Đóng tìm kiếm": "Zatvori pretraživanje",
  "Giờ": "Sat",
  "Phút": "Minuta",
  "Đặt nhắc nhở cho nhà": "Postavi podsjetnik za dom",
  "Đặt báo động cho nhà": "Postavi alarm za dom",
  "Xác nhận thay đổi": "Potvrdi promjene",
  "Tiếp tục": "Nastavi",
  "Giờ nhắc nhở": "Vrijeme podsjetnika",
  "Giờ bắt đầu báo động": "Vrijeme početka alarma",
  "Giờ kết thúc báo động": "Vrijeme završetka alarma",
  "Không có nhà nào đủ điều kiện để cài":
      "Nema dostupnih domova koji ispunjavaju uvjete",
  "Cài đặt hoàn tất": "Postavljanje je dovršeno",
  "Xác nhận rời nhà": "Potvrdi napuštanje doma",
  "Xác nhận xoá nhà": "Potvrdi brisanje doma",
  "Nhập mật khẩu": "Unesite lozinku",
  "Mật khẩu tài khoản": "Lozinka računa",
  "Rời khỏi nhà": "Napusti dom",
  "Xoá nhà": "Izbriši dom",
  "Sai mật khẩu": "Pogrešna lozinka",
  "Đã rời khỏi home": "Napustili ste dom",
  "Đã cập nhật": "Ažurirano",
  "Tìm home...": "Pretraži domove...",
  "Đặt vị trí nhà và bật bảo vệ tự động":
      "Postavite lokaciju doma i uključite automatsku zaštitu",
  "Chuyển quyền chủ nhà hoặc xoá nhà": "Prenesite vlasništvo ili izbrišite dom",
  "Đặt nhắc nhở / báo động nhà đã chọn":
      "Postavite podsjetnik/alarm za odabrane domove",
  "Chia sẻ nhà đã chọn": "Dijeli odabrane domove",
  "Mở danh sách chia sẻ nhà": "Otvori popis dijeljenja doma",
  "Xoá các nhà đã chọn?": "Izbrisati odabrane domove?",
  "Các nhà đã chọn sẽ bị xoá vĩnh viễn.":
      "Odabrani domovi bit će trajno izbrisani.",
  "Hoặc quét QR để xin gia nhập các nhà đã chọn":
      "Ili skenirajte QR kod kako biste zatražili pristup odabranim domovima",
  "Email người nhận": "E-adresa primatelja",
  "Chia sẻ": "Dijeli",
  "Email chưa đăng ký": "E-adresa nije registrirana",
  "Chia sẻ hoàn tất": "Dijeljenje je dovršeno",
  "Mở List chia sẻ nhà": "Otvori popis dijeljenja doma",
  "Không có nhà nào bạn có quyền quản lý":
      "Ne upravljate nijednim od odabranih domova",
  "Chưa share cho ai": "Još nije podijeljeno ni s kim",
  "Tìm nhà": "Pretraži domove",
  "Xoá các nhà đã chọn ?": "Izbrisati odabrane domove?",
  "Thông báo Home": "Obavijesti doma",
  "Thông báo nhà": "Obavijesti doma",
  "Vai trò thành viên đã thay đổi": "Uloga člana je promijenjena",
  "Xoá tất cả thông báo?": "Izbrisati sve obavijesti?",
  "Toàn bộ thông báo nhà sẽ bị xoá.": "Sve obavijesti doma bit će izbrisane.",
  "Chưa có thông báo nào": "Još nema obavijesti",
  "Chưa có thông báo": "Nema obavijesti",
  "Vuốt lên để tải thêm": "Povucite prema gore za učitavanje još sadržaja",
  "Không có thiết bị": "Nema uređaja",
  "Chỉ chủ nhà mới được xoá nhà": "Samo vlasnik može izbrisati ovaj dom",
  "Chỉ chủ nhà mới được chuyển quyền": "Samo vlasnik može prenijeti vlasništvo",
  "Lưu ý khi bật báo động": "Napomena pri uključivanju alarma",
  "Báo động đã được bật": "Alarm je omogućen",
  "Đã hiểu": "Razumijem",
  "Lưu ý tạm tắt báo động": "Napomena o privremenom pauziranju alarma",
  "Đã bật báo động": "Alarm je uključen",
  "Đã tắt báo động": "Alarm je isključen",
  "Tắt báo động": "Zaustavi alarm",
  "Cả ngày": "Cijeli dan",
  "Bạn không có quyền thực hiện thao tác này.":
      "Nemate dopuštenje za ovu radnju.",
  "Không thể hoàn tất thao tác. Vui lòng thử lại.":
      "Radnju nije moguće dovršiti. Pokušajte ponovno.",
  "QR gia nhập nhiều nhà không hợp lệ":
      "Nevažeći QR kod za pridruživanje više domova",
  "Bạn đang là chủ các nhà này": "Vi ste vlasnik ovih domova",
  "Một người dùng": "Jedan korisnik",
  "Yêu cầu gia nhập nhà": "Zahtjev za pridruživanje domu",
  "Đã gửi yêu cầu gia nhập nhà": "Zahtjev za pridruživanje je poslan",
  "QR gia nhập không hợp lệ": "Nevažeći QR kod za pridruživanje",
  "Bạn đang là chủ nhà này": "Već ste vlasnik ovog doma",
  "QR này không phải mã xin gia nhập nhà":
      "Ovaj QR kod nije kod za pridruživanje domu",
  "Bạn không có quyền thêm thiết bị": "Nemate dopuštenje za dodavanje uređaja",
  "Đã mở chế độ thêm thiết bị": "Omogućeno je uparivanje uređaja",
  "Rời khỏi Home này?": "Napustiti ovaj dom?",
  "Nhà này và toàn bộ thiết bị bên trong sẽ bị xoá vĩnh viễn.":
      "Ovaj dom i svi uređaji u njemu bit će trajno izbrisani.",
  "Đã xoá nhà": "Dom je izbrisan",
  "QR của nhà này": "QR kod ovog doma",
  "Người khác quét mã này để gửi yêu cầu gia nhập nhà.":
      "Drugi mogu skenirati ovaj kod kako bi zatražili pristup domu.",
  "Chia sẻ nhà": "Dijeli dom",
  "Quét QR để xin gia nhập nhà": "Skenirajte QR kod za pridruživanje domu",
  "Quét QR xin gia nhập nhà": "Skenirajte QR kod za pridruživanje domu",
  "Đưa mã QR chia sẻ nhà vào khung hình":
      "Postavite QR kod dijeljenog doma unutar okvira",
  "Mã QR này do chủ nhà chia sẻ": "Ovaj QR kod dijeli vlasnik doma",
  "Nhập mã mời": "Unesite kod pozivnice",
  "Gửi yêu cầu gia nhập": "Pošalji zahtjev za pridruživanje",
  "QR này không phải mã thiết bị": "Ovaj QR kod nije kod uređaja",
  "Xin gia nhập nhà": "Zatraži pridruživanje domu",
  "Quét mã QR chia sẻ nhà": "Skeniraj QR kod za dijeljenje doma",
  "Mời thành viên bằng mã QR": "Pozovi člana QR kodom",
  "Không thể share cho chính bạn": "Ne možete dijeliti sami sa sobom",
  "Lời mời chia sẻ nhà": "Pozivnica za dijeljenje doma",
  "Đã share home": "Dom je podijeljen",
  "Chuyển quyền chủ nhà": "Prenesi vlasništvo",
  "Không thể chuyển quyền cho chính bạn":
      "Ne možete prenijeti vlasništvo sami sebi",
  "Không tìm thấy user": "Korisnik nije pronađen",
  "Không tìm thấy tài khoản": "Račun nije pronađen",
  "Xác nhận chuyển quyền": "Potvrdi prijenos vlasništva",
  "Chuyển": "Prenesi",
  "Xác nhận mật khẩu": "Potvrdi lozinku",
  "Yêu cầu chuyển quyền chủ nhà": "Zahtjev za prijenos vlasništva",
  "Đã gửi yêu cầu chuyển quyền": "Zahtjev za prijenos je poslan",
  "Đã gửi yêu cầu chuyển quyền chủ nhà":
      "Zahtjev za prijenos vlasništva je poslan",
  "Bạn không có quyền xoá thiết bị": "Nemate dopuštenje za brisanje uređaja",
  "Xóa Device?": "Izbrisati ovaj uređaj?",
  "Đã gửi yêu cầu xoá thiết bị": "Zahtjev za brisanje uređaja je poslan",
  "Đang xoá thiết bị": "Brisanje uređaja",
  "Đăng xuất?": "Odjaviti se?",
  "Thêm nhà": "Dodaj dom",
  "Thêm nhà mới": "Dodaj novi dom",
  "Tạo nhà mới": "Izradi novi dom",
  "Tạo một ngôi nhà mới của bạn": "Izradite novi dom",
  "Quét mã QR được chủ nhà chia sẻ":
      "Skenirajte QR kod koji je podijelio vlasnik",
  "Tên nhà": "Naziv doma",
  "Số điện thoại": "Telefonski broj",
  "Nam": "Muško",
  "Nữ": "Žensko",
  "Ngày": "Dan",
  "Tháng": "Mjesec",
  "Năm": "Godina",
  "Thông tin cá nhân": "Osobni podaci",
  "Thiết lập tài khoản": "Postavljanje računa",
  "Vui lòng nhập đủ thông tin": "Unesite sve potrebne podatke",
  "Không thể lưu thông tin": "Podatke nije moguće spremiti",
  "Đã lưu thông tin": "Podaci su spremljeni",
  "Lỗi lưu profile": "Profil nije moguće spremiti",
  "Thêm số điện thoại để dùng cho các trường hợp khẩn cấp":
      "Dodajte telefonski broj za hitne slučajeve",
  "Hoàn tất": "Gotovo",
  "Đã tạo nhà mới": "Novi dom je izrađen",
  "Về muộn": "Vraćam se kasno",
  "Ra ngoài": "Izlazim",
  "Khác": "Ostalo",
  "⏸️ Tạm tắt báo động hôm nay": "⏸️ Privremeno pauziraj alarm danas",
  "Chọn giờ bắt đầu tạm tắt": "Odaberite vrijeme početka pauze",
  "Từ": "Od",
  "Từ giờ": "Od sada",
  "Chọn giờ kết thúc tạm tắt": "Odaberite vrijeme završetka pauze",
  "Đến": "Do",
  "Đến giờ": "Do vremena",
  "Xoá lịch tạm tắt": "Izbriši raspored pauze",
  "Xóa lịch tạm tắt": "Izbriši raspored pauze",
  "Giới tính": "Spol",
  "SĐT": "Telefon",
  "Ngày sinh": "Datum rođenja",
  "Yêu cầu & lời mời": "Zahtjevi i pozivnice",
  "Xem lời mời chia sẻ và xin gia nhập":
      "Pregledajte pozivnice za dijeljenje i zahtjeve za pridruživanje",
  "Cài đặt bảo mật": "Sigurnosne postavke",
  "Quyền báo động toàn màn hình": "Dopuštenje za alarm preko cijelog zaslona",
  "Báo động toàn màn hình": "Alarm preko cijelog zaslona",
  "Đã được cấp quyền": "Dopuštenje je odobreno",
  "Chưa được cấp quyền": "Dopuštenje nije odobreno",
  "Mở cài đặt hệ thống": "Otvori postavke sustava",
  "Đăng xuất": "Odjava",
  "Thoát tài khoản khỏi thiết bị này": "Odjavi račun s ovog uređaja",
  "Không có yêu cầu hoặc lời mời nào": "Nema zahtjeva ni pozivnica",
  "Xoá tài khoản": "Izbriši račun",
  "Hành động này sẽ xoá toàn bộ dữ liệu:":
      "Ova će radnja izbrisati sve podatke:",
  "Nhà và thiết bị": "Domovi i uređaji",
  "Chia sẻ và quyền truy cập": "Dijeljenje i pristup",
  "Toàn bộ dữ liệu liên quan": "Svi povezani podaci",
  "Mật khẩu xác nhận": "Lozinka za potvrdu",
  "Đã xoá tài khoản": "Račun je izbrisan",
  "Xoá thất bại": "Brisanje nije uspjelo",
  "Lỗi xoá tài khoản": "Račun nije moguće izbrisati",
  "Tình trạng": "Stanje",
  "Tháo/Lắp": "Zaštita od neovlaštene manipulacije",
  "Pin": "Baterija",
  "Tín hiệu": "Signal",
  "Chưa liên kết": "Nije povezano",
  "Liên lạc cuối": "Posljednji kontakt",
  "Event cuối": "Posljednji događaj",
  "Sự kiện cuối": "Posljednji događaj",
  "Lần kích hoạt cuối": "Posljednje aktiviranje",
  "Thiết bị không còn tồn tại": "Uređaj više ne postoji",
  "Mất kết nối": "Veza je prekinuta",
  "Online": "Na mreži",
  "Offline": "Izvan mreže",
  "Loại thiết bị": "Vrsta uređaja",
  "Nhiệt độ": "Temperatura",
  "Độ ẩm": "Vlažnost",
  "Công suất": "Snaga",
  "Điện áp": "Napon",
  "Dòng điện": "Struja",
  "Điện năng": "Energija",
  "Cường độ rung": "Jačina vibracije",
  "Góc nghiêng": "Kut nagiba",
  "Độ mở van": "Otvorenost ventila",
  "Nguồn dự phòng": "Pričuvno napajanje",
  "Ngập/rò nước": "Poplava/curenje vode",
  "Phát hiện khói": "Otkriven je dim",
  "Quản lý phòng": "Upravljanje prostorijama",
  "Bạn không có quyền quản lý phòng":
      "Nemate dopuštenje za upravljanje prostorijama",
  "Đổi tên phòng": "Preimenuj prostoriju",
  "Tên phòng": "Naziv prostorije",
  "Xoá phòng": "Izbriši prostoriju",
  "Thiết bị trong phòng này sẽ được chuyển về Chưa phân phòng.":
      "Uređaji u ovoj prostoriji bit će premješteni u Nedodijeljeno.",
  "Thêm phòng": "Dodaj prostoriju",
  "Ví dụ: Phòng khách": "Primjer: Dnevni boravak",
  "Phòng khách": "Dnevni boravak",
  "Tên phòng đã tồn tại": "Naziv prostorije već postoji",
  "Chưa phân phòng": "Nedodijeljeno",
  "Phòng mặc định": "Zadana prostorija",
  "Phát hiện bất thường": "Otkrivena je neuobičajena aktivnost",
  "Phát hiện cạy phá": "Otkriven je pokušaj provale",
  "Tamper detected": "Otkrivena je neovlaštena manipulacija",
  "Tamper cleared": "Upozorenje za manipulaciju je uklonjeno",
  "Door opened": "Vrata su otvorena",
  "Door closed": "Vrata su zatvorena",
  "Motion detected": "Otkriveno je kretanje",
  "Battery low": "Niska razina baterije",
  "Device offline": "Uređaj je izvan mreže",
  "Device online": "Uređaj je na mreži",
  "Cửa mở": "Vrata su otvorena",
  "Cửa đóng": "Vrata su zatvorena",
  "Chưa đặt vị trí nhà": "Lokacija doma nije postavljena",
  "Đặt vị trí nhà tại đây": "Postavite lokaciju doma ovdje",
  "Hãy đặt vị trí nhà trước khi bật tự động Bảo vệ":
      "Postavite lokaciju doma prije uključivanja automatske zaštite",
  "Bán kính bảo vệ mặc định: 150 m": "Zadani polumjer zaštite: 150 m",
  "Mỗi thành viên sẽ cần cấp quyền vị trí Luôn cho phép để trạng thái rời/đến nhà hoạt động khi ứng dụng chạy nền.":
      "Svaki član mora dopustiti lokaciju Uvijek kako bi stanje odsutan/kod kuće radilo u pozadini.",
  "Lưu cài đặt": "Spremi postavke",
  "Đã đặt vị trí nhà": "Lokacija doma je postavljena",
  "Đang lấy vị trí...": "Dohvaćanje lokacije...",
  "Đang lưu...": "Spremanje...",
  "Đổi tên hiển thị": "Promijeni prikazano ime",
  "Cập nhật thông tin nhà": "Ažuriraj podatke o domu",
  "Nhập địa chỉ của nhà": "Unesite adresu doma",
  "Lưu thay đổi": "Spremi promjene",
  "Tên này chỉ hiển thị riêng trên tài khoản của bạn.":
      "Ovo se ime prikazuje samo na vašem računu.",
  "Tên và địa chỉ sẽ được cập nhật cho toàn bộ thành viên trong nhà.":
      "Naziv i adresa ažurirat će se za sve članove doma.",
  "Một thành viên": "Jedan član",
  "Đã cập nhật thông tin nhà": "Podaci o domu su ažurirani",
  "Thay tên": "Preimenuj",
  "Đã đổi tên thiết bị": "Uređaj je preimenovan",
  "Chưa chọn nhà để kiểm tra": "Nije odabran dom za provjeru",
  "Hãy thực hiện kiểm tra bằng tài khoản Owner":
      "Izvršite provjeru pomoću računa Vlasnika",
  "Không đọc được dữ liệu nhà": "Nije moguće pročitati podatke doma",
  "Nhà cần có ít nhất một thiết bị để test":
      "Dom mora imati barem jedan uređaj za testiranje",
  "Đóng": "Zatvori",
  "Đã thiết lập": "Postavljeno",
  "Quét QR": "Skeniraj QR kod",
  "Quét QR để thêm thiết bị": "Skenirajte QR kod za dodavanje uređaja",
  "Nhập HUB ID thủ công": "Ručno unesite HUB ID",
  "Bạn không có quyền sắp xếp phòng":
      "Nemate dopuštenje za promjenu redoslijeda prostorija",
  "Cảnh báo khói": "Upozorenje na dim",
  "Cập nhật thiết bị": "Ažuriranje uređaja",
  "Cửa đang mở": "Vrata su otvorena",
  "Cửa đã đóng": "Vrata su zatvorena",
  "Firebase Rules: CÓ LỖI": "Firebase Rules: PRONAĐENI SU PROBLEMI",
  "Firebase Rules: ĐẠT": "Firebase Rules: PROLAZ",
  "Giờ không hợp lệ": "Nevažeće vrijeme",
  "Khôi phục mật khẩu": "Ponovno postavi lozinku",
  "Nhập email của bạn": "Unesite svoju adresu e-pošte",
  "Gửi": "Pošalji",
  "Đã gửi email khôi phục": "Poruka za ponovno postavljanje lozinke je poslana",
  "Không gửi được email": "Nije moguće poslati e-poštu",
  "Vui lòng nhập email và mật khẩu": "Unesite adresu e-pošte i lozinku",
  "Mật khẩu xác nhận không khớp": "Lozinke se ne podudaraju",
  "Không thể tạo tài khoản": "Nije moguće izraditi račun",
  "Sai tài khoản": "Netočan račun",
  "Email đã tồn tại": "Adresa e-pošte već postoji",
  "Mật khẩu quá yếu": "Lozinka je preslaba",
  "Sai email hoặc mật khẩu": "Netočna adresa e-pošte ili lozinka",
  "Lỗi đăng nhập": "Pogreška pri prijavi",
  "Email": "E-pošta",
  "Mật khẩu": "Lozinka",
  "Ghi nhớ tài khoản": "Zapamti račun",
  "Đăng nhập": "Prijava",
  "Đăng ký mới": "Izradi račun",
  "Quên mật khẩu?": "Zaboravili ste lozinku?",
  "Chưa có tài khoản? Đăng ký": "Nemate račun? Registrirajte se",
  "Đã có tài khoản? Đăng nhập": "Već imate račun? Prijavite se",
  "Tính năng đang được phát triển": "Ova je značajka u razvoju",
  "Thông báo": "Obavijest",
  "Chat trong nhà": "Razgovor doma",
  "Tìm kiếm tin nhắn": "Pretraži poruke",
  "Xem thành viên": "Prikaži članove",
  "Tìm nội dung hoặc tên người gửi": "Pretraži sadržaj ili ime pošiljatelja",
  "Xoá từ khoá": "Izbriši ključnu riječ",
  "Không có kết quả": "Nema rezultata",
  "Tìm ngôn ngữ": "Pretraži jezik",
  "Kết quả trước": "Prethodni rezultat",
  "Kết quả tiếp theo": "Sljedeći rezultat",
  "Chưa có tin nhắn": "Još nema poruka",
  "Không tìm thấy thành viên phù hợp": "Nisu pronađeni odgovarajući članovi",
  "Nhắc đến trong tin nhắn": "Spomeni u poruci",
  "Huỷ trả lời": "Odustani od odgovora",
  "Nhắn gì đó...": "Napišite poruku...",
  "Gọi điện": "Nazovi",
  "Báo động thiết bị": "Alarm uređaja",
  "Chế độ áp dụng": "Način primjene",
  "Theo nhà": "Prema rasporedu doma",
  "Riêng tôi": "Samo za mene",
  "Dùng lịch chung do Chủ nhà hoặc Quản trị viên thiết lập":
      "Koristi zajednički raspored koji je postavio Vlasnik ili Administrator",
  "Dùng lịch riêng chỉ áp dụng cho tài khoản của bạn":
      "Koristi osobni raspored koji vrijedi samo za vaš račun",
  "Thiết lập nhanh báo động": "Brzo postavljanje alarma",
  "Thiết lập nhanh toàn bộ thiết bị": "Brzo postavljanje svih uređaja",
  "Áp dụng cho toàn bộ thiết bị": "Primijeni na sve uređaje",
  "Bắt đầu": "Početak",
  "Kết thúc": "Kraj",
  "Thời gian lặp lại": "Interval ponavljanja",
  "Không lặp lại": "Bez ponavljanja",
  "Quét QR HUB": "Skeniraj QR kod HUB-a",
  "Đưa mã QR vào giữa khung": "Postavite QR kod u sredinu okvira",
  "Đang áp dụng...": "Primjena...",
  "Hôm nay đã ghi nhận cảnh báo SOS": "Danas je zabilježeno SOS upozorenje",
  "Hôm nay đã ghi nhận cảnh báo khói": "Danas je zabilježeno upozorenje na dim",
  "Khói đã an toàn": "Opasnost od dima je prestala",
  "Không tìm thấy nhà của thông báo này":
      "Dom povezan s ovom obavijesti nije pronađen",
  "Không tìm thấy thiết bị trong nhà này": "Uređaj nije pronađen u ovom domu",
  "Một chủ nhà": "Jedan vlasnik",
  "Ngôi nhà đang hoạt động ổn định": "Dom radi normalno",
  "Nhiệt độ cao": "Visoka temperatura",
  "OK": "U redu",
  "Pin yếu": "Slaba baterija",
  "SOS đã kết thúc": "SOS je završen",
  "SOS được kích hoạt": "SOS je aktiviran",
  "Tamper bình thường": "Nije otkriveno neovlašteno uklanjanje",
  "Thiết bị bị tháo": "Otkriveno je uklanjanje uređaja",
  "Thiết bị mới": "Novi uređaj",
  "Thiết bị offline": "Uređaj je izvan mreže",
  "Thiết bị online": "Uređaj je na mreži",
  "Báo động kích hoạt": "Alarm je aktiviran",
  "Báo động đã tắt": "Alarm je isključen",
  "Tạm tắt báo động hôm nay": "Privremeno pauziraj alarm za danas",
  "Độ ẩm cao": "Visoka vlažnost",
  "Thử lại": "Pokušaj ponovno",
  "Không thể tải dữ liệu tài khoản": "Nije moguće učitati podatke računa",
  "Không": "Ne",
  "Đã chia sẻ nhà thành công.": "Domovi su uspješno podijeljeni.",
  "Tìm nhà...": "Pretraži domove...",
  "Đã rời khỏi nhà": "Napustili ste dom",
  "Bạn sẽ rời khỏi các nhà được chia sẻ.": "Napustit ćete dijeljene domove.",
  "Các nhà của bạn sẽ bị xoá.\n": "Vaši će domovi biti izbrisani.\n",
  "Thao tác này sẽ thay đổi lịch báo động của toàn bộ thiết bị an ninh trong các nhà đã chọn.\n\n":
      "Ova će radnja promijeniti raspored alarma za sve sigurnosne uređaje u odabranim domovima.\n\n",
  "Thao tác này sẽ thêm nhắc nhở cho các nhà đã chọn.\n\n":
      "Ova će radnja dodati podsjetnik odabranim domovima.\n\n",
  "Xác nhận thay đổi báo động": "Potvrdi promjene alarma",
  "Xác nhận thay đổi nhắc nhở": "Potvrdi promjene podsjetnika",
  "Lặp lại khi sự cố vẫn còn": "Ponavljaj dok problem traje",
  "Thời gian lặp lại báo động": "Vrijeme ponavljanja alarma",
  "VD: Mr Chung": "Npr. g. Chung",
  "🏡 Chưa có nhà nào": "🏡 Još nema domova",
  "Vẫn chuyển về Bình thường": "Ipak prebaci na Normalno",
  "Tự động Bảo vệ khi rời nhà vẫn đang bật. Nếu mọi thành viên vẫn ở ngoài, hệ thống có thể tự bật lại Bảo vệ sau vài phút.":
      "Automatska Zaštita pri odlasku i dalje je uključena. Ako su svi članovi još uvijek izvan doma, sustav može ponovno uključiti Zaštitu nakon nekoliko minuta.",
  "Chuyển về Bình thường?": "Prebaciti na Normalno?",
  "Khi bật, các thiết bị an ninh sẽ được giám sát ngay.\n\n":
      "Kada je uključeno, sigurnosni uređaji odmah će se nadzirati.\n\n",
  "Bật Bảo vệ thủ công?": "Uključiti ručni način Zaštite?",
  "Hành động này sẽ thay đổi thời gian báo động của một số thiết bị ":
      "Ova će radnja danas promijeniti vrijeme alarma za neke uređaje",
  "Hành động này sẽ tắt toàn bộ báo động của nhà ":
      "Ova će radnja isključiti sve alarme doma",
  "Tắt toàn bộ báo động?": "Isključiti sve alarme?",
  "Không xoá được lịch tạm tắt báo động":
      "Nije moguće izbrisati raspored pauze alarma",
  "Không lưu được tạm tắt báo động": "Nije moguće spremiti pauzu alarma",
  "Không gửi được yêu cầu xoá": "Nije moguće poslati zahtjev za brisanje",
  "Không lưu được cài đặt": "Nije moguće spremiti postavku",
  "Không lấy được vị trí hiện tại": "Nije moguće dohvatiti trenutačnu lokaciju",
  "Không thể xác nhận tài khoản hiện tại":
      "Nije moguće potvrditi trenutačni račun",
  "Mật khẩu không đúng": "Netočna lozinka",
  "Không thể xác nhận mật khẩu": "Nije moguće potvrditi lozinku",
  "Chỉ Chủ nhà hoặc Quản trị viên mới có quyền thay đổi lặp báo động":
      "Samo Vlasnik ili Administrator može promijeniti ponavljanje alarma",
  "Không lưu được thời gian lặp báo động":
      "Nije moguće spremiti vrijeme ponavljanja alarma",
  "Chỉ Chủ nhà hoặc Quản trị viên mới có quyền thay đổi Chế độ Bảo vệ":
      "Samo Vlasnik ili Administrator može promijeniti način Zaštite",
  "Không thể thay đổi chế độ nhà": "Nije moguće promijeniti način doma",
  "Đã bật Bảo vệ nhưng chưa gửi được thông báo":
      "Način Zaštite je uključen, ali obavijest nije moguće poslati",
  "Đã bật Chế độ Bảo vệ thủ công": "Ručni način Zaštite je uključen",
  "Đã chuyển nhà về Bình thường": "Dom je vraćen na Normalno",
  "60 phút": "60 minuta",
  "30 phút": "30 minuta",
  "15 phút": "15 minuta",
  "Bạn đang xem lịch của chủ nhà. Chọn Riêng tôi để tự đặt lịch báo động.":
      "Pregledavate raspored Vlasnika. Odaberite Samo za mene kako biste postavili vlastiti raspored Alarma.",
  "Chọn giờ kết thúc báo động": "Odaberite vrijeme završetka alarma",
  "Chọn giờ bắt đầu báo động": "Odaberite vrijeme početka alarma",
  "Bạn không có quyền sửa lịch báo động của nhà":
      "Nemate dopuštenje za uređivanje rasporeda Alarma ovog doma",
  "Không thể áp dụng báo động cho toàn bộ thiết bị":
      "Nije moguće primijeniti Alarm na sve uređaje",
  "Nhà chưa có thiết bị an ninh để áp dụng":
      "Ovaj dom nema sigurnosnih uređaja na koje se postavka može primijeniti",
  "Bạn không có quyền sửa lịch Theo nhà. Hãy chọn Riêng tôi.":
      "Nemate dopuštenje za uređivanje postavki Doma. Odaberite Samo za mene.",
  "Không thể lưu chế độ báo động": "Nije moguće spremiti način Alarma",
  "Thêm nhắc nhở": "Dodaj podsjetnik",
  "Nhắc nhở sẽ nhắc bạn kiểm tra trạng thái an toàn của ngôi nhà vào giờ đã chọn.":
      "Podsjetnik će vas u odabrano vrijeme podsjetiti da provjerite sigurnosno stanje doma.",
  "Thêm khung giờ báo động": "Dodaj vremenski raspon alarma",
  "Đang sử dụng nhắc nhở riêng của bạn":
      "Koriste se vaše osobne postavke Podsjetnika",
  "Đang sử dụng nhắc nhở của chủ nhà":
      "Koriste se postavke Podsjetnika Vlasnika",
  "Sửa giờ nhắc nhở": "Uredi vrijeme podsjetnika",
  "Sửa giờ kết thúc báo động": "Uredi vrijeme završetka alarma",
  "Sửa giờ bắt đầu báo động": "Uredi vrijeme početka alarma",
  "Xoá nhắc nhở": "Izbriši podsjetnik",
  "Mỗi 1 giờ": "Svakog sata",
  "Mỗi 30 phút": "Svakih 30 minuta",
  "Mỗi 15 phút": "Svakih 15 minuta",
  "Không báo lại": "Ne ponavljaj",
  "Báo lại khi vẫn chưa an toàn": "Ponavljaj dok stanje nije sigurno",
  "Báo lại mỗi 1 giờ": "Ponavljaj svakog sata",
  "Báo lại mỗi 30 phút": "Ponavljaj svakih 30 minuta",
  "Báo lại mỗi 15 phút": "Ponavljaj svakih 15 minuta",
  "Quản lý nhà": "Upravljanje domom",
  "Xoá thành viên": "Ukloni člana",
  "Đã xoá thành viên": "Član je uklonjen",
  "Đồng ý": "U redu",
  "Bạn chắc chắn muốn rời khỏi nhà này?":
      "Jeste li sigurni da želite napustiti ovaj dom?",
  "Xoá thành viên?": "Ukloniti člana?",
  "Rời khỏi nhà?": "Napustiti dom?",
  "Chỉ chủ nhà mới được thay đổi vai trò": "Samo Vlasnik može mijenjati uloge",
  "Bạn không có quyền xoá thành viên này":
      "Nemate dopuštenje za uklanjanje ovog člana",
  "Bạn": "Vi",
  "Không có email": "Nema adrese e-pošte",
  "Chưa có số điện thoại": "Još nema telefonskog broja",
  "Không mở được ứng dụng gọi điện":
      "Nije moguće otvoriti aplikaciju za pozive",
  "Thành viên chưa cập nhật số điện thoại":
      "Ovaj član još nije dodao telefonski broj",
  "Bảo vệ thủ công đang bật - chỉ tắt khi chuyển về Bình thường":
      "Ručna Zaštita je uključena — može se isključiti samo povratkom na Normalno",
  "Thời gian lặp": "Interval ponavljanja",
  "Chọn 0 để chỉ báo một lần. Cài đặt này dùng cho cả Bảo vệ thủ công và Tự động Bảo vệ khi rời nhà.":
      "Odaberite 0 za jednokratno upozorenje. Ova postavka vrijedi za ručnu Zaštitu i automatsku Zaštitu pri odlasku.",
  "Lặp báo động khi sự cố vẫn còn": "Ponavljaj alarm dok problem traje",
  "Đang được sử dụng": "Trenutačno se koristi",
  "Chuyển về sử dụng thông thường": "Vrati na uobičajenu upotrebu",
  "Chế độ nhà": "Način doma",
  "Thiết bị SOS chưa ghi nhận cảnh báo.":
      "SOS uređaj nije zabilježio upozorenje.",
  "Cảm biến khói chưa ghi nhận bất thường.":
      "Senzor dima nije otkrio nepravilnosti.",
  "Bạn hoặc thành viên đã chủ động bật Bảo vệ.":
      "Vi ili drugi član ručno ste uključili Zaštitu.",
  "SafeHome tự bật Bảo vệ vì bạn đã rời khỏi nhà.":
      "SafeHome je automatski uključio Zaštitu jer ste napustili dom.",
  "Nhà đang ở chế độ dùng bình thường.":
      "Dom je trenutačno u uobičajenom načinu rada.",
  "Bảo vệ thủ công đang bật": "Ručna Zaštita je uključena",
  "Bảo vệ tự động đang bật": "Automatska Zaštita je uključena",
  "Bảo vệ đang tắt": "Zaštita je isključena",
  "Bạn đã mở ứng dụng gần đây để kiểm tra trạng thái.":
      "Nedavno ste otvorili aplikaciju kako biste provjerili stanje.",
  "Bạn nên mở ứng dụng định kỳ để kiểm tra quyền, lịch và cảnh báo chưa đọc.":
      "Redovito otvarajte aplikaciju kako biste provjerili dopuštenja, rasporede i nepročitana upozorenja.",
  "Sau vài lần sử dụng, SafeHome sẽ đánh giá thói quen kiểm tra ứng dụng tốt hơn.":
      "Nakon nekoliko korištenja SafeHome će moći bolje procijeniti vašu naviku provjeravanja aplikacije.",
  "Tần suất vào ứng dụng ổn": "Učestalost provjere aplikacije je dobra",
  "Đã lâu chưa vào ứng dụng kiểm tra":
      "Prošlo je dosta vremena od posljednje provjere aplikacije",
  "Đang ghi nhận tần suất vào ứng dụng":
      "Bilježi se učestalost provjere aplikacije",
  "Cần kiểm tra quyền vị trí luôn luôn và điều kiện chạy nền.":
      "Provjerite dopuštenje lokacije „Uvijek” i uvjete rada u pozadini.",
  "Thiết bị đủ điều kiện để Auto rời khỏi nhà hoạt động.":
      "Ovaj uređaj ispunjava uvjete za Automatski odlazak.",
  "Bạn có thể bật khi muốn tự động chuyển Bảo vệ lúc rời nhà.":
      "Uključite ako želite da se Zaštita automatski aktivira kada napustite dom.",
  "Auto rời khỏi nhà chưa ổn": "Automatski odlazak nije spreman",
  "Auto rời khỏi nhà đã sẵn sàng": "Automatski odlazak je spreman",
  "Auto rời khỏi nhà chưa bật": "Automatski odlazak nije uključen",
  "Nên thêm báo khói, SOS hoặc thiết bị khẩn cấp phù hợp với nhà.":
      "Preporučuje se dodati senzor dima, SOS ili drugi hitni uređaj prikladan za dom.",
  "Chưa có thiết bị khẩn cấp": "Još nema hitnog uređaja",
  "Đã có thiết bị khẩn cấp": "Dodani su hitni uređaji",
  "Nên đặt lịch báo động cho thời gian ngủ hoặc vắng nhà.":
      "Postavite raspored Alarma za vrijeme spavanja ili kada niste kod kuće.",
  "Nhà đã có lịch báo động hoặc lịch cảnh báo theo thiết bị.":
      "Dom ima raspored Alarma ili raspored upozorenja po uređajima.",
  "Chưa cài lịch báo động": "Raspored Alarma nije postavljen",
  "Đã cài lịch báo động": "Raspored Alarma je postavljen",
  "Nên có ít nhất một nhắc nhở để không quên kiểm tra nhà.":
      "Postavite barem jedan Podsjetnik kako ne biste zaboravili provjeriti dom.",
  "Ứng dụng sẽ nhắc bạn kiểm tra nhà theo lịch đã đặt.":
      "Aplikacija će vas podsjetiti da provjerite dom prema postavljenom rasporedu.",
  "Chưa cài đặt nhắc nhở": "Podsjetnik nije postavljen",
  "Đã cài đặt nhắc nhở": "Podsjetnik je postavljen",
  "Hãy mở lại ứng dụng hoặc đăng nhập lại nếu thiết bị không nhận cảnh báo.":
      "Ponovno otvorite aplikaciju ili se ponovno prijavite ako ovaj uređaj ne prima upozorenja.",
  "Thiết bị chưa đăng ký nhận cảnh báo":
      "Ovaj uređaj nije registriran za upozorenja",
  "Thiết bị nhận cảnh báo bình thường": "Ovaj uređaj normalno prima upozorenja",
  "iOS quản lý chạy nền chặt hơn Android; hãy giữ thông báo và vị trí luôn luôn nếu dùng Auto rời khỏi nhà.":
      "iOS strože upravlja radom u pozadini od Androida; ostavite obavijesti i lokaciju „Uvijek” uključenima ako koristite Automatski odlazak.",
  "Cơ chế iOS": "Ponašanje sustava iOS",
  "Hãy kiểm tra quyền chạy nền và tự khởi động để cảnh báo không bị trễ.":
      "Provjerite dopuštenje rada u pozadini i automatsko pokretanje kako upozorenja ne bi kasnila.",
  "Thiết bị đã xác nhận các điều kiện chạy nền quan trọng.":
      "Uređaj je potvrdio važne uvjete rada u pozadini.",
  "Cần kiểm tra chạy nền / tự khởi động":
      "Provjeri rad u pozadini / automatsko pokretanje",
  "Chạy nền ổn định": "Rad u pozadini je stabilan",
  "Một số máy Android có thể trì hoãn cảnh báo nếu tối ưu pin còn bật.":
      "Neki Android telefoni mogu odgoditi upozorenja dok je optimizacija baterije uključena.",
  "Điện thoại ít có khả năng trì hoãn cảnh báo SafeHome.":
      "Mala je vjerojatnost da će telefon odgađati SafeHome upozorenja.",
  "Chưa tắt tối ưu pin": "Optimizacija baterije još je uključena",
  "Tối ưu pin không chặn ứng dụng":
      "Optimizacija baterije ne blokira aplikaciju",
  "Auto rời khỏi nhà cần quyền vị trí luôn luôn để chạy ổn định.":
      "Automatski odlazak treba dopuštenje lokacije „Uvijek” za pouzdan rad.",
  "Cần cấp quyền vị trí để Auto rời khỏi nhà hoạt động.":
      "Za rad Automatskog odlaska potrebno je dopuštenje lokacije.",
  "Dịch vụ vị trí đang tắt nên Auto rời khỏi nhà không ổn định.":
      "Usluga lokacije je isključena pa Automatski odlazak možda neće pouzdano raditi.",
  "Chỉ cần quyền này khi dùng Auto rời khỏi nhà.":
      "Ovo dopuštenje potrebno je samo kada koristite Automatski odlazak.",
  "Chưa cấp vị trí luôn luôn": "Lokacija „Uvijek” nije dopuštena",
  "Đã cấp vị trí luôn luôn": "Lokacija „Uvijek” je dopuštena",
  "iOS không mở toàn màn hình như Android; ứng dụng dùng thông báo và âm thanh hệ thống.":
      "iOS ne otvara upozorenja preko cijelog zaslona kao Android; aplikacija koristi sistemske obavijesti i zvuk.",
  "Android dùng cảnh báo toàn màn hình; nếu máy chặn, hãy cấp quyền trong cài đặt.":
      "Android koristi upozorenja preko cijelog zaslona; ako ih telefon blokira, dopustite ih u postavkama.",
  "Cảnh báo trên iOS": "Upozorenja na iOS-u",
  "Cảnh báo toàn màn hình": "Upozorenja preko cijelog zaslona",
  "Cảnh báo có thể không hiển thị nếu thông báo bị tắt.":
      "Upozorenja se možda neće prikazati ako su obavijesti isključene.",
  "Điện thoại có thể nhận thông báo SafeHome.":
      "Ovaj telefon može primati SafeHome obavijesti.",
  "Chưa bật thông báo": "Obavijesti nisu uključene",
  "Đã bật thông báo": "Obavijesti su uključene",
  "Hệ thống: Sẵn sàng": "Sustav: Spreman",
  "Hệ thống: Có thể bỏ lỡ cảnh báo":
      "Sustav: Neka upozorenja mogu biti propuštena",
  "Cách bạn đang dùng ứng dụng": "Kako koristite aplikaciju",
  "Thiết bị của bạn": "Vaš uređaj",
  "Kiểm tra điện thoại và cách bạn đang dùng ứng dụng.":
      "Provjerava telefon i način na koji koristite aplikaciju.",
  "Hệ thống SafeHome": "Sustav SafeHome",
  "Hệ thống: Đang kiểm tra...": "Sustav: Provjera...",
  "Tên": "Ime",
  "Bạn không có quyền thay đổi vị trí nhà":
      "Nemate dopuštenje za promjenu lokacije doma",
  "Hãy bật GPS để đặt vị trí nhà":
      "Uključite GPS kako biste postavili lokaciju doma",
  "Bạn chưa cấp quyền vị trí": "Niste dali dopuštenje lokacije",
  "Hãy cấp quyền vị trí trong Cài đặt ứng dụng":
      "Dopustite lokaciju u postavkama aplikacije",
  "Đã bật tự động Bảo vệ khi mọi người rời nhà":
      "Automatska Zaštita kada svi napuste dom je uključena",
  "Đã tắt tự động Bảo vệ khi mọi người rời nhà":
      "Automatska Zaštita kada svi napuste dom je isključena",
  "Không thể thay đổi trạng thái báo động":
      "Nije moguće promijeniti stanje Alarma",
  "Đã tắt toàn bộ báo động của nhà": "Svi Alarmi doma su isključeni",
  "QR này không phải mã xin gia nhập Home":
      "Ovaj QR kod nije kod za pridruživanje Domu",
  "Thêm Home": "Dodaj Dom",
  "Mở cài đặt": "Otvori postavke",
  "Để sau": "Kasnije",
  "SafeHome cần quyền vị trí \"Luôn cho phép\" để nhận biết khi bạn rời hoặc trở về nhà, kể cả khi ứng dụng đang chạy nền.":
      "SafeHome treba dopuštenje lokacije „Uvijek dopusti” kako bi prepoznao kada odlazite ili se vraćate kući, čak i dok aplikacija radi u pozadini.",
  "SafeHome hiện chỉ được truy cập vị trí khi bạn đang sử dụng ứng dụng.\n\nHãy chọn quyền Vị trí và chuyển sang \"Luôn cho phép\" để tính năng tự động Bảo vệ khi rời nhà hoạt động khi ứng dụng đang chạy nền.":
      "SafeHome trenutačno može pristupati lokaciji samo dok koristite aplikaciju.\n\nOtvorite dopuštenje Lokacija i odaberite „Uvijek dopusti” kako bi automatska Zaštita pri odlasku radila i u pozadini.",
  "Cho phép vị trí luôn luôn": "Uvijek dopusti lokaciju",
  "Các nhà của bạn sẽ bị xoá.\nCác nhà được chia sẻ sẽ được rời khỏi.":
      "Vaši će domovi biti izbrisani.\nNapustit ćete dijeljene domove.",
  "Thao tác này sẽ thay đổi lịch báo động của toàn bộ thiết bị an ninh trong các nhà đã chọn.\n\nNhững thành viên đang sử dụng báo động 'Theo nhà' sẽ bị ảnh hưởng.\nBáo động cá nhân ở chế độ 'Riêng tôi' sẽ không bị thay đổi.":
      "Ova će radnja promijeniti raspored Alarma za sve sigurnosne uređaje u odabranim domovima.\n\nTo će utjecati na članove koji koriste Alarm „Prema domu”.\nOsobni Alarmi u načinu „Samo za mene” neće se promijeniti.",
  "Thao tác này sẽ thêm nhắc nhở cho các nhà đã chọn.\n\nNhững thành viên đang sử dụng nhắc nhở 'Theo nhà' sẽ bị ảnh hưởng.\nNhắc nhở cá nhân ở chế độ 'Riêng tôi' sẽ không bị thay đổi.":
      "Ova će radnja dodati Podsjetnik odabranim domovima.\n\nTo će utjecati na članove koji koriste Podsjetnik „Prema domu”.\nOsobni Podsjetnici u načinu „Samo za mene” neće se promijeniti.",
  "Khi bật, các thiết bị an ninh sẽ được giám sát ngay.\n\nTự động Bảo vệ khi rời nhà sẽ tạm dừng. Chế độ này không tự tắt khi có người về nhà và chỉ được tắt khi một thành viên có quyền chủ động chuyển về Bình thường.":
      "Kada je uključeno, sigurnosni uređaji odmah će se nadzirati.\n\nAutomatska Zaštita pri odlasku bit će pauzirana. Ovaj način ne isključuje se automatski kada se netko vrati kući i može ga isključiti samo ovlašteni član ručnim povratkom na Normalno.",
  "Hành động này sẽ thay đổi thời gian báo động của một số thiết bị trong hôm nay...":
      "Ova će radnja danas promijeniti vrijeme Alarma za neke uređaje...",
  "Hành động này sẽ tắt toàn bộ báo động của nhà dưới mọi hình thức. Bạn sẽ không còn nhận được cảnh báo khi có nguy hiểm trên điện thoại nữa.":
      "Ova će radnja isključiti sve Alarme doma. Više nećete primati upozorenja na opasnost na telefonu.",
  "Báo động đang sử dụng chế độ Theo nhà.\n\nBạn sẽ nhận cảnh báo theo lịch báo động chung do Chủ nhà hoặc Quản trị viên thiết lập.":
      "Alarm koristi način „Prema domu”.\n\nPrimat ćete upozorenja prema zajedničkom rasporedu koji je postavio Vlasnik ili Administrator.",
  "Báo động đang sử dụng chế độ Riêng tôi.\n\nBạn sẽ nhận cảnh báo theo lịch báo động riêng đã thiết lập cho tài khoản này.":
      "Alarm koristi način „Samo za mene”.\n\nPrimat ćete upozorenja prema osobnom rasporedu Alarma za ovaj račun.",
  "Không thể đăng nhập bằng Google": "Prijava putem Googlea nije uspjela",
  "Không đặt được mật khẩu": "Nije moguće postaviti lozinku",
  "Chấp nhận": "Prihvati",
  "Cho phép": "Dopusti",
  "Không thể chấp nhận lời mời. Vui lòng thử lại.":
      "Nije moguće prihvatiti pozivnicu. Pokušajte ponovno.",
  "Không thể chấp nhận lời xin vào nhà. Vui lòng thử lại.":
      "Nije moguće prihvatiti zahtjev za pridruživanje domu. Pokušajte ponovno.",
  "Từ chối": "Odbij",
  "Lời mời từ chủ nhà": "Pozivnica Vlasnika",
  "Nhận quyền chủ nhà": "Preuzmi vlasništvo nad domom",
  "Một người dùng SafeHome": "Korisnik SafeHomea",
  "Lời mời gia nhập": "Pozivnica za pridruživanje",
  "Lời xin vào nhà": "Zahtjev za pridruživanje domu",
  "Nhập HUB ID": "Unesite HUB ID",
  "VD: HUB_001": "Npr.: HUB_001",
  "Pair": "Upari",
  "Mật khẩu tối thiểu 6 ký tự": "Lozinka mora imati najmanje 6 znakova",
  "Mật khẩu nhập lại không khớp": "Lozinke se ne podudaraju",
  "Tạo mật khẩu": "Izradi lozinku",
  "Mật khẩu mới": "Nova lozinka",
  "Nhập lại mật khẩu": "Ponovno unesite lozinku",
  "Xác nhận tắt cảnh báo": "Potvrdi zaustavljanje alarma",
  "HỦY": "ODUSTANI",
  "XÁC NHẬN": "POTVRDI",
  "CẦN KIỂM TRA": "POTREBNA PROVJERA",
  "KIỂM TRA NHÀ": "PROVJERI DOM",
  "ĐÓNG NHẮC NHỞ": "ZATVORI PODSJETNIK",
  "SafeHome Security Alert": "SafeHome sigurnosno upozorenje",
  "Hãy chọn quyền vị trí Luôn cho phép trong Cài đặt ứng dụng":
      "Odaberite dopuštenje lokacije „Uvijek dopusti” u postavkama aplikacije",
  "Tài khoản Google cần tạo thêm mật khẩu để dùng các chức năng bảo mật.":
      "Google račun treba dodatnu lozinku za korištenje sigurnosnih značajki.",
  "Báo động": "Alarm",
  "Bạn không có quyền thực hiện thao tác này。":
      "Nemate dopuštenje za izvođenje ove radnje.",
  "Cài đặt": "Postavke",
  "Cập nhật": "Ažuriraj",
  "Chọn ngôn ngữ": "Odaberite jezik",
  "Chưa có dữ liệu thiết bị để đánh giá":
      "Nema podataka o uređajima za procjenu",
  "Chuyển quyền sở hữu cho thành viên khác":
      "Prenesi vlasništvo na drugog člana",
  "Có": "Da",
  "Cửa đã đóng an toàn": "Vrata su sigurno zatvorena",
  "Đã xảy ra lỗi. Vui lòng thử lại.":
      "Došlo je do pogreške. Pokušajte ponovno.",
  "Đang kiểm tra kết nối Hub": "Provjera veze s Hubom",
  "Đang mở khi nhà ở chế độ Bảo vệ": "Otvoreno dok je dom u načinu Zaštite",
  "Đang mở trong giờ báo động": "Otvoreno tijekom vremena Alarma",
  "Đang tải...": "Učitavanje...",
  "Hồ sơ, yêu cầu và lời mời tham gia": "Profil, zahtjevi i pozivnice",
  "Hub chưa gửi trạng thái": "Stanje Huba nije dostupno",
  "Hub mất kết nối": "Hub nije povezan",
  "Hub tín hiệu bình thường": "Hub je povezan",
  "Khóa đang mở khi nhà ở chế độ Bảo vệ":
      "Brava je otključana dok je dom u načinu Zaštite",
  "Khóa đang mở trong giờ báo động":
      "Brava je otključana tijekom vremena Alarma",
  "Không có thông báo": "Nema obavijesti",
  "Khu vực nguy hiểm": "Opasna zona",
  "Kiểm tra thiết bị trong nhà này": "Provjeri uređaje u ovom domu",
  "Mất điện lưới": "Mrežno napajanje je prekinuto",
  "Mời người khác tham gia nhà này": "Pozovi nekoga da se pridruži ovom domu",
  "Môi trường hiện tại": "Trenutačno okruženje",
  "MQTT mất kết nối": "MQTT nije povezan",
  "Ngôn ngữ": "Jezik",
  "Nhà đã chia sẻ": "Dijeljeni dom",
  "Nhà đang hoạt động bình thường": "Dom radi normalno",
  "Nhập email": "Unesite adresu e-pošte",
  "Phòng": "Prostorija",
  "Quản trị viên": "Administrator",
  "Nhắc nhở": "Podsjetnik",
  "SafeHome": "SafeHome",
  "Sóng yếu": "Slab signal",
  "SOS": "SOS",
  "Tài khoản & hệ thống": "Račun i sustav",
  "Tài khoản cá nhân": "Osobni račun",
  "Tạo tài khoản": "Izradi račun",
  "Thành viên": "Član",
  "Thành viên trong nhà": "Članovi doma",
  "Thành viên đang ở trong nhà": "Članovi koji su trenutačno kod kuće",
  "Thành viên đang ở ngoài": "Članovi koji su trenutačno izvan doma",
  "Thành viên chưa xác định vị trí": "Članovi s nepoznatom lokacijom",
  "Thay đổi ngôn ngữ hiển thị": "Promijeni jezik prikaza",
  "Thêm, đổi tên và sắp xếp phòng":
      "Dodaj, preimenuj i promijeni redoslijed prostorija",
  "Thiết bị đang được giám sát": "Uređaj se nadzire",
  "Tiếng Anh": "Engleski",
  "Tiếng Hàn": "Korejski",
  "Tiếng Nhật": "Japanski",
  "Tiếng Trung": "Kineski",
  "Tiếng Việt": "Vijetnamski",
  "Toàn bộ thiết bị": "Svi uređaji",
  "Vai trò": "Uloga",
  "Về nhà": "Kod kuće",
  "Xem và quản lý quyền thành viên": "Pregledaj i upravljaj ulogama članova",
  "Xóa": "Izbriši",
  "Xóa nhà": "Izbriši dom",
  "Xoá toàn bộ dữ liệu và thiết bị": "Izbriši sve podatke i uređaje",
  "TẮT CẢNH BÁO": "ISKLJUČI UPOZORENJE",
  "Đã tạo nhà": "Dom je izrađen",
  "Chế độ Bảo vệ thủ công đã bật": "Ručni način Zaštite je uključen",
  "Báo động không lặp lại.": "Alarm se neće ponavljati.",
  "Báo động lặp sau \$securityModeRepeatMinutes phút nếu sự cố vẫn còn.":
      "Alarm se ponavlja nakon \$securityModeRepeatMinutes minuta ako problem i dalje traje.",
  "\$actorName đã bật Chế độ Bảo vệ thủ công cho \"\$homeName\". Chế độ này chỉ tắt khi một thành viên có quyền chủ động chuyển về Bình thường. \$repeatMessage":
      "\$actorName je uključio ručni način Zaštite za „\$homeName”. Ovaj se način može isključiti samo kada ga ovlašteni član ručno vrati na Normalno. \$repeatMessage",
  "Bạn đã bật báo động cho nhà \"\$homeName\".":
      "Uključili ste Alarm za dom „\$homeName”.",
  "Bạn đã tắt toàn bộ báo động của nhà \"\$homeName\".":
      "Isključili ste sve Alarme doma „\$homeName”.",
  "Thành viên mới": "Novi član",
  "Thành viên rời nhà": "Član je napustio dom",
  "\$displayMemberName đã rời khỏi nhà \"\$homeName\".":
      "\$displayMemberName je napustio dom „\$homeName”.",
  "\$actorName đã đổi vai trò của \$memberName từ \$oldRoleName thành \$newRoleName trong nhà \"\$homeName\".":
      "\$actorName je promijenio ulogu člana \$memberName iz \$oldRoleName u \$newRoleName u domu „\$homeName”.",
  "Còn \$count tin nhắn chưa đọc": "Još \$count nepročitanih poruka",
  "Hãy an tâm nghỉ ngơi.": "Možete mirno odmoriti.",
  "Có thiết bị chưa an toàn.": "Neki uređaji nisu sigurni.",
  "SafeHome đang cập nhật vị trí": "SafeHome ažurira lokaciju",
  "Đang theo dõi để tự động bật Chế độ Bảo vệ.":
      "Nadzire se radi automatskog uključivanja načina Zaštite.",
  "Dùng vị trí để tự động bật Chế độ Bảo vệ khi mọi người rời nhà.":
      "Koristi lokaciju za automatsko uključivanje načina Zaštite kada svi napuste dom.",
  "CẢNH BÁO SOS": "SOS UPOZORENJE",
  "CẢNH BÁO KHÓI / CHÁY": "UPOZORENJE NA DIM / POŽAR",
  "CẢNH BÁO NGẬP NƯỚC": "UPOZORENJE NA POPLAVU",
  "CẢNH BÁO RÒ KHÍ": "UPOZORENJE NA CURENJE PLINA",
  "CẢNH BÁO CỬA": "UPOZORENJE ZA VRATA",
  "CẢNH BÁO AN NINH": "SIGURNOSNO UPOZORENJE",
  "Không thể xác nhận với SafeHome. Hãy kiểm tra kết nối và thử lại.":
      "Potvrda sa SafeHomeom nije uspjela. Provjerite vezu i pokušajte ponovno.",
  "Chỉ tắt cảnh báo khi bạn đã kiểm tra tình trạng trong nhà.\n\nBạn chắc chắn muốn tắt cảnh báo?":
      "Isključite upozorenje tek nakon što provjerite stanje doma.\n\nJeste li sigurni da želite isključiti upozorenje?",
  "🚨 SafeHome phát hiện cảnh báo": "🚨 SafeHome je otkrio upozorenje",
  "Mở SafeHome để kiểm tra ngay.":
      "Otvorite SafeHome kako biste odmah provjerili.",
  "\$count tin nhắn mới": "\$count novih poruka",
  "Tin nhắn HomeChat": "HomeChat poruka",
  "\$senderName đã gửi một tin nhắn": "\$senderName je poslao poruku",
  "Bạn có tin nhắn mới": "Imate novu poruku",
  "Chế độ Bảo vệ sẽ chỉ báo động một lần":
      "Način Zaštite upozorit će samo jednom",
  "Chế độ Bảo vệ sẽ lặp báo động sau \$minutes phút":
      "Način Zaštite ponovit će upozorenje nakon \$minutes minuta",
  "Đã gửi yêu cầu gia nhập \$count nhà":
      "Poslani su zahtjevi za pridruživanje za \$count domova",
  "\$requesterName đang xin gia nhập nhà \"\$homeName\".":
      "\$requesterName traži pridruživanje domu „\$homeName”.",
  "Bạn đã xoá nhà \"\$homeName\".": "Izbrisali ste dom „\$homeName”.",
  "Bạn đã gửi yêu cầu chuyển quyền chủ nhà \"\$homeName\" cho \$email.":
      "Poslali ste zahtjev za prijenos vlasništva doma „\$homeName” na \$email.",
  "\$actorName muốn chuyển quyền chủ nhà \"\$homeName\" cho bạn.":
      "\$actorName vam želi prenijeti vlasništvo nad domom „\$homeName”.",
  "\$actorName đã mời bạn tham gia nhà \"\$homeName\".":
      "\$actorName vas je pozvao da se pridružite domu „\$homeName”.",
  "SafeHome đang xoá thiết bị \"\$deviceName\" khỏi nhà \"\$homeName\".":
      "SafeHome uklanja uređaj „\$deviceName” iz doma „\$homeName”.",
  "Thiết bị \"\$deviceName\" đã xuất hiện trong \"\$homeName\".":
      "Uređaj „\$deviceName” dodan je u dom „\$homeName”.",
  "Bạn đã tạo nhà \"\$name\".": "Izradili ste dom „\$name”.",
  "\$actorName đã cập nhật tên nhà thành \"\$newName\" và thay đổi địa chỉ.":
      "\$actorName je ažurirao naziv doma u „\$newName” i promijenio njegovu adresu.",
  "\$actorName đã đổi tên nhà thành \"\$newName\".":
      "\$actorName je preimenovao dom u „\$newName”.",
  "\$actorName đã cập nhật địa chỉ của nhà \"\$newName\".":
      "\$actorName je ažurirao adresu doma „\$newName”.",
  "\$actorName đã đổi tên thiết bị \"\$oldDeviceName\" thành \"\$newName\" trong nhà \"\$homeName\".":
      "\$actorName je preimenovao uređaj „\$oldDeviceName” u „\$newName” u domu „\$homeName”.",
  "Đang ghép nối: \$seconds giây": "Uparivanje: \$seconds s",
  "Chế độ thêm thiết bị đã được mở trong nhà \"\$homeName\" trong \$seconds giây.":
      "Način dodavanja uređaja uključen je u domu „\$homeName” na \$seconds sekundi.",
  "Khoảng thời gian phải nằm trong khung báo động (\$start → \$end)":
      "Razdoblje pauze mora biti unutar rasporeda Alarma (\$start → \$end)",
  "\$passCount/\$total bài test đạt\n\n":
      "\$passCount/\$total testova je prošlo\n\n",
  "\$name chưa cập nhật số điện thoại trong hồ sơ.":
      "\$name nije dodao telefonski broj u svoj profil.",
  "Tin nhắn mới trong \$homeName": "Nova poruka u \$homeName",
  "\$current/\$total kết quả": "\$current/\$total rezultata",
  "Đang trả lời \$name": "Odgovarate korisniku \$name",
  "\"\$name\" phát hiện khói trong \"\$homeName\".":
      "„\$name” je otkrio dim u domu „\$homeName”.",
  "\"\$name\" đã trở lại trạng thái bình thường.":
      "„\$name” se vratio u normalno stanje.",
  "\"\$name\" vừa kích hoạt SOS trong \"\$homeName\".":
      "„\$name” je upravo aktivirao SOS u domu „\$homeName”.",
  "\"\$name\" đã hết trạng thái SOS.": "„\$name” više nije u SOS stanju.",
  "\"\$name\" báo bị tháo/cạy trong \"\$homeName\".":
      "„\$name” je prijavio uklanjanje ili nasilno otvaranje u domu „\$homeName”.",
  "\"\$name\" đã hết cảnh báo tháo/cạy.":
      "Upozorenje na neovlašteno uklanjanje za „\$name” je prestalo.",
  "\"\$name\" đã đóng trong \"\$homeName\".":
      "„\$name” je zatvoren u domu „\$homeName”.",
  "\"\$name\" đang mở trong \"\$homeName\".":
      "„\$name” je otvoren u domu „\$homeName”.",
  "\"\$name\" trong \"\$homeName\" đang yếu pin.":
      "„\$name” u domu „\$homeName” ima slabu bateriju.",
  "\"\$name\" trong \"\$homeName\" đã mất kết nối.":
      "„\$name” u domu „\$homeName” izgubio je vezu.",
  "\"\$name\" trong \"\$homeName\" đã kết nối trở lại.":
      "„\$name” u domu „\$homeName” ponovno je na mreži.",
  "\"\$name\" ghi nhận nhiệt độ cao trong \"\$homeName\".":
      "„\$name” je zabilježio visoku temperaturu u domu „\$homeName”.",
  "\"\$name\" ghi nhận độ ẩm cao trong \"\$homeName\".":
      "„\$name” je zabilježio visoku vlažnost u domu „\$homeName”.",
  "Có nút SOS vừa được kích hoạt": "Aktiviran je SOS gumb",
  "Có dấu hiệu khói hoặc cháy": "Otkriveni su znakovi dima ili požara",
  "Có dấu hiệu ngập nước": "Otkriveni su znakovi poplave",
  "Có dấu hiệu rò khí": "Otkriveni su znakovi curenja plina",
  "Có cửa đang mở hoặc thiết bị bị tháo":
      "Vrata su otvorena ili je otkriveno neovlašteno uklanjanje uređaja",
  "Có thiết bị đang cảnh báo": "Uređaj šalje upozorenje",
  "Nếu chưa có ai xác nhận, SafeHome sẽ chuyển sang gọi điện khẩn cấp.":
      "Ako nitko ne potvrdi, SafeHome će pokrenuti hitni poziv.",
  "Báo lại lúc \$time nếu vấn đề chưa được xử lý.":
      "Upozorenje će se ponoviti u \$time ako problem nije riješen.",
  "Sẽ báo lại theo lịch báo động đã cài nếu vấn đề chưa được xử lý.":
      "Upozorenje će se ponoviti prema rasporedu Alarma ako problem nije riješen.",
  "\"\$deviceName\" đã đóng trong \"\$resolvedHomeName\".":
      "„\$deviceName” je zatvoren u domu „\$resolvedHomeName”.",
  "\"\$deviceName\" đang mở trong \"\$resolvedHomeName\".":
      "„\$deviceName” je otvoren u domu „\$resolvedHomeName”.",
  "\$count nhà đã chọn": "Odabrano je \$count domova",
  "🚨 \$count nhà không an toàn\$suffix":
      "🚨 \$count nesigurnih domova\$suffix",
  "⚠️ \$count nhà cần chú ý\$suffix":
      "⚠️ \$count domova zahtijeva pažnju\$suffix",
  "✅ \$count nhà an toàn": "✅ \$count sigurnih domova",
  "\$count nhà đang được theo dõi": "Nadzire se \$count domova",
  "\$minutes phút": "\$minutes minuta",
  "Đã cài nhắc nhở cho \$updatedHomes nhà.":
      "Podsjetnik je postavljen za \$updatedHomes domova.",
  "Đã cài báo động cho \$updatedDevices thiết bị trong \$updatedHomes nhà.\n":
      "Alarm je postavljen za \$updatedDevices uređaja u \$updatedHomes domova.\n",
  "Đã chia sẻ các nhà bạn có quyền.\n\n\$skipped nhà bị bỏ qua vì bạn không có quyền chia sẻ.":
      "Domovi za koje imate dopuštenje uspješno su podijeljeni.\n\n\$skipped domova je preskočeno jer nemate dopuštenje za dijeljenje.",
  "Đã áp dụng báo động cho \$count thiết bị an ninh":
      "Alarm je primijenjen na \$count sigurnosnih uređaja",
  "Áp dụng cùng một lịch cho \$count thiết bị an ninh":
      "Primijeni isti raspored na \$count sigurnosnih uređaja",
  "\$count phút trước": "Prije \$count minuta",
  "\$count giờ trước": "Prije \$count sati",
  "\${count}h trước": "Prije \${count} h",
  "\${hours}h\$minutes' trước": "Prije \${hours} h i \$minutes min",
  "\$count ngày trước": "Prije \$count dana",
  "\$count tháng trước": "Prije \$count mjeseci",
  "Bạn chắc chắn muốn xoá \$name khỏi nhà này?":
      "Jeste li sigurni da želite ukloniti \$name iz ovog doma?",
  "\$targetEmail\nXin gia nhập \"\$homeName\"":
      "\$targetEmail\nTraži pridruživanje domu „\$homeName”",
  "Xin gia nhập \"\$homeName\"": "Traži pridruživanje domu „\$homeName”",
  "Bạn được mời nhận quyền nhà \"\$homeName\"":
      "Pozvani ste preuzeti vlasništvo nad domom „\$homeName”",
  "\$ownerEmail\nMời bạn gia nhập \"\$homeName\"":
      "\$ownerEmail\nPoziva vas da se pridružite domu „\$homeName”",
  "Mời bạn gia nhập \"\$homeName\"":
      "Poziva vas da se pridružite domu „\$homeName”",
  "Cần kiểm tra: \$joined": "Potrebna provjera: \$joined",
  "Cập nhật \$value": "Ažurirano \$value",
  "Hãy thêm thiết bị SafeHome đầu tiên để bắt đầu theo dõi nhà.":
      "Dodajte prvi SafeHome uređaj kako biste počeli nadzirati dom.",
  "Kiểm tra cảnh báo khẩn cấp trước, sau đó liên hệ thành viên trong nhà nếu cần.":
      "Prvo provjerite hitna upozorenja, a zatim po potrebi kontaktirajte članove doma.",
  "Không có thành viên nào ở nhà nhưng cửa hoặc khóa đang mở, hãy kiểm tra ngay.":
      "Nijedan član nije kod kuće, ali vrata ili brava su otvoreni. Odmah provjerite.",
  "Kiểm tra cửa hoặc khóa đang mở trước khi giữ nhà ở chế độ Bảo vệ.":
      "Provjerite otvorena vrata ili bravu prije nego što dom ostavite u načinu Zaštite.",
  "Có thể vẫn có người ở nhà; nếu đúng, nên chuyển về Bình thường.":
      "Moguće je da je netko još kod kuće; ako jest, prebacite na Normalno.",
  "Có thành viên chưa xác định vị trí, hãy nhắc họ mở ứng dụng hoặc kiểm tra quyền vị trí.":
      "Neki članovi imaju nepoznatu lokaciju. Zamolite ih da otvore aplikaciju ili provjere dopuštenje lokacije.",
  "Có thiết bị mất kết nối, hãy kiểm tra pin, nguồn hoặc vị trí đặt thiết bị.":
      "Uređaj nije povezan. Provjerite bateriju, napajanje ili položaj uređaja.",
  "Có thiết bị pin yếu, nên thay pin sớm để tránh mất cảnh báo.":
      "Uređaj ima slabu bateriju. Uskoro je zamijenite kako ne biste propustili upozorenja.",
  "Bạn chưa đặt nhắc nhở, nên tạo lịch nhắc kiểm tra nhà định kỳ.":
      "Podsjetnik nije postavljen. Izradite raspored za redovitu provjeru doma.",
  "Bạn chưa đặt lịch báo động, nên bật bảo vệ theo khung giờ thường vắng nhà.":
      "Raspored Alarma nije postavljen. Uključite Zaštitu za razdoblja kada obično niste kod kuće.",
  "Không có việc cần xử lý ngay, bạn chỉ cần tiếp tục theo dõi trạng thái nhà.":
      "Nije potrebna hitna radnja. Nastavite pratiti stanje doma.",
  "Lặp sau \$minutes phút": "Ponovi nakon \$minutes minuta",
  "Đang dùng • \$repeatText": "Aktivno • \$repeatText",
  "Giám sát an ninh • \$repeatText": "Sigurnosni nadzor • \$repeatText",
  "Gia đình: \$mode": "Način doma: \$mode",
  "Gợi ý xử lý": "Predložene radnje",
  "Phát hiện \$count vấn đề cần xử lý":
      "Otkriveno je \$count problema koji zahtijevaju pažnju",
  "Hôm nay các cửa đã được sử dụng \$count lần":
      "Vrata su danas korištena \$count puta",
  "Đã ghi nhận \$count hoạt động gần đây":
      "Zabilježeno je \$count nedavnih aktivnosti",
  "Hệ thống: Cần kiểm tra \$issueCount mục":
      "Sustav: \$issueCount stavki treba provjeru",
  "FCM token đã sẵn sàng trên điện thoại này.":
      "FCM token spreman je na ovom telefonu.",
  "FCM token đã sẵn sàng, nhưng Auto rời khỏi nhà còn thiếu điều kiện.":
      "FCM token je spreman, ali Automatskom odlasku nedostaje jedan uvjet.",
  "Hiện có \$emergencyTotal thiết bị khẩn cấp. Khuyến nghị tối thiểu: báo khói và SOS.":
      "Pronađeno je \$emergencyTotal hitnih uređaja. Preporučeni minimum: senzor dima i SOS.",
  "Bạn chắc chắn muốn chuyển quyền chủ nhà cho:\n\$targetEmail?":
      "Jeste li sigurni da želite prenijeti vlasništvo na:\n\$targetEmail?",
  "\$count cửa đã đóng an toàn": "\$count vrata sigurno zatvoreno",
  "\$count cửa và khóa đã an toàn": "\$count vrata i brava osigurano",
  "\$count thiết bị đang được theo dõi": "Nadzire se \$count uređaja",
  "Cập nhật \$timeText": "Ažurirano \$timeText",
  "Dữ liệu gần nhất cập nhật \$count phút trước":
      "Najnoviji podaci ažurirani su prije \$count minuta",
  "Dữ liệu gần nhất cập nhật \$count giờ trước":
      "Najnoviji podaci ažurirani su prije \$count sati",
  "Thành viên trong nhà: \$count": "Članovi kod kuće: \$count",
  "Thành viên bên ngoài: \$count": "Članovi izvan doma: \$count",
  "Chưa xác định vị trí: \$count": "Nepoznata lokacija: \$count",
  "Môi trường hiện tại: \$environment": "Trenutačno okruženje: \$environment",
  "\$name: Đang mở khi nhà ở chế độ Bảo vệ":
      "\$name: Otvoreno dok je dom u načinu Zaštite",
  "An tâm hơn trong từng ngôi nhà": "Mir u svakom domu",
  "Báo động SafeHome": "SafeHome Alarm",
  "Có cảnh báo an ninh cần kiểm tra ngay.":
      "Sigurnosno upozorenje zahtijeva hitnu provjeru.",
  "Có cảnh báo cần kiểm tra": "Upozorenje zahtijeva provjeru",
  "Tự đóng sau \$time": "Automatski se zatvara za \$time",
  "Ngày trong tuần": "Dani u tjednu",
  "Hoặc": "Ili",
  "Giờ bắt đầu và kết thúc không được trùng nhau":
      "Vrijeme početka i završetka ne mogu biti isti",
  "Giờ kết thúc phải sau thời điểm hiện tại":
      "Vrijeme završetka mora biti nakon trenutačnog vremena",
  "Khoảng tạm tắt không hợp lệ": "Nevažeći raspon pauze Alarma",
  "Khoảng tạm tắt không trùng với lịch báo động nào đang bật":
      "Raspon pauze ne preklapa se ni s jednim aktivnim rasporedom Alarma",
  "Cài đặt báo động": "Postavke Alarma",
  "Điều khiển cách cảm biến này kích hoạt cảnh báo.":
      "Upravlja načinom na koji ovaj senzor pokreće upozorenja.",
  "Tham gia báo động": "Sudjeluj u alarmima",
  "Tắt để cảm biến không tạo báo động.":
      "Isključite kako ovaj senzor ne bi pokretao Alarm.",
  "Bật còi vật lý": "Omogući fizičku sirenu",
  "Cho phép kích hoạt còi trong nhà.": "Dopušta uključivanje sirene u domu.",
  "Đánh thức màn hình": "Probudi zaslon",
  "Hiển thị cảnh báo toàn màn hình trên điện thoại.":
      "Prikazuje upozorenje preko cijelog zaslona telefona.",
  "Độ trễ kích hoạt": "Odgoda aktiviranja",
  "Chỉ áp dụng cho cảm biến an ninh.":
      "Primjenjuje se samo na sigurnosne senzore.",
  "Cảm biến khẩn cấp luôn kích hoạt ngay lập tức.":
      "Hitni senzori uvijek se aktiviraju odmah.",
  "Ngay lập tức": "Odmah",
  "giây": "sekundi",
  "Đã lưu cấu hình báo động": "Postavke Alarma su spremljene",
  "Không thể lưu cấu hình báo động": "Nije moguće spremiti postavke Alarma",
  "Chỉ chủ nhà và quản trị viên có thể thay đổi cài đặt này.":
      "Samo Vlasnik i Administratori mogu promijeniti ovu postavku.",
  "Thông tin chi tiết": "Pojedinosti o uređaju",
  "Thông báo báo động": "Obavijest o Alarmu",
  "Cài đặt nhắc nhở": "Postavke Podsjetnika",
  "Nhắc nhở theo lịch": "Zakazani Podsjetnik",
  "Danh sách thông báo": "Popis obavijesti",
  "Cài đặt thông báo": "Postavke obavijesti",
  "Sử dụng báo động theo lịch đã thiết lập":
      "Koristi Alarm prema postavljenom rasporedu",
  "Chỉ gửi thông báo, không kích hoạt báo động":
      "Šalji samo obavijesti, bez pokretanja Alarma",
  "Toàn bộ báo động của nhà đang tắt; hệ thống chỉ gửi thông báo.":
      "Svi Alarmi doma su isključeni; sustav će slati samo obavijesti.",
  "Chỉ Chủ nhà có thể bật chế độ này.":
      "Samo Vlasnik može uključiti ovaj način.",
  "Bật Không bảo vệ?": "Uključiti način Bez zaštite?",
  "Cảm biến vừa phát hiện một sự kiện.": "Senzor je upravo otkrio događaj.",
  "Chỉ Chủ nhà mới có quyền bật chế độ Không bảo vệ":
      "Samo Vlasnik može uključiti način Bez zaštite",
  "Đã chuyển nhà sang Không bảo vệ": "Dom je prebačen u način Bez zaštite",
  "Đã chuyển sang Không bảo vệ nhưng chưa gửi được thông báo":
      "Prebačeno je na način Bez zaštite, ali obavijest nije moguće poslati",
  "Giám sát toàn diện": "Potpuni nadzor",
  "Không bảo vệ": "Bez zaštite",
  "Không bảo vệ đang bật": "Način Bez zaštite je aktivan",
  "Nhà đã chuyển sang Không bảo vệ": "Dom je prebačen u način Bez zaštite",
  "Thông báo cảm biến": "Obavijesti senzora",
  "Thông báo thông thường khi cảm biến phát hiện sự kiện.":
      "Uobičajene obavijesti kada senzor otkrije događaj.",
  "Tôi hiểu, tiếp tục": "Razumijem, nastavi",
  "Cảnh báo an ninh đã kết thúc": "Sigurnosno upozorenje je završilo",
  "Sự cố nguy hiểm đã kết thúc": "Hitni slučaj je završen",
  "Cảnh báo đã được kết thúc.": "Upozorenje je završilo.",
  "Vẫn còn cảnh báo khác đang hoạt động.": "Drugo upozorenje još je aktivno.",
  "Báo động đã hoạt động trở lại": "Alarm je ponovno aktivan",
  "Thời gian tạm dừng báo động đã kết thúc.":
      "Razdoblje pauze Alarma je završilo.",
  "MQTT đã kết nối trở lại": "MQTT se ponovno povezao",
  "Còi báo động đã được tắt": "Fizička sirena je isključena",
  "Sự cố vẫn đang được theo dõi.": "Incident se i dalje nadzire.",
  "Bảo vệ tự động đã bật": "Automatska Zaštita je uključena",
  "Toàn bộ thành viên đã rời khỏi nhà.": "Svi članovi napustili su dom.",
  "Bảo vệ tự động đã tắt": "Automatska Zaštita je isključena",
  "Có thành viên đã trở về nhà.": "Član se vratio kući.",
  "Thiết bị đã được xoá": "Uređaj je uklonjen",
  "Không thể xoá thiết bị": "Nije moguće ukloniti uređaj",
  "Hãy thử lại thao tác xoá thiết bị.": "Pokušajte ponovno ukloniti uređaj.",
  "Chế độ Bảo vệ đã được tắt.": "Način Zaštite je isključen.",
  "Nhà đang ở chế độ Bình thường.": "Dom je u načinu Normalno.",
  "Pin thiết bị đã ổn định": "Baterija uređaja je stabilna",
  "Hub đã kết nối trở lại": "Hub se ponovno povezao",
  "Đã chuyển về Bình thường nhưng chưa gửi được thông báo":
      "Vraćeno je na Normalno, ali obavijest nije moguće poslati",
  "Chung cho nhà": "Zajedničko za dom",
  "Áp dụng cho toàn bộ thành viên và có thể bật còi vật lý.":
      "Primjenjuje se na sve članove i može uključiti fizičku sirenu.",
  "Cá nhân": "Osobno",
  "Lịch cá nhân hoạt động độc lập và không bật còi vật lý.":
      "Osobni raspored radi neovisno i nikada ne uključuje fizičku sirenu.",
  "Cài đặt này chỉ áp dụng cho tài khoản của bạn.":
      "Ova postavka vrijedi samo za vaš račun.",
  "Chỉ chủ nhà và quản trị viên có thể thay đổi phần chung cho nhà.":
      "Samo Vlasnik i Administratori mogu mijenjati zajedničke postavke doma.",
  "Tham gia hệ thống báo động": "Sudjeluj u sustavu Alarma",
  "Cảm biến khẩn cấp luôn tham gia hệ thống báo động.":
      "Hitni senzori uvijek sudjeluju u sustavu Alarma.",
  "Tắt để thiết bị không tạo bất kỳ báo động nào.":
      "Isključite kako uređaj ne bi pokretao nijedan Alarm.",
  "Lịch báo động chung": "Zajednički raspored Alarma",
  "Lịch báo động cá nhân": "Osobni raspored Alarma",
  "Hiển thị cảnh báo toàn màn hình trên điện thoại của bạn.":
      "Prikazuje upozorenje preko cijelog zaslona vašeg telefona.",
  "Lặp lại cảnh báo": "Ponavljaj upozorenje",
  "Báo động chung": "Zajednički Alarm",
  "Báo động cá nhân": "Osobni Alarm",
  "Đã cài đặt": "Postavljeno",
  "Chưa cài đặt": "Nije postavljeno",
  "Lịch chung và lịch cá nhân hoạt động song song, không còn phải chọn một trong hai.":
      "Zajednički i osobni rasporedi rade paralelno; više ne morate birati između njih.",
  "Cài nhanh chung": "Brzo zajedničko postavljanje",
  "Cài nhanh cá nhân": "Brzo osobno postavljanje",
  "Thiết lập nhanh lịch cá nhân": "Brzo postavljanje osobnog rasporeda",
  "Thiết lập nhanh lịch chung": "Brzo postavljanje zajedničkog rasporeda",
  "Lịch này chỉ áp dụng cho bạn và không bật còi vật lý.":
      "Ovaj raspored vrijedi samo za vas i ne uključuje fizičku sirenu.",
  "Lịch này áp dụng cho toàn bộ thành viên trong nhà.":
      "Ovaj raspored vrijedi za sve članove doma.",
  "Đã áp dụng lịch báo động": "Raspored Alarma je primijenjen",
  "Không thể lưu lịch báo động": "Nije moguće spremiti raspored Alarma",
  "Nhà chưa có thiết bị an ninh": "Ovaj dom nema sigurnosnih uređaja",
  "Nhận cảnh báo theo lịch chung của nhà":
      "Primaj upozorenja prema zajedničkom rasporedu doma",
  "Tắt để không nhận thông báo hoặc cảnh báo toàn màn hình từ lịch chung. Còi vật lý của nhà vẫn hoạt động.":
      "Isključite kako više ne biste primali obavijesti ili upozorenja preko cijelog zaslona iz zajedničkog rasporeda. Sirena doma i dalje će raditi.",
};

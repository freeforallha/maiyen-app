const Map<String, String> huDynamicStrings = {
  "Bảo vệ - Tự động": "Védelem — Automatikus",
  "Bảo vệ - Thủ công": "Védelem — Kézi",
  "Tự động": "Automatikus",
  "Thủ công": "Kézi",
  "\$displayMemberName đã gia nhập nhà \"\$homeName\".":
      "\$displayMemberName csatlakozott a(z) „\$homeName” otthonhoz.",
  "NGUY HIỂM": "VESZÉLY",
  "Nguy hiểm & Khẩn cấp": "Veszély és vészhelyzet",
  "TẮT CÒI": "SZIRÉNA KIKAPCSOLÁSA",
  "Tắt còi báo động?": "Sziréna kikapcsolása?",
  "Còi vật lý sẽ dừng, nhưng cảnh báo vẫn tiếp tục cho đến khi sự cố được xử lý.\n\nBạn chắc chắn muốn tắt còi?":
      "A fizikai sziréna leáll, de a riasztás a probléma megoldásáig folytatódik.\n\nBiztosan ki szeretné kapcsolni a szirénát?",
  "Đã gửi lệnh tắt còi. Cảnh báo vẫn đang được theo dõi.":
      "A sziréna kikapcsolási parancsa elküldve. A riasztás megfigyelése továbbra is folyamatban van.",
  "Không tìm thấy cảnh báo đang hoạt động hoặc chưa thể gửi lệnh tắt còi.":
      "Nem található aktív riasztás, vagy a sziréna kikapcsolási parancsa még nem küldhető el.",
  "TẮT CÒI TRONG NHÀ": "OTTHONI SZIRÉNA KIKAPCSOLÁSA",
  "Đã tắt còi trong nhà. Cảnh báo vẫn tiếp tục cho đến khi được xử lý.":
      "Az otthoni sziréna kikapcsolva. A riasztás a probléma megoldásáig folytatódik.",
  "\$name đang chuẩn bị gửi tin...": "\$name éppen ír...",
  "\$name1 và \$name2 đang chuẩn bị gửi tin...":
      "\$name1 és \$name2 éppen írnak...",
  "\$name và \$otherCount người khác đang chuẩn bị gửi tin...":
      "\$name és további \$otherCount személy éppen ír...",
  "Kênh báo động cũ để giữ tương thích":
      "Régi riasztási csatorna a kompatibilitás megőrzéséhez",
  "SafeHome báo động toàn màn hình": "SafeHome teljes képernyős riasztás",
  "Mở cảnh báo toàn màn hình; âm còi phát từ trang báo động":
      "Teljes képernyős riasztás megnyitása; a szirénahang a Riasztási oldalról szól",
  "SafeHome cảnh báo khẩn cấp": "SafeHome vészhelyzeti riasztás",
  "Cảnh báo khẩn cấp ưu tiên cao trước khi mở toàn màn hình":
      "Magas prioritású vészhelyzeti riasztás a teljes képernyős megnyitás előtt",
  "SafeHome nhắc nhở toàn màn hình": "SafeHome teljes képernyős Emlékeztető",
  "Nhắc nhở SafeHome toàn màn hình không âm thanh":
      "SafeHome teljes képernyős Emlékeztető hang nélkül",
  "SafeHome nhắc nhở ưu tiên cao": "Magas prioritású SafeHome Emlékeztető",
  "Nhắc nhở SafeHome ưu tiên cao, không mở toàn màn hình":
      "Magas prioritású SafeHome Emlékeztető teljes képernyős megnyitás nélkül",
  "Tin nhắn mới trong các nhà SafeHome": "Új üzenetek a SafeHome-otthonokban",
  "Hành động này sẽ thay đổi thời gian báo động của một số thiết bị hôm nay.\n\nBáo động của các thiết bị thuộc trường \"Nguy hiểm khẩn cấp\" và báo động ở chế độ \"Bảo vệ\" sẽ không bị ảnh hưởng bởi chức năng này.":
      "Ez a művelet ma módosítja néhány eszköz riasztási idejét.\n\nA „Vészhelyzeti veszély” kategóriába tartozó eszközök riasztásait és a „Védelem” módban működő riasztásokat ez a funkció nem érinti.",
  "🆘 \$count nhà nguy hiểm\$suffix":
      "🆘 \$count veszélyben lévő otthon\$suffix",
  "FCM token đã sẵn sàng, nhưng tính năng tự động khi rời nhà còn thiếu điều kiện.":
      "Az FCM-token készen áll, de az automatikus távolléti funkció egyik feltétele hiányzik.",
  "Đã kích hoạt SOS": "SOS aktiválva",
  "Phát hiện chập điện": "Rövidzárlat észlelve",
  "Phát hiện quá dòng": "Túláram észlelve",
  "Phát hiện quá áp": "Túlfeszültség észlelve",
  "Thiết bị điện quá nhiệt": "Elektromos eszköz túlmelegedett",
  "Tài khoản đang được sử dụng": "A fiók használatban van",
  "Hiện tại tài khoản này đang đăng nhập trên một thiết bị khác. Nếu tiếp tục, tài khoản trên thiết bị đó sẽ tự đăng xuất.":
      "Ez a fiók jelenleg egy másik eszközön van bejelentkezve. Ha folytatja, a másik eszközön a rendszer automatikusan kijelentkezteti.",
  "Tiếp tục đăng nhập": "Bejelentkezés folytatása",
  "Tài khoản đã được đăng nhập trên một thiết bị khác.":
      "A fiók egy másik eszközön lett bejelentkeztetve.",
  "KHẨN CẤP": "VÉSZHELYZET",
  "CẦN CHÚ Ý": "FIGYELMET IGÉNYEL",
  "THÔNG TIN": "INFORMÁCIÓ",
  "BÁO ĐỘNG": "RIASZTÁS",
  "Cảm biến đã trở lại trạng thái an toàn.":
      "Az érzékelő visszatért biztonságos állapotba.",
  "Người dùng đã tắt cảnh báo.": "A felhasználó kikapcsolta a riasztást.",
  "Khung giờ bảo vệ đã kết thúc.": "A Védelmi időszak véget ért.",
  "Cảnh báo tức thời đã tự kết thúc.":
      "Az azonnali riasztás automatikusan véget ért.",
  "Điều kiện cảnh báo không còn hoạt động.":
      "A riasztási feltétel már nem aktív.",
  "Cảnh báo đã kết thúc: \$reason": "A riasztás véget ért: \$reason",
};

import 'dart:ui' as ui;

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AppLanguageController extends ChangeNotifier {
  static const String _storageKey = "safehome_language_code";
  static const Set<String> supportedCodes = {
    "vi",
    "en",
    "zh",
    "ko",
    "ja",
    "de",
    "ru",
    "fr",
    "es",
    "id",
    "th",
    "ms",
    "fil",
    "km",
    "my",
    "lo",
    "ta",
    "pt",
    "tet",
    "it",
    "pl",
    "nl",
    "cs",
    "sk",
    "uk",
    "ro",
    "hu",
    "bg",
    "hr",
    "sr",
    "bs",
    "sl",
    "mk",
    "sq",
    "el",
    "tr",
    "sv",
    "da",
    "nb",
    "fi",
    "is",
    "et",
    "lv",
    "lt",
    "ga",
    "mt",
    "be",
    "lb",
    "ca",
    "cnr",
    "hy",
    "ka",
    "az",
  };
  static const List<Locale> supportedLocales = [
    Locale("vi"),
    Locale("en"),
    Locale("zh", "CN"),
    Locale("ko", "KR"),
    Locale("ja", "JP"),
    Locale("de", "DE"),
    Locale("ru", "RU"),
    Locale("fr", "FR"),
    Locale("es", "ES"),
    Locale("id", "ID"),
    Locale("th", "TH"),
    Locale("ms", "MY"),
    Locale("fil", "PH"),
    Locale("km", "KH"),
    Locale("my", "MM"),
    Locale("lo"),
    Locale("ta", "SG"),
    Locale("pt", "TL"),
    Locale("tet", "TL"),
    Locale("it", "IT"),
    Locale("pl", "PL"),
    Locale("nl", "NL"),
    Locale("cs", "CZ"),
    Locale("sk", "SK"),
    Locale("uk", "UA"),
    Locale("ro", "RO"),
    Locale("hu", "HU"),
    Locale("bg", "BG"),
    Locale("hr", "HR"),
    Locale("sr", "RS"),
    Locale("bs", "BA"),
    Locale("sl", "SI"),
    Locale("mk", "MK"),
    Locale("sq", "AL"),
    Locale("el", "GR"),
    Locale("tr", "TR"),
    Locale("sv", "SE"),
    Locale("da", "DK"),
    Locale("nb", "NO"),
    Locale("fi", "FI"),
    Locale("is", "IS"),
    Locale("et", "EE"),
    Locale("lv", "LV"),
    Locale("lt", "LT"),
    Locale("ga", "IE"),
    Locale("mt", "MT"),
    Locale("be", "BY"),
    Locale("lb", "LU"),
    Locale("ca", "AD"),
    Locale("cnr", "ME"),
    Locale("hy", "AM"),
    Locale("ka", "GE"),
    Locale("az", "AZ"),
  ];
  static const Map<String, String> languageFlags = {
    "vi": "🇻🇳",
    "en": "🇬🇧",
    "zh": "🇨🇳",
    "ko": "🇰🇷",
    "ja": "🇯🇵",
    "de": "🇩🇪",
    "ru": "🇷🇺",
    "fr": "🇫🇷",
    "es": "🇪🇸",
    "id": "🇮🇩",
    "th": "🇹🇭",
    "ms": "🇲🇾",
    "fil": "🇵🇭",
    "km": "🇰🇭",
    "my": "🇲🇲",
    "lo": "🇱🇦",
    "ta": "🇸🇬",
    "pt": "🇹🇱",
    "tet": "🇹🇱",
    "it": "🇮🇹",
    "pl": "🇵🇱",
    "nl": "🇳🇱",
    "cs": "🇨🇿",
    "sk": "🇸🇰",
    "uk": "🇺🇦",
    "ro": "🇷🇴",
    "hu": "🇭🇺",
    "bg": "🇧🇬",
    "hr": "🇭🇷",
    "sr": "🇷🇸",
    "bs": "🇧🇦",
    "sl": "🇸🇮",
    "mk": "🇲🇰",
    "sq": "🇦🇱",
    "el": "🇬🇷",
    "tr": "🇹🇷",
    "sv": "🇸🇪",
    "da": "🇩🇰",
    "nb": "🇳🇴",
    "fi": "🇫🇮",
    "is": "🇮🇸",
    "et": "🇪🇪",
    "lv": "🇱🇻",
    "lt": "🇱🇹",
    "ga": "🇮🇪",
    "mt": "🇲🇹",
    "be": "🇧🇾",
    "lb": "🇱🇺",
    "ca": "🇦🇩",
    "cnr": "🇲🇪",
    "hy": "🇦🇲",
    "ka": "🇬🇪",
    "az": "🇦🇿",
  };

  static const Map<String, String> languageLabels = {
    "vi": "Tiếng Việt",
    "en": "English",
    "zh": "中文",
    "ko": "한국어",
    "ja": "日本語",
    "de": "Deutsch",
    "ru": "Русский",
    "fr": "Français",
    "es": "Español",
    "id": "Bahasa Indonesia",
    "th": "ภาษาไทย",
    "ms": "Bahasa Melayu",
    "fil": "Filipino",
    "km": "ភាសាខ្មែរ",
    "my": "မြန်မာဘာသာ",
    "lo": "ລາວ",
    "ta": "தமிழ்",
    "pt": "Português",
    "tet": "Tetun",
    "it": "Italiano",
    "pl": "Polski",
    "nl": "Nederlands",
    "cs": "Čeština",
    "sk": "Slovenčina",
    "uk": "Українська",
    "ro": "Română",
    "hu": "Magyar",
    "bg": "Български",
    "hr": "Hrvatski",
    "sr": "Srpski",
    "bs": "Bosanski",
    "sl": "Slovenščina",
    "mk": "Македонски",
    "sq": "Shqip",
    "el": "Ελληνικά",
    "tr": "Türkçe",
    "sv": "Svenska",
    "da": "Dansk",
    "nb": "Norsk bokmål",
    "fi": "Suomi",
    "is": "Íslenska",
    "et": "Eesti",
    "lv": "Latviešu",
    "lt": "Lietuvių",
    "ga": "Gaeilge",
    "mt": "Malti",
    "be": "Беларуская",
    "lb": "Lëtzebuergesch",
    "ca": "Català",
    "cnr": "Crnogorski",
    "hy": "Հայերեն",
    "ka": "ქართული",
    "az": "Azərbaycan dili",
  };

  Locale _locale = const Locale("vi");
  bool _loaded = false;

  Locale get locale => _locale;
  String get languageCode => _locale.languageCode;
  bool get isEnglish => languageCode == "en";
  bool get isChinese => languageCode == "zh";
  bool get isKorean => languageCode == "ko";
  bool get isJapanese => languageCode == "ja";
  bool get isGerman => languageCode == "de";
  bool get isRussian => languageCode == "ru";
  bool get isFrench => languageCode == "fr";
  bool get isSpanish => languageCode == "es";
  bool get isIndonesian => languageCode == "id";
  bool get isThai => languageCode == "th";
  bool get isMalay => languageCode == "ms";
  bool get isFilipino => languageCode == "fil";
  bool get isKhmer => languageCode == "km";
  bool get isBurmese => languageCode == "my";
  bool get isLao => languageCode == "lo";
  bool get isTamil => languageCode == "ta";
  bool get isPortuguese => languageCode == "pt";
  bool get isTetum => languageCode == "tet";
  bool get isItalian => languageCode == "it";
  bool get isPolish => languageCode == "pl";
  bool get isDutch => languageCode == "nl";
  bool get isCzech => languageCode == "cs";
  bool get isSlovak => languageCode == "sk";
  bool get isUkrainian => languageCode == "uk";
  bool get isRomanian => languageCode == "ro";
  bool get isHungarian => languageCode == "hu";
  bool get isBulgarian => languageCode == "bg";
  bool get isCroatian => languageCode == "hr";
  bool get isSerbian => languageCode == "sr";
  bool get isBosnian => languageCode == "bs";
  bool get isSlovenian => languageCode == "sl";
  bool get isMacedonian => languageCode == "mk";
  bool get isAlbanian => languageCode == "sq";
  bool get isGreek => languageCode == "el";
  bool get isTurkish => languageCode == "tr";
  bool get isSwedish => languageCode == "sv";
  bool get isDanish => languageCode == "da";
  bool get isNorwegianBokmal => languageCode == "nb";
  bool get isFinnish => languageCode == "fi";
  bool get isIcelandic => languageCode == "is";
  bool get isEstonian => languageCode == "et";
  bool get isLatvian => languageCode == "lv";
  bool get isLithuanian => languageCode == "lt";
  bool get isIrish => languageCode == "ga";
  bool get isMaltese => languageCode == "mt";
  bool get isBelarusian => languageCode == "be";
  bool get isLuxembourgish => languageCode == "lb";
  bool get isCatalan => languageCode == "ca";
  bool get isMontenegrin => languageCode == "cnr";
  bool get isArmenian => languageCode == "hy";
  bool get isGeorgian => languageCode == "ka";
  bool get isAzerbaijani => languageCode == "az";

  String _normalizeLanguageCode(String code) {
    final cleanCode = code.trim().toLowerCase();

    if (cleanCode == "my_mm" || cleanCode == "my-mm") {
      return "my";
    }

    return cleanCode;
  }

  Locale _localeForCode(String code) {
    final normalizedCode = _normalizeLanguageCode(code);

    if (normalizedCode == "my") {
      return const Locale("my", "MM");
    }

    if (normalizedCode == "lo") {
      return const Locale("lo");
    }

    if (normalizedCode == "ta") {
      return const Locale("ta", "SG");
    }

    if (normalizedCode == "pt") {
      return const Locale("pt", "TL");
    }

    if (normalizedCode == "tet") {
      return const Locale("tet", "TL");
    }

    if (normalizedCode == "it") {
      return const Locale("it", "IT");
    }

    if (normalizedCode == "pl") {
      return const Locale("pl", "PL");
    }

    if (normalizedCode == "nl") {
      return const Locale("nl", "NL");
    }

    if (normalizedCode == "cs") {
      return const Locale("cs", "CZ");
    }

    if (normalizedCode == "sk") {
      return const Locale("sk", "SK");
    }

    if (normalizedCode == "uk") {
      return const Locale("uk", "UA");
    }

    if (normalizedCode == "ro") {
      return const Locale("ro", "RO");
    }

    if (normalizedCode == "hu") {
      return const Locale("hu", "HU");
    }

    if (normalizedCode == "bg") {
      return const Locale("bg", "BG");
    }

    if (normalizedCode == "hr") {
      return const Locale("hr", "HR");
    }

    if (normalizedCode == "sr") {
      return const Locale("sr", "RS");
    }

    if (normalizedCode == "bs") {
      return const Locale("bs", "BA");
    }

    if (normalizedCode == "sl") {
      return const Locale("sl", "SI");
    }

    if (normalizedCode == "mk") {
      return const Locale("mk", "MK");
    }

    if (normalizedCode == "sq") {
      return const Locale("sq", "AL");
    }

    if (normalizedCode == "el") {
      return const Locale("el", "GR");
    }

    if (normalizedCode == "tr") {
      return const Locale("tr", "TR");
    }

    if (normalizedCode == "sv") {
      return const Locale("sv", "SE");
    }

    if (normalizedCode == "da") {
      return const Locale("da", "DK");
    }

    if (normalizedCode == "nb") {
      return const Locale("nb", "NO");
    }

    if (normalizedCode == "fi") {
      return const Locale("fi", "FI");
    }

    if (normalizedCode == "is") {
      return const Locale("is", "IS");
    }

    if (normalizedCode == "et") {
      return const Locale("et", "EE");
    }

    if (normalizedCode == "lv") {
      return const Locale("lv", "LV");
    }

    if (normalizedCode == "lt") {
      return const Locale("lt", "LT");
    }

    if (normalizedCode == "ga") {
      return const Locale("ga", "IE");
    }

    if (normalizedCode == "mt") {
      return const Locale("mt", "MT");
    }

    if (normalizedCode == "be") {
      return const Locale("be", "BY");
    }

    if (normalizedCode == "lb") {
      return const Locale("lb", "LU");
    }

    if (normalizedCode == "ca") {
      return const Locale("ca", "AD");
    }

    if (normalizedCode == "cnr") {
      return const Locale("cnr", "ME");
    }

    if (normalizedCode == "hy") {
      return const Locale("hy", "AM");
    }

    if (normalizedCode == "ka") {
      return const Locale("ka", "GE");
    }

    if (normalizedCode == "az") {
      return const Locale("az", "AZ");
    }

    if (code == "zh") {
      return const Locale("zh", "CN");
    }

    if (code == "ko") {
      return const Locale("ko", "KR");
    }

    if (code == "ja") {
      return const Locale("ja", "JP");
    }

    if (code == "de") {
      return const Locale("de", "DE");
    }

    if (code == "ru") {
      return const Locale("ru", "RU");
    }

    if (code == "fr") {
      return const Locale("fr", "FR");
    }

    if (code == "es") {
      return const Locale("es", "ES");
    }

    if (code == "id") {
      return const Locale("id", "ID");
    }

    if (code == "th") {
      return const Locale("th", "TH");
    }

    if (code == "ms") {
      return const Locale("ms", "MY");
    }

    if (code == "fil") {
      return const Locale("fil", "PH");
    }

    if (code == "km") {
      return const Locale("km", "KH");
    }

    return Locale(code);
  }

  Future<void> _syncLanguageToFirebase(String code) async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;

      final normalizedCode = _normalizeLanguageCode(code);
      if (!supportedCodes.contains(normalizedCode)) return;

      await FirebaseDatabase.instance
          .ref("accounts/${user.uid}/languageCode")
          .set(normalizedCode);
    } catch (_) {
      // Không chặn đổi ngôn ngữ cục bộ khi Firebase tạm thời không khả dụng.
    }
  }

  String _systemSupportedLanguageCode() {
    final systemCode = _normalizeLanguageCode(
      ui.PlatformDispatcher.instance.locale.languageCode,
    );

    if (supportedCodes.contains(systemCode)) {
      return systemCode;
    }

    return "vi";
  }

  Future<void> load() async {
    if (_loaded) {
      return;
    }

    _loaded = true;

    try {
      final preferences = await SharedPreferences.getInstance();
      final savedValue = preferences.getString(_storageKey);
      final savedCode = savedValue == null
          ? null
          : _normalizeLanguageCode(savedValue);
      final code = savedCode != null && supportedCodes.contains(savedCode)
          ? savedCode
          : _systemSupportedLanguageCode();

      if (code != languageCode) {
        _locale = _localeForCode(code);
        notifyListeners();
      }
    } catch (_) {
      final code = _systemSupportedLanguageCode();

      if (code != languageCode) {
        _locale = _localeForCode(code);
        notifyListeners();
      }
    }

    await _syncLanguageToFirebase(languageCode);
  }

  Future<void> setLanguageCode(String code) async {
    final normalizedCode = _normalizeLanguageCode(code);

    if (!supportedCodes.contains(normalizedCode) ||
        normalizedCode == languageCode) {
      return;
    }

    _locale = _localeForCode(normalizedCode);
    notifyListeners();

    try {
      final preferences = await SharedPreferences.getInstance();
      await preferences.setString(_storageKey, normalizedCode);
    } catch (_) {
      // Ngôn ngữ vẫn đổi trong phiên hiện tại.
    }

    await _syncLanguageToFirebase(normalizedCode);
  }
}

final AppLanguageController appLanguageController = AppLanguageController();

import 'package:flutter/material.dart';

class AppStrings {
  final bool isEnglish;
  final bool isChinese;

  const AppStrings._({required this.isEnglish, required this.isChinese});

  factory AppStrings.fromLocale(Locale locale) {
    return AppStrings._(
      isEnglish: locale.languageCode == "en",
      isChinese: locale.languageCode == "zh",
    );
  }

  static AppStrings of(BuildContext context) {
    return AppStrings.fromLocale(Localizations.localeOf(context));
  }

  String choose({required String vi, required String en, String? zh}) {
    if (isChinese) {
      return zh ?? _chinese[vi] ?? vi;
    }

    return isEnglish ? en : vi;
  }

  static const Map<String, String> _english = {
    "Nhà chưa đặt tên": "Unnamed home",
    "Nhà": "Home",
    "Chưa có thông tin": "No information available",
    "Chưa cập nhật": "Not updated",
    "Chủ nhà": "Owner",
    "Nhà được chia sẻ": "Shared home",
    "Địa chỉ": "Address",
    "An ninh ra/vào": "Entry security",
    "Nguy hiểm khẩn cấp": "Emergency hazards",
    "Điều khiển & hạ tầng": "Control & infrastructure",
    "Thiết bị đang Offline": "Device is offline",
    "Thiết bị đang Online": "Device is online",
    "pin yếu": "low battery",
    "sóng yếu": "weak signal",
    "lâu không phản hồi": "not responding",
    "Kết nối cần kiểm tra": "Connection needs attention",
    "Vừa xong": "Just now",
    "Bị tháo": "Tamper detected",
    "Có khói": "Smoke detected",
    "Bình thường": "Normal",
    "Đã kích hoạt": "Activated",
    "Sẵn sàng": "Ready",
    "Đang đóng": "Closed",
    "Đang mở": "Open",
    "Rò rỉ gas": "Gas leak detected",
    "Phát hiện ngập nước": "Water leak detected",
    "Phát hiện chuyển động": "Motion detected",
    "Không có chuyển động": "No motion detected",
    "Phát hiện hiện diện": "Presence detected",
    "Không phát hiện hiện diện": "No presence detected",
    "Phát hiện rung/chấn động": "Vibration detected",
    "Không có rung bất thường": "No unusual vibration",
    "Phát hiện kính vỡ": "Glass break detected",
    "Không có cảnh báo kính vỡ": "No glass-break alert",
    "Nhiệt độ nguy hiểm": "Dangerous heat detected",
    "Phát hiện khí CO": "Carbon monoxide detected",
    "Không phát hiện khí CO": "No carbon monoxide detected",
    "Khóa đang mở": "Unlocked",
    "Khóa đang đóng": "Locked",
    "Đang bật": "On",
    "Đang tắt": "Off",
    "Đang theo dõi điện năng": "Monitoring power",
    "Đang dùng nguồn dự phòng": "Running on backup power",
    "Nguồn điện bình thường": "Mains power normal",
    "Còi đang bật": "Siren active",
    "Còi sẵn sàng": "Siren ready",
    "Van đang mở": "Valve open",
    "Van đã đóng": "Valve closed",
    "Đang hoạt động": "Operating",
    "Chưa nhận diện": "Unrecognized device",
    "Chưa có cập nhật": "No updates yet",
    "Chưa có thiết bị, hãy nhấn nút + để thêm để bắt đầu duy trì an ninh":
        "No devices yet. Tap + to add one and start monitoring your home.",
    "CHƯA AN TOÀN": "UNSAFE",
    "CẦN CHÚ Ý": "NEEDS ATTENTION",
    "ĐÃ AN TOÀN": "SAFE",
    "Nhà đang có dấu hiệu cần kiểm tra, bạn nên xem lại các trạng thái bên dưới.":
        "Your home needs attention. Review the statuses below.",
    "Nhà đang hoạt động ổn định, bạn có thể yên tâm.":
        "Your home is operating normally.",
    "Không có dấu hiệu khói hoặc SOS bất thường.":
        "No unusual smoke or SOS activity detected.",
    "Chưa có nhiều hoạt động mới để phân tích sâu hơn.":
        "There is not enough recent activity for a deeper analysis.",
    "Cài đặt cảnh báo cho nhà hiện tại": "Alert settings for this home",
    "Nhận cảnh báo Alarm": "Receive Alarm alerts",
    "Đang bật cho tài khoản này": "Enabled for this account",
    "Đang tắt cho tài khoản này": "Disabled for this account",
    "Hẹn giờ Reminder": "Reminder schedule",
    "Nhắc kiểm tra nhà theo thời gian": "Schedule home check reminders",
    "Hẹn giờ Alarm": "Alarm schedule",
    "Chưa thiết lập": "Not configured",
    "Chưa thiết lập thời gian": "No schedule configured",
    "Tổng hợp trạng thái nhà": "Home status summary",
    "Cần xử lý ngay": "Action required",
    "Cần kiểm tra": "Needs attention",
    "Đánh giá tự động": "Automated assessment",
    "Tổng quan hôm nay": "Today overview",
    "Chưa có dữ liệu tổng quan": "No overview data yet",
    "Chưa có dữ liệu trạng thái": "No status data yet",
    "Bấm vào để xem chi tiết": "Tap to view details",
    "Tạm dừng": "Paused",
    "Tắt": "Off",
    "Chi tiết": "Details",
    "Tổng hợp trạng thái": "Status summary",
    "Không an toàn": "Unsafe",
    "Cần chú ý": "Needs attention",
    "An toàn": "Safe",
    "Không có": "None",
    "Đổi tên nhóm": "Rename group",
    "Huỷ": "Cancel",
    "Hủy": "Cancel",
    "Lưu": "Save",
    "Nhà của tôi": "My homes",
    "Bỏ chọn toàn bộ nhóm": "Deselect entire group",
    "Chọn toàn bộ nhóm": "Select entire group",
    "Giờ": "Hour",
    "Phút": "Minute",
    "Đặt Home Reminder": "Set Home Reminder",
    "Đặt Home Alarm": "Set Home Alarm",
    "Xác nhận thay đổi": "Confirm changes",
    "Tiếp tục": "Continue",
    "Giờ Reminder": "Reminder time",
    "Giờ bắt đầu Alarm": "Alarm start time",
    "Giờ kết thúc Alarm": "Alarm end time",
    "Không có nhà nào đủ điều kiện để cài": "No eligible homes were found",
    "Cài đặt hoàn tất": "Setup complete",
    "Xác nhận rời nhà": "Confirm leaving home",
    "Xác nhận xoá nhà": "Confirm home deletion",
    "Nhập mật khẩu": "Enter password",
    "Mật khẩu tài khoản": "Account password",
    "Rời khỏi nhà": "Leave home",
    "Xoá nhà": "Delete home",
    "Sai mật khẩu": "Incorrect password",
    "Đã rời khỏi home": "Left home",
    "Đã cập nhật": "Updated",
    "Tìm home...": "Search homes...",
    "Đặt Reminder / Alarm nhà đã chọn":
        "Set Reminder / Alarm for selected homes",
    "Chia sẻ nhà đã chọn": "Share selected homes",
    "Hoặc quét QR để xin gia nhập các nhà đã chọn":
        "Or scan a QR code to request access to selected homes",
    "Email người nhận": "Recipient email",
    "Chia sẻ": "Share",
    "Email chưa đăng ký": "Email is not registered",
    "Chia sẻ hoàn tất": "Sharing complete",
    "Mở List chia sẻ nhà": "Open home sharing list",
    "Không có nhà nào bạn có quyền quản lý":
        "You do not manage any selected homes",
    "Chưa share cho ai": "Not shared with anyone",
    "Xoá các nhà đã chọn ?": "Delete selected homes?",
    "Thông báo Home": "Home notifications",
    "Không có thiết bị": "No devices",
    "Chỉ chủ nhà mới được xoá nhà": "Only the owner can delete this home",
    "Chỉ chủ nhà mới được chuyển quyền":
        "Only the owner can transfer ownership",
    "Lưu ý khi bật Alarm": "Alarm notice",
    "Đã hiểu": "Got it",
    "Lưu ý tạm tắt Alarm": "Pause Alarm notice",
    "Đã bật Alarm": "Alarm enabled",
    "Đã tắt Alarm": "Alarm disabled",
    "Cả ngày": "All day",
    "QR gia nhập nhiều nhà không hợp lệ": "Invalid multi-home join QR code",
    "Bạn đang là chủ các nhà này": "You own these homes",
    "Một người dùng": "A user",
    "Yêu cầu gia nhập nhà": "Home join request",
    "Đã gửi yêu cầu gia nhập nhà": "Join request sent",
    "QR gia nhập không hợp lệ": "Invalid join QR code",
    "Bạn đang là chủ nhà này": "You already own this home",
    "QR này không phải mã xin gia nhập nhà":
        "This QR code is not a home join code",
    "Bạn không có quyền thêm thiết bị":
        "You do not have permission to add devices",
    "Đã mở chế độ thêm thiết bị": "Device pairing enabled",
    "Rời khỏi Home này?": "Leave this home?",
    "Nhà này và toàn bộ thiết bị bên trong sẽ bị xoá vĩnh viễn.":
        "This home and all its devices will be permanently deleted.",
    "Đã xoá nhà": "Home deleted",
    "QR của nhà này": "Home QR code",
    "Người khác quét mã này để gửi yêu cầu gia nhập nhà.":
        "Others can scan this code to request access to the home.",
    "Chia sẻ nhà": "Share home",
    "Quét QR để xin gia nhập nhà": "Scan QR to join a home",
    "Xin gia nhập nhà": "Join a home",
    "Quét mã QR chia sẻ nhà": "Scan a home sharing QR code",
    "Mời thành viên bằng mã QR": "Invite members with a QR code",
    "Không thể share cho chính bạn": "You cannot share with yourself",
    "Lời mời chia sẻ nhà": "Home sharing invitation",
    "Đã share home": "Home shared",
    "Chuyển quyền chủ nhà": "Transfer ownership",
    "Không thể chuyển quyền cho chính bạn":
        "You cannot transfer ownership to yourself",
    "Không tìm thấy user": "User not found",
    "Xác nhận chuyển quyền": "Confirm ownership transfer",
    "Chuyển": "Transfer",
    "Xác nhận mật khẩu": "Confirm password",
    "Xác nhận": "Confirm",
    "Yêu cầu chuyển quyền chủ nhà": "Ownership transfer request",
    "Đã gửi yêu cầu chuyển quyền": "Transfer request sent",
    "Đã gửi yêu cầu chuyển quyền chủ nhà": "Ownership transfer request sent",
    "Bạn không có quyền xoá thiết bị":
        "You do not have permission to delete devices",
    "Xóa Device?": "Delete this device?",
    "Đã gửi yêu cầu xoá thiết bị": "Device deletion request sent",
    "Đang xoá thiết bị": "Deleting device",
    "Đăng xuất?": "Sign out?",
    "Thêm nhà mới": "Add a new home",
    "Tên nhà": "Home name",
    "Đã tạo nhà mới": "Home created",
    "Về muộn": "Coming home late",
    "Ra ngoài": "Going out",
    "Khác": "Other",
    "⏸️ Tạm tắt Alarm hôm nay": "⏸️ Pause Alarm today",
    "Chọn giờ bắt đầu tạm tắt": "Choose pause start time",
    "Từ giờ": "From",
    "Chọn giờ kết thúc tạm tắt": "Choose pause end time",
    "Đến giờ": "Until",
    "Xóa lịch tạm tắt": "Delete pause schedule",
    "Đổi tên hiển thị": "Change display name",
    "Cập nhật thông tin nhà": "Update home information",
    "Nhập địa chỉ của nhà": "Enter the home address",
    "Lưu thay đổi": "Save changes",
    "Tên này chỉ hiển thị riêng trên tài khoản của bạn.":
        "This name is only shown on your account.",
    "Tên và địa chỉ sẽ được cập nhật cho toàn bộ thành viên trong nhà.":
        "The name and address will be updated for all home members.",
    "Một thành viên": "A member",
    "Đã cập nhật thông tin nhà": "Home information updated",
    "Thay tên": "Rename",
    "Đã đổi tên thiết bị": "Device renamed",
    "Chưa chọn nhà để kiểm tra": "Select a home to test",
    "Hãy thực hiện kiểm tra bằng tài khoản Owner":
        "Run this test using the owner account",
    "Không đọc được dữ liệu nhà": "Unable to read home data",
    "Nhà cần có ít nhất một thiết bị để test":
        "The home needs at least one device for testing",
    "Đóng": "Close",
    "Đã thiết lập": "Configured",
    "Quét QR": "Scan QR",
    "Quét QR để thêm thiết bị": "Scan QR to add a device",
    "Nhập HUB ID thủ công": "Enter HUB ID manually",
    "Bạn không có quyền sắp xếp phòng":
        "You do not have permission to reorder rooms",
    "Cảnh báo khói": "Smoke alert",
    "Cập nhật thiết bị": "Device update",
    "Cửa đang mở": "Door is open",
    "Cửa đã đóng": "Door closed",
    "Firebase Rules: CÓ LỖI": "Firebase Rules: ISSUES FOUND",
    "Firebase Rules: ĐẠT": "Firebase Rules: PASSED",
    "Giờ không hợp lệ": "Invalid time",
    "Hôm nay đã ghi nhận cảnh báo SOS": "An SOS alert was recorded today",
    "Hôm nay đã ghi nhận cảnh báo khói": "A smoke alert was recorded today",
    "Khói đã an toàn": "Smoke condition cleared",
    "Không tìm thấy nhà của thông báo này":
        "The home for this notification was not found",
    "Không tìm thấy thiết bị trong nhà này":
        "The device was not found in this home",
    "Một chủ nhà": "A homeowner",
    "Ngôi nhà đang hoạt động ổn định": "The home is operating normally",
    "Nhiệt độ cao": "High temperature",
    "OK": "OK",
    "Pin yếu": "Low battery",
    "SOS đã kết thúc": "SOS cleared",
    "SOS được kích hoạt": "SOS activated",
    "Tamper bình thường": "Tamper condition cleared",
    "Thiết bị bị tháo": "Tamper detected",
    "Thiết bị mới": "New device",
    "Thiết bị offline": "Device offline",
    "Thiết bị online": "Device online",
    "Tạm tắt Alarm hôm nay": "Pause Alarm today",
    "Độ ẩm cao": "High humidity",
  };

  static const Map<String, String> _chinese = {
    "NhÃ  chÆ°a Ä‘áº·t tÃªn": "未命名的家",
    "NhÃ ": "家",
    "ChÆ°a cÃ³ thÃ´ng tin": "暂无信息",
    "ChÆ°a cáº­p nháº­t": "未更新",
    "Chá»§ nhÃ ": "屋主",
    "NhÃ  Ä‘Æ°á»£c chia sáº»": "共享家庭",
    "Äá»‹a chá»‰": "地址",
    "An ninh ra/vÃ o": "出入安全",
    "Nguy hiá»ƒm kháº©n cáº¥p": "紧急危险",
    "Äiá»u khiá»ƒn & háº¡ táº§ng": "控制与基础设施",
    "Thiáº¿t bá»‹ Ä‘ang Offline": "设备离线",
    "Thiáº¿t bá»‹ Ä‘ang Online": "设备在线",
    "pin yáº¿u": "电量低",
    "sÃ³ng yáº¿u": "信号弱",
    "lÃ¢u khÃ´ng pháº£n há»“i": "长时间无响应",
    "Káº¿t ná»‘i cáº§n kiá»ƒm tra": "连接需要检查",
    "Vá»«a xong": "刚刚",
    "Bá»‹ thÃ¡o": "检测到拆卸",
    "CÃ³ khÃ³i": "检测到烟雾",
    "BÃ¬nh thÆ°á»ng": "正常",
    "ÄÃ£ kÃ­ch hoáº¡t": "已激活",
    "Sáºµn sÃ ng": "就绪",
    "Äang Ä‘Ã³ng": "已关闭",
    "Äang má»Ÿ": "已打开",
    "RÃ² rá»‰ gas": "检测到燃气泄漏",
    "PhÃ¡t hiá»‡n ngáº­p nÆ°á»›c": "检测到漏水",
    "PhÃ¡t hiá»‡n chuyá»ƒn Ä‘á»™ng": "检测到移动",
    "KhÃ´ng cÃ³ chuyá»ƒn Ä‘á»™ng": "未检测到移动",
    "PhÃ¡t hiá»‡n hiá»‡n diá»‡n": "检测到有人",
    "KhÃ´ng phÃ¡t hiá»‡n hiá»‡n diá»‡n": "未检测到有人",
    "PhÃ¡t hiá»‡n rung/cháº¥n Ä‘á»™ng": "检测到震动",
    "KhÃ´ng cÃ³ rung báº¥t thÆ°á»ng": "无异常震动",
    "PhÃ¡t hiá»‡n kÃ­nh vá»¡": "检测到玻璃破碎",
    "KhÃ´ng cÃ³ cáº£nh bÃ¡o kÃ­nh vá»¡": "无玻璃破碎警报",
    "Nhiá»‡t Ä‘á»™ nguy hiá»ƒm": "危险高温",
    "PhÃ¡t hiá»‡n khÃ­ CO": "检测到一氧化碳",
    "KhÃ´ng phÃ¡t hiá»‡n khÃ­ CO": "未检测到一氧化碳",
    "KhÃ³a Ä‘ang má»Ÿ": "未上锁",
    "KhÃ³a Ä‘ang Ä‘Ã³ng": "已上锁",
    "Äang báº­t": "开启",
    "Äang táº¯t": "关闭",
    "Äang theo dÃµi Ä‘iá»‡n nÄƒng": "正在监测电力",
    "Äang dÃ¹ng nguá»“n dá»± phÃ²ng": "正在使用备用电源",
    "Nguá»“n Ä‘iá»‡n bÃ¬nh thÆ°á»ng": "市电正常",
    "CÃ²i Ä‘ang báº­t": "警笛响起",
    "CÃ²i sáºµn sÃ ng": "警笛就绪",
    "Van Ä‘ang má»Ÿ": "阀门打开",
    "Van Ä‘Ã£ Ä‘Ã³ng": "阀门关闭",
    "Äang hoáº¡t Ä‘á»™ng": "运行中",
    "ChÆ°a nháº­n diá»‡n": "未识别设备",
    "ChÆ°a cÃ³ cáº­p nháº­t": "暂无更新",
    "CHÆ¯A AN TOÃ€N": "不安全",
    "Cáº¦N CHÃš Ã": "需要注意",
    "ÄÃƒ AN TOÃ€N": "安全",
    "NhÃ  Ä‘ang cÃ³ dáº¥u hiá»‡u cáº§n kiá»ƒm tra, báº¡n nÃªn xem láº¡i cÃ¡c tráº¡ng thÃ¡i bÃªn dÆ°á»›i.":
        "家中有需要检查的迹象，请查看下面的状态。",
    "NhÃ  Ä‘ang hoáº¡t Ä‘á»™ng á»•n Ä‘á»‹nh, báº¡n cÃ³ thá»ƒ yÃªn tÃ¢m.":
        "家中运行稳定，可以安心。",
    "KhÃ´ng cÃ³ dáº¥u hiá»‡u khÃ³i hoáº·c SOS báº¥t thÆ°á»ng.":
        "未发现异常烟雾或 SOS。",
    "ChÆ°a cÃ³ nhiá»u hoáº¡t Ä‘á»™ng má»›i Ä‘á»ƒ phÃ¢n tÃ­ch sÃ¢u hÆ¡n.":
        "暂无足够的新活动用于深入分析。",
    "CÃ i Ä‘áº·t cáº£nh bÃ¡o cho nhÃ  hiá»‡n táº¡i": "当前家庭的提醒设置",
    "Nháº­n cáº£nh bÃ¡o Alarm": "接收警报提醒",
    "Äang báº­t cho tÃ i khoáº£n nÃ y": "此账户已开启",
    "Äang táº¯t cho tÃ i khoáº£n nÃ y": "此账户已关闭",
    "Háº¹n giá» Reminder": "提醒计划",
    "Nháº¯c kiá»ƒm tra nhÃ  theo thá»i gian": "按时间提醒检查家庭",
    "Háº¹n giá» Alarm": "警报计划",
    "ChÆ°a thiáº¿t láº­p": "未设置",
    "ChÆ°a thiáº¿t láº­p thá»i gian": "未设置时间",
    "Tá»•ng há»£p tráº¡ng thÃ¡i nhÃ ": "家庭状态汇总",
    "Cáº§n xá»­ lÃ½ ngay": "需要立即处理",
    "Cáº§n kiá»ƒm tra": "需要检查",
    "ÄÃ¡nh giÃ¡ tá»± Ä‘á»™ng": "自动评估",
    "Tá»•ng quan hÃ´m nay": "今日概览",
    "ChÆ°a cÃ³ dá»¯ liá»‡u tá»•ng quan": "暂无概览数据",
    "ChÆ°a cÃ³ dá»¯ liá»‡u tráº¡ng thÃ¡i": "暂无状态数据",
    "Báº¥m vÃ o Ä‘á»ƒ xem chi tiáº¿t": "点击查看详情",
    "Táº¡m dá»«ng": "暂停",
    "Táº¯t": "关闭",
    "Chi tiáº¿t": "详情",
    "Tá»•ng há»£p tráº¡ng thÃ¡i": "状态汇总",
    "KhÃ´ng an toÃ n": "不安全",
    "Cáº§n chÃº Ã½": "需要注意",
    "An toÃ n": "安全",
    "KhÃ´ng cÃ³": "无",
    "Huá»·": "取消",
    "Há»§y": "取消",
    "LÆ°u": "保存",
    "NhÃ  cá»§a tÃ´i": "我的家庭",
    "Giá»": "小时",
    "PhÃºt": "分钟",
    "Äáº·t Home Reminder": "设置家庭提醒",
    "Äáº·t Home Alarm": "设置家庭警报",
    "XÃ¡c nháº­n thay Ä‘á»•i": "确认更改",
    "Tiáº¿p tá»¥c": "继续",
    "Giá» Reminder": "提醒时间",
    "Giá» báº¯t Ä‘áº§u Alarm": "警报开始时间",
    "Giá» káº¿t thÃºc Alarm": "警报结束时间",
    "CÃ i Ä‘áº·t hoÃ n táº¥t": "设置完成",
    "XÃ¡c nháº­n rá»i nhÃ ": "确认离开家庭",
    "XÃ¡c nháº­n xoÃ¡ nhÃ ": "确认删除家庭",
    "Nháº­p máº­t kháº©u": "输入密码",
    "Máº­t kháº©u tÃ i khoáº£n": "账户密码",
    "Rá»i khá»i nhÃ ": "离开家庭",
    "XoÃ¡ nhÃ ": "删除家庭",
    "Sai máº­t kháº©u": "密码错误",
    "ÄÃ£ rá»i khá»i home": "已离开家庭",
    "ÄÃ£ cáº­p nháº­t": "已更新",
    "TÃ¬m home...": "搜索家庭...",
    "Chia sáº»": "共享",
    "Email ngÆ°á»i nháº­n": "收件人邮箱",
    "Email chÆ°a Ä‘Äƒng kÃ½": "邮箱未注册",
    "Chia sáº» hoÃ n táº¥t": "共享完成",
    "ChÆ°a share cho ai": "尚未共享给任何人",
    "ThÃ´ng bÃ¡o Home": "家庭通知",
    "KhÃ´ng cÃ³ thiáº¿t bá»‹": "没有设备",
    "Chá»‰ chá»§ nhÃ  má»›i Ä‘Æ°á»£c xoÃ¡ nhÃ ": "只有屋主可以删除家庭",
    "Chá»‰ chá»§ nhÃ  má»›i Ä‘Æ°á»£c chuyá»ƒn quyá»n": "只有屋主可以转移所有权",
    "LÆ°u Ã½ khi báº­t Alarm": "开启警报提示",
    "ÄÃ£ hiá»ƒu": "知道了",
    "ÄÃ£ báº­t Alarm": "警报已开启",
    "ÄÃ£ táº¯t Alarm": "警报已关闭",
    "Cáº£ ngÃ y": "全天",
    "Má»™t ngÆ°á»i dÃ¹ng": "一位用户",
    "YÃªu cáº§u gia nháº­p nhÃ ": "加入家庭请求",
    "ÄÃ£ gá»­i yÃªu cáº§u gia nháº­p nhÃ ": "已发送加入请求",
    "Báº¡n khÃ´ng cÃ³ quyá»n thÃªm thiáº¿t bá»‹": "你没有添加设备的权限",
    "ÄÃ£ má»Ÿ cháº¿ Ä‘á»™ thÃªm thiáº¿t bá»‹": "设备配对已开启",
    "QR cá»§a nhÃ  nÃ y": "此家庭的二维码",
    "Chia sáº» nhÃ ": "共享家庭",
    "QuÃ©t QR Ä‘á»ƒ xin gia nháº­p nhÃ ": "扫描二维码加入家庭",
    "Xin gia nháº­p nhÃ ": "加入家庭",
    "QuÃ©t mÃ£ QR chia sáº» nhÃ ": "扫描家庭共享二维码",
    "Má»i thÃ nh viÃªn báº±ng mÃ£ QR": "用二维码邀请成员",
    "KhÃ´ng thá»ƒ share cho chÃ­nh báº¡n": "不能共享给自己",
    "Lá»i má»i chia sáº» nhÃ ": "家庭共享邀请",
    "ÄÃ£ share home": "家庭已共享",
    "Chuyá»ƒn quyá»n chá»§ nhÃ ": "转移屋主权限",
    "KhÃ´ng thá»ƒ chuyá»ƒn quyá»n cho chÃ­nh báº¡n": "不能转移给自己",
    "KhÃ´ng tÃ¬m tháº¥y user": "未找到用户",
    "XÃ¡c nháº­n chuyá»ƒn quyá»n": "确认转移所有权",
    "Chuyá»ƒn": "转移",
    "XÃ¡c nháº­n máº­t kháº©u": "确认密码",
    "XÃ¡c nháº­n": "确认",
    "YÃªu cáº§u chuyá»ƒn quyá»n chá»§ nhÃ ": "屋主权限转移请求",
    "ÄÃ£ gá»­i yÃªu cáº§u chuyá»ƒn quyá»n": "已发送转移请求",
    "Báº¡n khÃ´ng cÃ³ quyá»n xoÃ¡ thiáº¿t bá»‹": "你没有删除设备的权限",
    "XÃ³a Device?": "删除设备？",
    "Äang xoÃ¡ thiáº¿t bá»‹": "正在删除设备",
    "ÄÄƒng xuáº¥t?": "退出登录？",
    "ThÃªm nhÃ  má»›i": "添加新家庭",
    "TÃªn nhÃ ": "家庭名称",
    "ÄÃ£ táº¡o nhÃ  má»›i": "家庭已创建",
    "Vá» muá»™n": "晚回家",
    "Ra ngoÃ i": "外出",
    "KhÃ¡c": "其他",
    "Táº¡m táº¯t Alarm hÃ´m nay": "今天暂停警报",
    "Chá»n giá» báº¯t Ä‘áº§u táº¡m táº¯t": "选择暂停开始时间",
    "Tá»« giá»": "从",
    "Chá»n giá» káº¿t thÃºc táº¡m táº¯t": "选择暂停结束时间",
    "Äáº¿n giá»": "到",
    "XÃ³a lá»‹ch táº¡m táº¯t": "删除暂停计划",
    "Äá»•i tÃªn hiá»ƒn thá»‹": "更改显示名称",
    "Cáº­p nháº­t thÃ´ng tin nhÃ ": "更新家庭信息",
    "Nháº­p Ä‘á»‹a chá»‰ cá»§a nhÃ ": "输入家庭地址",
    "LÆ°u thay Ä‘á»•i": "保存更改",
    "Má»™t thÃ nh viÃªn": "一位成员",
    "ÄÃ£ cáº­p nháº­t thÃ´ng tin nhÃ ": "家庭信息已更新",
    "Thay tÃªn": "重命名",
    "ÄÃ£ Ä‘á»•i tÃªn thiáº¿t bá»‹": "设备已重命名",
    "ÄÃ³ng": "关闭",
    "ÄÃ£ thiáº¿t láº­p": "已设置",
    "QuÃ©t QR": "扫描二维码",
    "QuÃ©t QR Ä‘á»ƒ thÃªm thiáº¿t bá»‹": "扫描二维码添加设备",
    "Nháº­p HUB ID thá»§ cÃ´ng": "手动输入 HUB ID",
    "Báº¡n khÃ´ng cÃ³ quyá»n sáº¯p xáº¿p phÃ²ng": "你没有排序房间的权限",
    "Cáº£nh bÃ¡o khÃ³i": "烟雾警报",
    "Cáº­p nháº­t thiáº¿t bá»‹": "设备更新",
    "Cá»­a Ä‘ang má»Ÿ": "门已打开",
    "Cá»­a Ä‘Ã£ Ä‘Ã³ng": "门已关闭",
    "Giá» khÃ´ng há»£p lá»‡": "时间无效",
    "NgÃ´i nhÃ  Ä‘ang hoáº¡t Ä‘á»™ng á»•n Ä‘á»‹nh": "家庭运行稳定",
    "Nhiá»‡t Ä‘á»™ cao": "温度过高",
    "OK": "确定",
    "Pin yáº¿u": "电量低",
    "SOS Ä‘Ã£ káº¿t thÃºc": "SOS 已结束",
    "SOS Ä‘Æ°á»£c kÃ­ch hoáº¡t": "SOS 已触发",
    "Tamper bÃ¬nh thÆ°á»ng": "防拆状态正常",
    "Thiáº¿t bá»‹ bá»‹ thÃ¡o": "设备被拆卸",
    "Thiáº¿t bá»‹ má»›i": "新设备",
    "Thiáº¿t bá»‹ offline": "设备离线",
    "Thiáº¿t bá»‹ online": "设备在线",
    "Äá»™ áº©m cao": "湿度过高",
  };

  String t(String vi) {
    if (isChinese) {
      return _chinese[vi] ?? vi;
    }

    if (!isEnglish) {
      return vi;
    }

    return _english[vi] ?? vi;
  }

  String statusText(String text) {
    if ((!isEnglish && !isChinese) || text.trim().isEmpty) {
      return text;
    }

    final translations = isChinese ? _chinese : _english;

    final exact = translations[text];
    if (exact != null) {
      return exact;
    }

    final issueParts = text.split(": ");
    if (issueParts.length >= 2) {
      final name = issueParts.first;
      final details = issueParts.sublist(1).join(": ");
      final translatedDetails = details
          .split(" & ")
          .map(_translateStatusFragment)
          .join(" & ");
      return "$name: $translatedDetails";
    }

    final closedMatch = RegExp(
      r"^(\d+)/(\d+) cửa đã đóng an toàn$",
    ).firstMatch(text);
    if (closedMatch != null) {
      return "${closedMatch.group(1)}/${closedMatch.group(2)} doors safely closed";
    }

    final securedAccessMatch = RegExp(
      r"^(\d+)/(\d+) cửa và khóa đã an toàn$",
    ).firstMatch(text);
    if (securedAccessMatch != null) {
      return "${securedAccessMatch.group(1)}/${securedAccessMatch.group(2)} doors and locks secured";
    }

    final deviceMatch = RegExp(
      r"^(\d+) thiết bị đang được theo dõi$",
    ).firstMatch(text);
    if (deviceMatch != null) {
      return "${deviceMatch.group(1)} devices monitored";
    }

    final minuteMatch = RegExp(
      r"^Dữ liệu gần nhất cập nhật (\d+) phút trước$",
    ).firstMatch(text);
    if (minuteMatch != null) {
      return "Latest data updated ${minuteMatch.group(1)} minutes ago";
    }

    final hourMatch = RegExp(
      r"^Dữ liệu gần nhất cập nhật (\d+) giờ trước$",
    ).firstMatch(text);
    if (hourMatch != null) {
      return "Latest data updated ${hourMatch.group(1)} hours ago";
    }

    if (text.startsWith("Môi trường hiện tại: ")) {
      return text.replaceFirst(
        "Môi trường hiện tại: ",
        "Current environment: ",
      );
    }

    return _translateStatusFragment(text);
  }

  String _translateStatusFragment(String text) {
    if (isChinese) {
      final exact = _chinese[text];

      if (exact != null) {
        return exact;
      }
    }

    const fragments = {
      "Nhiệt độ cao": "High temperature",
      "Độ ẩm cao": "High humidity",
      "Có khói": "Smoke detected",
      "SOS": "SOS",
      "Đang mở khi nhà ở chế độ Bảo vệ": "Open while Home is in Guard mode",
      "Đang mở trong giờ Alarm": "Open during Alarm hours",
      "Đang mở": "Open",
      "Phát hiện chuyển động": "Motion detected",
      "Phát hiện hiện diện": "Presence detected",
      "Phát hiện rung/chấn động": "Vibration detected",
      "Phát hiện kính vỡ": "Glass break detected",
      "Nhiệt độ nguy hiểm": "Dangerous heat detected",
      "Phát hiện khí CO": "Carbon monoxide detected",
      "Khóa đang mở khi nhà ở chế độ Bảo vệ":
          "Unlocked while Home is in Guard mode",
      "Khóa đang mở trong giờ Alarm": "Unlocked during Alarm hours",
      "Khóa đang mở": "Unlocked",
      "Mất điện lưới": "Mains power lost",
      "Rò rỉ gas": "Gas leak detected",
      "Phát hiện ngập nước": "Water leak detected",
      "Bị tháo": "Tamper detected",
      "Pin yếu": "Low battery",
      "Sóng yếu": "Weak signal",
      "Mất kết nối": "Disconnected",
      "Hub chưa gửi trạng thái": "Hub status unavailable",
      "Hub mất kết nối": "Hub disconnected",
      "MQTT mất kết nối": "MQTT disconnected",
      "Đang kiểm tra kết nối Hub": "Checking Hub connection",
      "Hub tín hiệu bình thường": "Hub connected",
      "Chưa có dữ liệu thiết bị để đánh giá":
          "No device data available for assessment",
    };

    return fragments[text] ?? text;
  }

  String get splashTagline => choose(
    vi: "An tâm hơn trong từng ngôi nhà",
    en: "Peace of mind in every home",
  );

  String get alarmTitle =>
      choose(vi: "Báo động SafeHome", en: "SafeHome Alarm");

  String get alarmBody => choose(
    vi: "Có cảnh báo an ninh cần kiểm tra ngay.",
    en: "A security alert requires your attention.",
  );

  String get alarmFallback => choose(
    vi: "Có cảnh báo cần kiểm tra",
    en: "An alert requires your attention",
  );

  String get owner => t("Chủ nhà");
  String get admin => choose(vi: "Quản trị viên", en: "Admin");
  String get member => choose(vi: "Thành viên", en: "Member");
  String get notUpdated => t("Chưa cập nhật");
  String get unnamedHome => t("Nhà chưa đặt tên");
  String get role => choose(vi: "Vai trò", en: "Role");
  String get address => t("Địa chỉ");
  String get members => choose(vi: "Thành viên", en: "Members");
  String get loading => choose(vi: "Đang tải...", en: "Loading...");
  String get manageHome => choose(vi: "Quản lý nhà", en: "Home management");
  String get shareHome => t("Chia sẻ nhà");
  String get shareHomeSubtitle => choose(
    vi: "Mời người khác tham gia nhà này",
    en: "Invite someone to join this home",
  );
  String get homeMembers =>
      choose(vi: "Thành viên đang ở nhà", en: "Members are at home");
  String get homeMembersSubtitle => choose(
    vi: "Xem và quản lý quyền thành viên",
    en: "View and manage member roles",
  );
  String get manageRooms => choose(vi: "Quản lý phòng", en: "Manage rooms");
  String get manageRoomsSubtitle => choose(
    vi: "Thêm, đổi tên và sắp xếp phòng",
    en: "Add, rename and reorder rooms",
  );
  String get allDevices => choose(vi: "Toàn bộ thiết bị", en: "All devices");
  String get allDevicesSubtitle => choose(
    vi: "Kiểm tra thiết bị trong nhà này",
    en: "Review devices in this home",
  );
  String get transferOwnership => t("Chuyển quyền chủ nhà");
  String get transferOwnershipSubtitle => choose(
    vi: "Chuyển quyền sở hữu cho thành viên khác",
    en: "Transfer ownership to another member",
  );
  String get accountAndSystem =>
      choose(vi: "Tài khoản & hệ thống", en: "Account & system");
  String get personalAccount =>
      choose(vi: "Tài khoản cá nhân", en: "Personal account");
  String get personalAccountSubtitle => choose(
    vi: "Hồ sơ, yêu cầu và lời mời tham gia",
    en: "Profile, requests and invitations",
  );
  String get language => choose(vi: "Ngôn ngữ", en: "Language");
  String get languageSubtitle => choose(
    vi: "Thay đổi ngôn ngữ hiển thị",
    en: "Change the display language",
  );
  String get chooseLanguage =>
      choose(vi: "Chọn ngôn ngữ", en: "Choose language");
  String get vietnamese =>
      choose(vi: "Tiếng Việt", en: "Vietnamese", zh: "越南语");
  String get english => choose(vi: "Tiếng Anh", en: "English", zh: "英语");
  String get chinese => choose(vi: "Tiếng Trung", en: "Chinese", zh: "中文");
  String get currentLanguageName {
    if (isChinese) {
      return "中文";
    }

    return isEnglish ? "English" : "Tiếng Việt";
  }

  String get dangerZone => choose(vi: "Khu vực nguy hiểm", en: "Danger zone");
  String get deleteHome => t("Xoá nhà");
  String get deleteHomeSubtitle => choose(
    vi: "Xoá toàn bộ dữ liệu và thiết bị",
    en: "Delete all home data and devices",
  );
}

extension AppStringsContext on BuildContext {
  AppStrings get strings => AppStrings.of(this);
}

import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';

class AlarmDeviceSheet extends StatefulWidget {
  final String ownerUid;
  final String homeId;
  final Map<String, dynamic> devices;
  final bool canManageHome;
  const AlarmDeviceSheet({
    super.key,
    required this.ownerUid,
    required this.homeId,
    required this.devices,
    required this.canManageHome,
  });

  @override
  State<AlarmDeviceSheet> createState() => _AlarmDeviceSheetState();
}

class _AlarmDeviceSheetState extends State<AlarmDeviceSheet> {
  Map<String, dynamic> devices = {};
  Map<String, dynamic> homeAlarms = {};
  Map<String, dynamic> customAlarms = {};

  String mode = "home";
  String expandedDeviceId = "";

  String get currentUid =>
      FirebaseAuth.instance.currentUser?.uid ?? widget.ownerUid;

  bool get isSharedUser => currentUid != widget.ownerUid;

  @override
  void initState() {
    super.initState();

    devices = Map<String, dynamic>.from(widget.devices);

    for (final entry in devices.entries) {
      final deviceId = entry.key.toString();
      final device = Map<String, dynamic>.from(entry.value);

      homeAlarms[deviceId] = Map<String, dynamic>.from(
        device["alarm"] ?? _defaultAlarm(),
      );
    }

    FirebaseDatabase.instance
        .ref("accounts/$currentUid/customRules/${widget.homeId}")
        .get()
        .then((snap) {
          if (!mounted) return;

          final data = snap.value;

          if (data is Map) {
            final map = Map<String, dynamic>.from(data);
            final savedMode = map["mode"]?.toString();
            final customDevices = map["devices"];

            if (customDevices is Map) {
              for (final entry in customDevices.entries) {
                final deviceId = entry.key.toString();
                final deviceData = Map<String, dynamic>.from(
                  entry.value as Map,
                );

                if (deviceData["alarm"] is Map) {
                  customAlarms[deviceId] = Map<String, dynamic>.from(
                    deviceData["alarm"],
                  );
                }
              }
            }

            setState(() {
              if (savedMode == "custom" || savedMode == "home") {
                mode = savedMode == "custom" ? "custom" : "home";
              }
            });
          }
        });
  }

  Map<String, dynamic> _defaultAlarm() {
    return {
      "enabled": false,
      "start": "23:00",
      "end": "06:00",
      "repeatMinutes": 30,
    };
  }

  bool isSecurityDevice(Map d) {
    final type = d["type"]?.toString();

    return type == "door" || type == "door_lock" || type == "motion";
  }

  Map<String, dynamic> alarmOf(String deviceId) {
    final source = mode == "custom"
        ? customAlarms[deviceId] ?? homeAlarms[deviceId]
        : homeAlarms[deviceId];

    return Map<String, dynamic>.from(source ?? _defaultAlarm());
  }

  Future<void> saveMode(String nextMode) async {
    final rulesRef = FirebaseDatabase.instance.ref(
      "accounts/$currentUid/customRules/${widget.homeId}",
    );

    if (nextMode == "custom") {
      final updates = <String, Object?>{"mode": "custom"};

      final nextCustomAlarms = <String, dynamic>{};

      for (final entry in devices.entries) {
        final deviceId = entry.key.toString();
        final rawDevice = entry.value;

        if (rawDevice is! Map) {
          continue;
        }

        final device = Map<String, dynamic>.from(rawDevice);

        if (!isSecurityDevice(device)) {
          continue;
        }

        final rawRealDeviceId = device["_deviceId"]?.toString().trim() ?? "";

        final realDeviceId = rawRealDeviceId.isNotEmpty
            ? rawRealDeviceId
            : deviceId;

        final rawAlarm =
            customAlarms[deviceId] ??
            customAlarms[realDeviceId] ??
            homeAlarms[deviceId] ??
            homeAlarms[realDeviceId];

        final alarm = rawAlarm is Map
            ? Map<String, dynamic>.from(rawAlarm)
            : _defaultAlarm();

        nextCustomAlarms[deviceId] = Map<String, dynamic>.from(alarm);

        updates["devices/$realDeviceId/alarm"] = Map<String, dynamic>.from(
          alarm,
        );
      }

      await rulesRef.update(updates);

      if (!mounted) {
        return;
      }

      setState(() {
        customAlarms = nextCustomAlarms;
        mode = "custom";
        expandedDeviceId = "";
      });

      return;
    }

    await rulesRef.child("mode").set("home");

    if (!mounted) {
      return;
    }

    setState(() {
      mode = "home";
      expandedDeviceId = "";
    });
  }

  Future<void> saveAlarm(String deviceId, Map<String, dynamic> alarm) async {
    if (mode == "home" && !widget.canManageHome) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text("Bạn không có quyền sửa lịch Alarm của nhà"),
          ),
        );
      }

      return;
    }

    final device = Map<String, dynamic>.from(devices[deviceId] ?? {});
    final homeId = device["_homeId"]?.toString() ?? widget.homeId;
    final realDeviceId = device["_deviceId"]?.toString() ?? deviceId;

    final path = mode == "custom"
        ? "accounts/$currentUid/customRules/$homeId/devices/$realDeviceId/alarm"
        : "accounts/${widget.ownerUid}/homes/$homeId/devices/$realDeviceId/alarm";

    await FirebaseDatabase.instance.ref(path).set(alarm);

    setState(() {
      if (mode == "custom") {
        customAlarms[deviceId] = alarm;
      } else {
        homeAlarms[deviceId] = alarm;
      }
    });
  }

  TimeOfDay parseTime(String value) {
    final parts = value.split(":");

    return TimeOfDay(
      hour: int.tryParse(parts[0]) ?? 23,
      minute: int.tryParse(parts[1]) ?? 0,
    );
  }

  String formatTime(TimeOfDay time) {
    final h = time.hour.toString().padLeft(2, "0");
    final m = time.minute.toString().padLeft(2, "0");
    return "$h:$m";
  }

  bool isValidTime(String value) {
    final reg = RegExp(r'^([01]\d|2[0-3]):([0-5]\d)$');
    return reg.hasMatch(value.trim());
  }

  Future<String?> openTimeTextInput({
    required String title,
    required String initial,
  }) async {
    final parts = initial.split(":");

    final hourController = TextEditingController(text: parts[0]);

    final minuteController = TextEditingController(text: parts[1]);

    const suggestions = [
      ["23", "00"],
      ["00", "00"],
      ["01", "00"],
      ["04", "00"],
      ["05", "00"],
      ["06", "00"],
    ];

    return showDialog<String>(
      context: context,
      builder: (_) {
        return AlertDialog(
          title: Text(title),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: hourController,
                      keyboardType: TextInputType.number,
                      maxLength: 2,
                      decoration: const InputDecoration(
                        labelText: "Giờ",
                        counterText: "",
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                  const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 10),
                    child: Text(
                      ":",
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  Expanded(
                    child: TextField(
                      controller: minuteController,
                      keyboardType: TextInputType.number,
                      maxLength: 2,
                      decoration: const InputDecoration(
                        labelText: "Phút",
                        counterText: "",
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Column(
                children: [
                  Row(
                    children: suggestions.take(3).map((s) {
                      return Expanded(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 4),
                          child: ActionChip(
                            label: Text("${s[0]}:${s[1]}"),
                            onPressed: () {
                              hourController.text = s[0];
                              minuteController.text = s[1];
                            },
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: suggestions.skip(3).map((s) {
                      return Expanded(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 4),
                          child: ActionChip(
                            label: Text("${s[0]}:${s[1]}"),
                            onPressed: () {
                              hourController.text = s[0];
                              minuteController.text = s[1];
                            },
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ],
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Huỷ"),
            ),
            ElevatedButton(
              onPressed: () {
                final value =
                    "${hourController.text.padLeft(2, '0')}:${minuteController.text.padLeft(2, '0')}";

                if (!isValidTime(value)) return;

                Navigator.pop(context, value);
              },
              child: const Text("OK"),
            ),
          ],
        );
      },
    );
  }

  Future<void> pickTime({
    required String deviceId,
    required Map<String, dynamic> alarm,
    required String field,
  }) async {
    final picked = await openTimeTextInput(
      title: field == "start"
          ? "Chọn giờ bắt đầu Alarm"
          : "Chọn giờ kết thúc Alarm",
      initial: alarm[field]?.toString() ?? "23:00",
    );

    if (picked == null) return;

    final nextAlarm = Map<String, dynamic>.from(alarm);
    nextAlarm[field] = picked;

    await saveAlarm(deviceId, nextAlarm);
  }

  @override
  Widget build(BuildContext context) {
    final securityDevices = devices.entries.where((e) {
      return isSecurityDevice(Map<String, dynamic>.from(e.value));
    }).toList();

    return SafeArea(
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              "Alarm thiết bị",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
            ),

            const SizedBox(height: 14),

            SegmentedButton<String>(
              segments: const [
                ButtonSegment(
                  value: "home",
                  label: Text("Theo nhà"),
                  icon: Icon(Icons.home_rounded),
                ),
                ButtonSegment(
                  value: "custom",
                  label: Text("Riêng tôi"),
                  icon: Icon(Icons.person_rounded),
                ),
              ],
              selected: {mode},
              onSelectionChanged: (value) async {
                final nextMode = value.first;

                await saveMode(nextMode);
              },
            ),

            if (mode == "home" && isSharedUser) ...[
              const SizedBox(height: 10),
              Text(
                "Bạn đang xem lịch của chủ nhà. Chọn Riêng tôi để tự đặt lịch alarm.",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 12,
                  height: 1.35,
                  color: Colors.grey.shade600,
                ),
              ),
            ],

            const SizedBox(height: 14),

            Flexible(
              child: ListView.builder(
                shrinkWrap: true,
                itemCount: securityDevices.length,
                itemBuilder: (_, index) {
                  final deviceId = securityDevices[index].key;
                  final device = Map<String, dynamic>.from(
                    securityDevices[index].value,
                  );

                  final alarm = alarmOf(deviceId);
                  final readOnly =
                      mode == "home" && isSharedUser && !widget.canManageHome;
                  final expanded = expandedDeviceId == deviceId;

                  return Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.red.withValues(alpha: 0.07),
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(
                        color: Colors.red.withValues(alpha: 0.10),
                      ),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Row(
                          children: [
                            const Icon(
                              Icons.shield_moon_rounded,
                              color: Colors.red,
                            ),
                            const SizedBox(width: 10),

                            Expanded(
                              child: InkWell(
                                onTap: () {
                                  setState(() {
                                    expandedDeviceId = expanded ? "" : deviceId;
                                  });
                                },
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      device["name"]?.toString() ?? deviceId,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                        fontWeight: FontWeight.w700,
                                        fontSize: 15,
                                      ),
                                    ),
                                    const SizedBox(height: 3),
                                    Text(
                                      "${alarm["start"] ?? "23:00"} → ${alarm["end"] ?? "06:00"} • ${alarm["repeatMinutes"] ?? 30} phút",
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                        fontSize: 12,
                                        color: Colors.grey.shade600,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),

                            Switch(
                              value: alarm["enabled"] == true,
                              onChanged: readOnly
                                  ? null
                                  : (v) async {
                                      final nextAlarm =
                                          Map<String, dynamic>.from(alarm);
                                      nextAlarm["enabled"] = v;
                                      await saveAlarm(deviceId, nextAlarm);
                                    },
                            ),

                            IconButton(
                              icon: Icon(
                                expanded
                                    ? Icons.expand_less_rounded
                                    : Icons.expand_more_rounded,
                              ),
                              onPressed: () {
                                setState(() {
                                  expandedDeviceId = expanded ? "" : deviceId;
                                });
                              },
                            ),
                          ],
                        ),

                        if (expanded) ...[
                          const SizedBox(height: 10),

                          Row(
                            children: [
                              Expanded(
                                child: _AlarmMiniButton(
                                  label: "Bắt đầu",
                                  value: alarm["start"]?.toString() ?? "23:00",
                                  enabled: !readOnly,
                                  onTap: () => pickTime(
                                    deviceId: deviceId,
                                    alarm: alarm,
                                    field: "start",
                                  ),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: _AlarmMiniButton(
                                  label: "Kết thúc",
                                  value: alarm["end"]?.toString() ?? "06:00",
                                  enabled: !readOnly,
                                  onTap: () => pickTime(
                                    deviceId: deviceId,
                                    alarm: alarm,
                                    field: "end",
                                  ),
                                ),
                              ),
                            ],
                          ),

                          const SizedBox(height: 10),

                          Row(
                            children: [15, 30, 60].map((minute) {
                              final selected = alarm["repeatMinutes"] == minute;

                              return Expanded(
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 3,
                                  ),
                                  child: ChoiceChip(
                                    label: Text("$minute phút"),
                                    selected: selected,
                                    onSelected: readOnly
                                        ? null
                                        : (_) async {
                                            final nextAlarm =
                                                Map<String, dynamic>.from(
                                                  alarm,
                                                );
                                            nextAlarm["repeatMinutes"] = minute;

                                            await saveAlarm(
                                              deviceId,
                                              nextAlarm,
                                            );
                                          },
                                  ),
                                ),
                              );
                            }).toList(),
                          ),
                        ],
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _AlarmMiniButton extends StatelessWidget {
  final String label;
  final String value;
  final bool enabled;
  final VoidCallback onTap;

  const _AlarmMiniButton({
    required this.label,
    required this.value,
    required this.enabled,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: enabled ? onTap : null,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: Colors.grey.shade200),
        ),
        child: Column(
          children: [
            Text(
              label,
              style: TextStyle(fontSize: 11, color: Colors.grey.shade600),
            ),
            const SizedBox(height: 3),
            Text(
              value,
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w800,
                color: enabled ? Colors.black87 : Colors.grey,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

import '../firebase_options.dart';
import 'notification_service.dart';

@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(
    RemoteMessage message,
    ) async {
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');

  await localNotif.initialize(
    const InitializationSettings(
      android: androidInit,
    ),
  );

  final type = message.data['type']?.toString() ?? 'alarm';
  final isSchedule = type == 'schedule_notification';

  final isSafeText = message.data['isSafe']?.toString() ?? 'true';

  final isSafe =
      isSafeText == 'true' || isSafeText == '1' || isSafeText == 'yes';

  final reason = message.data['reason']?.toString().trim() ?? '';

  final scheduleBody = isSafe
      ? '✅ ĐÃ AN TOÀN\nHãy an tâm nghỉ ngơi.'
      : reason.isEmpty
      ? '⚠️ CHƯA AN TOÀN\nCó thiết bị chưa an toàn.'
      : '⚠️ CHƯA AN TOÀN\n$reason';

  NotificationService.lastScheduleBody = scheduleBody;

  final title = message.notification?.title ??
      message.data['title'] ??
      (isSchedule ? '🏡 SAFEHOME' : 'SafeHome Alarm');

  final body = isSchedule
      ? scheduleBody
      : message.notification?.body ??
      message.data['body'] ??
      'Alarm triggered';

  final androidDetails = AndroidNotificationDetails(
    isSchedule
        ? 'safehome_schedule_fullscreen_channel'
        : 'alarm_siren_channel',
    isSchedule ? 'SafeHome Schedule Fullscreen' : 'Alarm Siren',
    importance: Importance.max,
    priority: Priority.high,
    category: isSchedule
        ? AndroidNotificationCategory.reminder
        : AndroidNotificationCategory.alarm,
    fullScreenIntent: true,
    playSound: !isSchedule,
    enableVibration: !isSchedule,
    sound: isSchedule
        ? null
        : const RawResourceAndroidNotificationSound('alarm_siren'),
  );

  await localNotif.show(
    DateTime.now().millisecondsSinceEpoch ~/ 1000,
    title.toString(),
    body.toString(),
    NotificationDetails(
      android: androidDetails,
    ),
    payload: isSchedule
        ? 'schedule_notification|$scheduleBody'
        : 'alarm', );
}